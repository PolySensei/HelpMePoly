
self.importScripts("CompteurJetons.js");
var compteur = new CompteurJetons();

self.addEventListener('message', function(e) {


  var it = compteur.compterJetons(e.data);

  var num = it.next().value;

  var returnValue;

  while (num <= 100) {
    // On envoit les jetons et le progrès (pourcentage)
    returnValue = [compteur.getJetons(), compteur.getProgress()];
    postMessage(returnValue);
    num = it.next().value;
  }

}, false);
