  var worker;
  var estActif = false;

  // Partir le worker
  function startWorker(){
    if(!estActif){
      estActif = true;
      if (typeof(Worker) !== "undefined") {
        if (typeof(worker) == "undefined"){
          worker = new Worker("worker.js");
        }
          worker.onmessage = function (event) {
            console.log("Jetons: " + event.data[0]);
            console.log("Pourcentage: " + event.data[1]);
            document.getElementById("jetons").innerHTML = event.data[0];
            document.getElementById("progres").style.width = event.data[1] + "%";
            document.getElementById("percent").innerHTML = event.data[1] + '%';

            // Si on a terminé de compté on arrete le worker
            if(event.data[1] == 100) {
              fin();
          }

        }
        document.getElementById("jetons").innerHTML = 0;
        document.getElementById("progres").style.width = 0;
        document.getElementById("percent").innerHTML = 0;
        console.log("TextCount :");
        worker.postMessage($('#textcount').val());
      } else {
        console.log("Sorry, your browser does not support Web Workers");
      }
    }
  }

  // Arreter le worker, on s'assure qu'un worker est actif
  function stopWorker(){
    estActif = false;
    document.getElementById("jetons").innerHTML = "Annulé";
    if (typeof(worker) !== "undefined"){
      worker.terminate();
      worker = undefined;
    }
  }

  function fin(){
    estActif = false;
    worker.terminate();
    worker = undefined;
  }

