/**
 * menu.component.ts - Composant représentant le menu d'affichage de l'application
 *
 * @authors Mathieu KABORÉ
 * @date 2017/01/16
 */
import { Component, OnInit } from '@angular/core';
import { PolyDataService } from './poly-data.service';

@Component({
  selector: 'menu-items',
  template: `
  <div *ngFor='let item of this.menuItems' class='menu_element'>
    <a href='{{item.link}}' class='links'>
      <h2>{{item.title}}</h2>
    </a>
  </div>
  `,
  providers: [ PolyDataService ]
})

export class MenuComponent implements OnInit {
  menuItems: Object;

  constructor(private dataService: PolyDataService) { }

  getListeMenu(): void {
    this.dataService.getListeMenu()
      .then((response: Object) => this.menuItems = response)
      .catch(this.handleError);
  }

  ngOnInit(): void {
    this.getListeMenu();
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
