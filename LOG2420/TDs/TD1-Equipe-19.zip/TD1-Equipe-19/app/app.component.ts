import { Component } from '@angular/core';

@Component({
  selector: 'poly-app',
  template: `
  <div class = "header">
    <a href = "/" class = "logo">
      <img src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/logo.png">
    </a>
    <a href= "#" class = "language-link">ENGLISH</a>
  </div>

  <div class = "media_header">
    <div class = "media_header_left">
      <div class = "media_header_left_component">

        <a href = "http://www.facebook.com/polymtl">
          <img class = "media_image"
            src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/fb-black.png">
        </a>
        <a href = "https://www.linkedin.com/company/ecole-polytechnique-de-montreal">
          <img class = "media_image"
            src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/linkedin-black.png">
        </a>
        <a href = "https://www.instagram.com/polymtl/">
          <img class = "media_image"
            src="http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/instagram-black.png">
        </a>
      </div>

      <div class="media_header_left_component">
        <a href = "http://www.polymtl.ca/carrefour-actualite/rss/rss_5.xml">
          <img class = "media_image" src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/rss-black.png">
        </a>
        <a href = "http://www.twitter.com/polymtl">
          <img class = "media_image"
            src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/twitter-black.png">
        </a>
        <a href = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'>
          <img class = "media_image"
            src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/youtube-black.png">
        </a>
      </div>
    </div>

    <div class = "media_header_right">
      <div class = "media_header_right_component">
        <a href = "#!" class = "quick-link">Liens rapides</a>
        <a href = '{{this._search_input}}' (click) = "search()">
          <img class = "image_glass" src = "http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/ico-loupe.png">
        </a>
        <div class = "search_bar">
          <input type = "text" name = "_search_input" [(ngModel)] = "_search_input" />
        </div>
        <a href = '#!' class = "menu-text" (click) = "menu()">Menu</a>
      </div>
    </div>
  </div>
  <div *ngIf = 'this.menuIsClicked'>
    <menu-items></menu-items>
  </div>

  <div class = "image_students">
    <div class = "images_text">
      <h5>{{this._text}}</h5>
    </div>
    <img src = {{this._source}} class = 'images'>
    <div class = 'images_bar'>
      <div class = 'numbers'>
        <a href = '#!'class = 'number links' (click) = 'setImage1()' id = "index1">1</a>
        <a href = '#!'class = 'number links' (click) = 'setImage2()' id = "index2">2</a>
        <a href = '#!'class = 'number links' (click) = 'setImage3()' id = "index3">3</a>
        <a href = '#!'class = 'number links' (click) = 'setImage4()' id = "index4">4</a>
      </div>
    </div>
  </div>

  <div class = "footer">
    <h1>International</h1>
    <p>Avec plus de 250 ententes universitaires et 24% d'étudiants internationaux,
     Polytechnique Montréal est plus que jamais ouverte sur le monde.</p>
    <a href = '#!' class = "discoveries-link">Découvrez les possibilités</a>
  </div>

  <div class = 'news_container'>
    <a href = '#!' class = 'news_link news_title' (click) = "news()">Nouvelles</a>
  </div>
  <div class = 'activities'>
    <a href = '#!' class = 'news_link news_title' (click) = "activities()" >Activités</a>
  </div>
  <div *ngIf = 'this.newsIsClicked'>
    <news-table></news-table>
  </div>
  <div *ngIf = "!this.newsIsClicked">
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing
     elit, sed do eiusmod tempor incididunt ut labore et dolore
     magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation
      ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute
      irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
       fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,
       sunt in culpa qui officia deserunt mollit anim id est laborum.
    </p>
  </div>
  <br><br><hr>
  <p>© Polytechnique Montréal</p>
  <br>
  `,
})

export class AppComponent {

  private menuIsClicked: boolean;
  private newsIsClicked: boolean;
  private _update: number;
  private _index: number;
  private _source: string;
  private _text: string;
  private _searchActive: boolean;
  private _search_input: string;

  constructor() {
    this.menuIsClicked = false;
    this.newsIsClicked = true;
    this._update = setInterval(this.update.bind(this), 7 * 1000);
    this._index = 1;
    this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/groupeetudiants_0_0.jpg';
    this._text = 'Bienvenue à Poly!';
    this._searchActive = false;
    this._search_input = '';

    // On s'assure que l'élément est bel et bien créé pour éviter les erreurs
    setTimeout(() => document.getElementById('index' + this._index).focus(), 0);
  }

  menu() {
    if (this.menuIsClicked) {
      this.menuIsClicked = false;
    } else {
      this.menuIsClicked = true;
    }
  }

  news() {
    if (!this.newsIsClicked) {
      this.newsIsClicked = true;
    }
  }

  activities() {
    if (this.newsIsClicked) {
      this.newsIsClicked = false;
    }
  }

// Permet d'utiliser le moteur de recherche de la poly avec la barre de recherche
  search() {
    this._search_input =
      'http://www.polymtl.ca/rechercheg/index.php?cx=018433811494757532061:zui6ueem0go&cof=FORID:11&ie=iso-8859-1&num=20&q=' + this._search_input;
    }

// Permet de mettre à jour l'index permettant de changer d'une image à l'autre
  update() {
    ++this._index;
    if (this._index === 5) {
      this._index = 1;
    }

// Permet de mettre le focus sur le chiffre correspondant à la bonne image
    document.getElementById('index' + this._index).focus();
    if (this._index === 1) {
      this.setImage1();
    } else if (this._index === 2) {
      this.setImage2();
    } else if (this._index === 3) {
      this.setImage3();
    } else if (this._index === 4) {
      this.setImage4();
    }
  }

// Fonctions permettant de mettre à jour la source de l'image, l'index et le texte
  setImage1() {
    this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/groupeetudiants_0_0.jpg';
    this._index = 1;
    this._text = 'Bienvenue à Poly!';
  }

  setImage2() {
    this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/envedette_lesiaq.jpg';
    this._index = 2;
    this._text = 'Inauguration du LESIAQ';
  }

  setImage3() {
    this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/nanomartel_janvier17.jpg';
    this._index = 3;
    this._text = 'Québec Science : Sylvain Marcel';
  }

  setImage4() {
    this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/salonetusup11fevrier16.jpg';
    this._index = 4;
    this._text = 'Salon des études supérieures';
  }
}
