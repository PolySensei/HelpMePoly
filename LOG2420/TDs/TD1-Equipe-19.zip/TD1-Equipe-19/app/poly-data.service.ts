/**
 * poly-data.service.ts - Service pour lire et fournir les données aux composants
 *
 * @authors Mathieu KABORÉ
 * @date 2017/01/16
 */
import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PolyDataService {

  constructor(private http: Http) { }

  getListeNouvelles(): Promise<Object> {
    return this.http.get('../data/nouvelles.json')
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError);
  }

  getListeMenu(): Promise<Object> {
    return this.http.get('../data/menu.json')
      .toPromise()
      .then(response => response.json())
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}
