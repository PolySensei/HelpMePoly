"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var AppComponent = (function () {
    function AppComponent() {
        var _this = this;
        this.menuIsClicked = false;
        this.newsIsClicked = true;
        this._update = setInterval(this.update.bind(this), 7 * 1000);
        this._index = 1;
        this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/groupeetudiants_0_0.jpg';
        this._text = 'Bienvenue à Poly!';
        this._searchActive = false;
        this._search_input = '';
        // On s'assure que l'élément est bel et bien créé pour éviter les erreurs
        setTimeout(function () { return document.getElementById('index' + _this._index).focus(); }, 0);
    }
    AppComponent.prototype.menu = function () {
        if (this.menuIsClicked) {
            this.menuIsClicked = false;
        }
        else {
            this.menuIsClicked = true;
        }
    };
    AppComponent.prototype.news = function () {
        if (!this.newsIsClicked) {
            this.newsIsClicked = true;
        }
    };
    AppComponent.prototype.activities = function () {
        if (this.newsIsClicked) {
            this.newsIsClicked = false;
        }
    };
    // Permet d'utiliser le moteur de recherche de la poly avec la barre de recherche
    AppComponent.prototype.search = function () {
        this._search_input =
            'http://www.polymtl.ca/rechercheg/index.php?cx=018433811494757532061:zui6ueem0go&cof=FORID:11&ie=iso-8859-1&num=20&q=' + this._search_input;
    };
    // Permet de mettre à jour l'index permettant de changer d'une image à l'autre
    AppComponent.prototype.update = function () {
        ++this._index;
        if (this._index === 5) {
            this._index = 1;
        }
        // Permet de mettre le focus sur le chiffre correspondant à la bonne image
        document.getElementById('index' + this._index).focus();
        if (this._index === 1) {
            this.setImage1();
        }
        else if (this._index === 2) {
            this.setImage2();
        }
        else if (this._index === 3) {
            this.setImage3();
        }
        else if (this._index === 4) {
            this.setImage4();
        }
    };
    // Fonctions permettant de mettre à jour la source de l'image, l'index et le texte
    AppComponent.prototype.setImage1 = function () {
        this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/groupeetudiants_0_0.jpg';
        this._index = 1;
        this._text = 'Bienvenue à Poly!';
    };
    AppComponent.prototype.setImage2 = function () {
        this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/envedette_lesiaq.jpg';
        this._index = 2;
        this._text = 'Inauguration du LESIAQ';
    };
    AppComponent.prototype.setImage3 = function () {
        this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/nanomartel_janvier17.jpg';
        this._index = 3;
        this._text = 'Québec Science : Sylvain Marcel';
    };
    AppComponent.prototype.setImage4 = function () {
        this._source = 'http://www.polymtl.ca/sites/amigow.polymtl.ca/files/salonetusup11fevrier16.jpg';
        this._index = 4;
        this._text = 'Salon des études supérieures';
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: 'poly-app',
            template: "\n  <div class = \"header\">\n    <a href = \"/\" class = \"logo\">\n      <img src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/logo.png\">\n    </a>\n    <a href= \"#\" class = \"language-link\">ENGLISH</a>\n  </div>\n\n  <div class = \"media_header\">\n    <div class = \"media_header_left\">\n      <div class = \"media_header_left_component\">\n\n        <a href = \"http://www.facebook.com/polymtl\">\n          <img class = \"media_image\"\n            src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/fb-black.png\">\n        </a>\n        <a href = \"https://www.linkedin.com/company/ecole-polytechnique-de-montreal\">\n          <img class = \"media_image\"\n            src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/linkedin-black.png\">\n        </a>\n        <a href = \"https://www.instagram.com/polymtl/\">\n          <img class = \"media_image\"\n            src=\"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/instagram-black.png\">\n        </a>\n      </div>\n\n      <div class=\"media_header_left_component\">\n        <a href = \"http://www.polymtl.ca/carrefour-actualite/rss/rss_5.xml\">\n          <img class = \"media_image\" src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/rss-black.png\">\n        </a>\n        <a href = \"http://www.twitter.com/polymtl\">\n          <img class = \"media_image\"\n            src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/twitter-black.png\">\n        </a>\n        <a href = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ'>\n          <img class = \"media_image\"\n            src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/social-media/youtube-black.png\">\n        </a>\n      </div>\n    </div>\n\n    <div class = \"media_header_right\">\n      <div class = \"media_header_right_component\">\n        <a href = \"#!\" class = \"quick-link\">Liens rapides</a>\n        <a href = '{{this._search_input}}' (click) = \"search()\">\n          <img class = \"image_glass\" src = \"http://www.polymtl.ca/profiles/portail/themes/custom/bueno/images/ico-loupe.png\">\n        </a>\n        <div class = \"search_bar\">\n          <input type = \"text\" name = \"_search_input\" [(ngModel)] = \"_search_input\" />\n        </div>\n        <a href = '#!' class = \"menu-text\" (click) = \"menu()\">Menu</a>\n      </div>\n    </div>\n  </div>\n  <div *ngIf = 'this.menuIsClicked'>\n    <menu-items></menu-items>\n  </div>\n\n  <div class = \"image_students\">\n    <div class = \"images_text\">\n      <h5>{{this._text}}</h5>\n    </div>\n    <img src = {{this._source}} class = 'images'>\n    <div class = 'images_bar'>\n      <div class = 'numbers'>\n        <a href = '#!'class = 'number links' (click) = 'setImage1()' id = \"index1\">1</a>\n        <a href = '#!'class = 'number links' (click) = 'setImage2()' id = \"index2\">2</a>\n        <a href = '#!'class = 'number links' (click) = 'setImage3()' id = \"index3\">3</a>\n        <a href = '#!'class = 'number links' (click) = 'setImage4()' id = \"index4\">4</a>\n      </div>\n    </div>\n  </div>\n\n  <div class = \"footer\">\n    <h1>International</h1>\n    <p>Avec plus de 250 ententes universitaires et 24% d'\u00E9tudiants internationaux,\n     Polytechnique Montr\u00E9al est plus que jamais ouverte sur le monde.</p>\n    <a href = '#!' class = \"discoveries-link\">D\u00E9couvrez les possibilit\u00E9s</a>\n  </div>\n\n  <div class = 'news_container'>\n    <a href = '#!' class = 'news_link news_title' (click) = \"news()\">Nouvelles</a>\n  </div>\n  <div class = 'activities'>\n    <a href = '#!' class = 'news_link news_title' (click) = \"activities()\" >Activit\u00E9s</a>\n  </div>\n  <div *ngIf = 'this.newsIsClicked'>\n    <news-table></news-table>\n  </div>\n  <div *ngIf = \"!this.newsIsClicked\">\n    <p>Lorem ipsum dolor sit amet, consectetur adipisicing\n     elit, sed do eiusmod tempor incididunt ut labore et dolore\n     magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation\n      ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute\n      irure dolor in reprehenderit in voluptate velit esse cillum dolore eu\n       fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident,\n       sunt in culpa qui officia deserunt mollit anim id est laborum.\n    </p>\n  </div>\n  <br><br><hr>\n  <p>\u00A9 Polytechnique Montr\u00E9al</p>\n  <br>\n  ",
        }), 
        __metadata('design:paramtypes', [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map