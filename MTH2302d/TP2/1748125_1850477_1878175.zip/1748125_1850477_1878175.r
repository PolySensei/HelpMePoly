
data = read.csv("Joueur_de_football.csv", header = TRUE);

data


data$R.table = cut(data$R, breaks = c(0, 20, 40, 60, 80, 100, 120, 140), include.lowest = TRUE)
data$V.table = cut(data$V, breaks = c(0,400,800, 1200, 1600, 2000), include.lowest = TRUE)
data$P.table = cut(data$P, breaks = c(0,20,40, 60, 80, 100), include.lowest = TRUE)
data$L.table = cut(data$L, breaks = c(0,20,40, 60, 80, 100), include.lowest = TRUE)
data$T.table = cut(data$T, breaks = c(0,2,4,6,8,10,12,14,16), include.lowest = TRUE)
data$R20.table = cut(data$R20, breaks = c(0,5,10,15,20,25,30,35), include.lowest = TRUE)
data$R40.table = cut(data$R40, breaks = c(1,2,3,4,5,6,7), include.lowest = TRUE)
data$R1.table = cut(data$R1, breaks = c(15,30,45,60,75, 90,105), include.lowest = TRUE)
data$P1.table = cut(data$P1, breaks = c(0,20,40, 60, 80, 100), include.lowest = TRUE)
data$E.table = cut(data$E, breaks = c(0,1,2,3,4), include.lowest = TRUE)

table(data$R.table)
table(data$V.table)
table(data$P.table)
table(data$L.table)
table(data$T.table)
table(data$R20.table)
table(data$R40.table)
table(data$R1.table)
table(data$P1.table)
table(data$E.table)

chisq.test(table(data$R.table))
chisq.test(table(data$V.table))
chisq.test(table(data$P.table))
chisq.test(table(data$L.table))
chisq.test(table(data$T.table))
chisq.test(table(data$R20.table))
chisq.test(table(data$R40.table))
chisq.test(table(data$R1.table))
chisq.test(table(data$P1.table))
chisq.test(table(data$E.table))

error.R = qt(0.975,df=length(data$R)-1)*sd(data$R)/sqrt(length(data$R))
error.V = qt(0.975,df=length(data$V)-1)*sd(data$V)/sqrt(length(data$V))
error.P = qt(0.975,df=length(data$P)-1)*sd(data$P)/sqrt(length(data$P))
error.L = qt(0.975,df=length(data$L)-1)*sd(data$L)/sqrt(length(data$L))
error.T = qt(0.975,df=length(data$T)-1)*sd(data$T)/sqrt(length(data$T))
error.R20 = qt(0.975,df=length(data$R20)-1)*sd(data$R20)/sqrt(length(data$R20))
error.R40 = qt(0.975,df=length(data$R40)-1)*sd(data$R)/sqrt(length(data$R40))
error.R1 = qt(0.975,df=length(data$R1)-1)*sd(data$R1)/sqrt(length(data$R1))
error.P1 = qt(0.975,df=length(data$P1)-1)*sd(data$P1)/sqrt(length(data$P1))
error.E = qt(0.975,df=length(data$E)-1)*sd(data$E)/sqrt(length(data$E))

R = c(mean(data$R)-error.R,mean(data$R),mean(data$R)+error.R)
V = c(mean(data$V)-error.V,mean(data$V),mean(data$V)+error.V)
P = c(mean(data$P)-error.P,mean(data$P),mean(data$P)+error.P)
L = c(mean(data$L)-error.L,mean(data$L),mean(data$L)+error.L)
T = c(mean(data$T)-error.T,mean(data$T),mean(data$T)+error.T)
R20 = c(mean(data$R20)-error.R20,mean(data$R20),mean(data$R20)+error.R20)
R40 = c(mean(data$R40)-error.R40,mean(data$R40),mean(data$R40)+error.R40)
R1 = c(mean(data$R1)-error.R1,mean(data$R1),mean(data$R1)+error.R1)
P1 = c(mean(data$P1)-error.P1,mean(data$P1),mean(data$P1)+error.P1)
E = c(mean(data$E)-error.E,mean(data$E),mean(data$E)+error.E)
row.names = c("min", "moyenne","max")
column.names = c("R","V","P","L","T","R20","R40","R1","P1","E")
matrix.names = c("intervalle de confiance des differentes moyennes a 5%")
result = array(c(R,V,P,L,T,R20,R40,R1,P1,E),dim = c(3,10,1),dimnames = list(row.names,column.names,
   matrix.names))


print(result)


