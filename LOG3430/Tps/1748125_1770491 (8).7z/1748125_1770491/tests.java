package tests;
import static org.junit.Assert.*;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import edu.princeton.cs.algs4.Graph;
import edu.princeton.cs.algs4.GraphGenerator;
import org.junit.Test;

/** A class that contains a conception of unit tests to test the GraphGenerator class */

public class tests {

	@BeforeClass public static void testSetup()  {}
	@AfterClass public static void testCleanup() {}

	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the SIMPLE graph ---------------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test the too many edges case for the Simple graph
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleTooManyEdges() {
		int vertices = 5;
		int edges = 122;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
	}

	// Test the too few edges case for the Simple graph
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleTooFewEdges() {
		int vertices = 10;
		int edges = -1;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
	}

	// Test the case where we have negative number of vertices for the Simple graph
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleTooFewVertices() {
		int vertices = -15;
		int edges = 10;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
	}

	// Test the type, the vertices number and the edges number for the Simple graph
	@Test public void testSimpleGraphCreated() {	
		int vertices = 9;
		int edges = 10;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}

	// Test the limit cases of vertices number and edges number for the Simple graph
	@Test public void testSimpleGraphLimits() {	
		int vertices = 0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}

	/** ------------------------------------------------------------------------------------ */
	/** ------------------- Tests for the Simple graph with probability -------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test the case where the probability is negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleNegativeProbability() {
		int vertices = 8;
		double edges = -2.5;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
	}

	// Test the case where the probability is too high for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleProbabilityTooHigh() {
		int vertices = 6;
		double edges = 3.2;
		Graph graphToTest = GraphGenerator.simple(vertices, edges);
	}

	// Test the type, the vertices number and the edges number for Simple graph with probability
	@Test public void testSimpleGraphProbabilityCreated() {
		int vertices = 8;
		double probability = 0.4;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphProbabilityNegativeVertices() {	
		int vertices = -4;
		double probability = 3;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}

	// Test the  limit cases of probability for Simple graph with probability
	@Test public void testSimpleGraphProbabilityLimites() {	
		int vertices = 4;
		double probability = 0.0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
		
		vertices = 6;
		probability = 1.0;
		edges = 15;
		graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V());
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}

	/** -------------------------------------------------------------------------------------- */
	/** ---------------------------- Tests for the complete Graph ---------------------------- */
	/** -------------------------------------------------------------------------------------- */

	// Test the type and the number of vertices for complete Graph
	@Test public void testCompleteGraphCreated() {
		int vertices = 45;
		int edges = 990;
		Graph graphToTest = GraphGenerator.complete(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be complete", "complete", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is on its limit for complete Graph
	@Test public void testCompleteGraphLimits() {
		int vertices = 0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.complete(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be complete", "complete", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices negative for complete Graph
	@Test(expected = IllegalArgumentException.class)
	public void testCompleteGraphNegativeVertices() {
		int vertices = -6;
		Graph graphToTest = GraphGenerator.complete(vertices);
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------- Tests for the Graph completeBipartite ----------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test the type, the number of vertices and number of edges for completeBipartite Graph
	@Test public void testCompleteBipartiteCreated() {
		int verticesOne = 12;
		int verticesTwo = 10;
		int vertices = 22;
		int edges = 120;
		Graph graphToTest= GraphGenerator.completeBipartite(verticesOne,verticesTwo);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be completeBipartite", "completeBipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices are on their limits for completeBipartite Graph
	@Test public void testCompleteBipartiteLimits() {
		int verticesOne = 0;
		int verticesTwo = 0;
		int vertices = 0;
		int edges = 0;
		Graph graphToTest= GraphGenerator.completeBipartite(verticesOne,verticesTwo);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be completeBipartite", "completeBipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices are negative for completeBipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void testCompleteBipartiteNegativeVertices() {
		int verticesOne = -10;
		int verticesTwo = -10;
		Graph graphToTest= GraphGenerator.completeBipartite(verticesOne,verticesTwo);
	}

	/** --------------------------------------------------------------------------------------- */
	/** ---------------------------- Tests for the bipartite Graph ---------------------------- */
	/** --------------------------------------------------------------------------------------- */

	// Test the case where the number of edges is too many for bipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteTooManyEdges() {
		int verticesOne = 6;
		int verticesTwo = 10;
		int edges = 80;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
	}

	// Test the case where the number of edges is too few for bipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteTooFewEdges() {
		int verticesOne = 18;
		int verticesTwo = 6;
		int edges = -11;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
	}

	// Test the type, the vertices number and the edges number for bipartite Graph
	@Test public void testBipartiteCreated() {
		int verticesOne = 12;
		int verticesTwo = 10;
		int edges = 10;
		int vertices = 22;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V());
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices number and the edges number are on their limits for bipartite Graph
	@Test public void testBipartiteLimits() {
		int verticesOne = 0;
		int verticesTwo = 0;
		int vertices = 0;
		int edges = 0;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V());
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices numbers  are negative for bipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteNegativeVertices() {
		int verticesOne = -10;
		int verticesTwo = -100;
		int edges = 0;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
	}

	/** ------------------------------------------------------------------------------------------- */
	/** ------------------------ Tests for the Graph bipartite Probability ------------------------ */
	/** ------------------------------------------------------------------------------------------- */

	// Test the case where the probability is negative for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteNegativeProbability() {
		int verticesOne = 6;
		int verticesTwo = 10;
		double probability = -6.2;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the probability is too high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteTooHighProbability() {
		int verticesOne = 18;
		int verticesTwo = 6;
		double probability = 11.8;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the type and the number of vertices for bipartite Probability Graph
	@Test public void testBipartiteWithProbabilityCreated() {
		
		int verticesOne = 15;
		int verticesTwo = 27;
		double probability = 0.5;
		int vertices = 42;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices and the probability are on the limit for bipartite Probability Graph
	@Test public void testBipartiteWithProbabilityLimits() {
		
		int verticesOne = 0;
		int verticesTwo = 0;
		double probability = 0.0;
		int vertices = 0;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 	
		
		verticesOne = 4;
		verticesTwo = 10;
		probability = 1.0;
		vertices = 14;
		graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where vertices are negative for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartiteWithProbabilityNegativeVertices() {
		int verticesOne = -4;
		int verticesTwo = -10;
		double probability = 0.5;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	/** ---------------------------------------------------------------------------------- */
	/** ---------------------------- Tests for the Graph path ---------------------------- */
	/** ---------------------------------------------------------------------------------- */

	// Test type and the number of vertices for Graph path
	@Test public void testPathCreated() {
		int vertices = 23;
		int edges = 22;
		Graph graphToTest= GraphGenerator.path(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be path", "path", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is on the limit for Graph path
	@Test public void testPathLimits() {
		int vertices = 0;
		int edges = 0;
		Graph graphToTest= GraphGenerator.path(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be path", "path", graphToTest.getTypeName()); 
	}

	//Test the case where the number of vertices is negative for Graph path
	@Test(expected = IllegalArgumentException.class)
	public void testPathNegativeVertices() {
		int vertices = -6;
		Graph graphToTest= GraphGenerator.path(vertices);
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph binaryTree ------------------------ */
	/** ------------------------------------------------------------------------------------ */

	// Test type and the number of vertices for the Graph binaryTree
	@Test public void testBinaryTreeCreated() {	
		int vertices = 34;
		int edges = 33;
		Graph graphToTest= GraphGenerator.binaryTree(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be binaryTree", "binaryTree", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is on the limit for the Graph binaryTree
	@Test public void testBinaryTreeLimits() {	
		int vertices = 0;
		int edges = 0;
		Graph graphToTest= GraphGenerator.binaryTree(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be binaryTree", "binaryTree", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is negative for the Graph binaryTree
	@Test(expected = IllegalArgumentException.class)
	public void testBinaryTreeNegativeVertices() {	
		int vertices = -7;
		int edges = 0;
		Graph graphToTest= GraphGenerator.binaryTree(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V());
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be binaryTree", "binaryTree", graphToTest.getTypeName()); 
	}

	/** ----------------------------------------------------------------------------------- */
	/** ---------------------------- Tests for the Graph cycle ---------------------------- */
	/** ----------------------------------------------------------------------------------- */

	// Test type,the number of edges and the number of vertices for the Graph cycle
	@Test public void testCycleCreated() {
		int vertices = 25;
		int edges = 25;
		Graph graphToTest= GraphGenerator.cycle(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be cycle", "cycle", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is on the limit for the Graph cycle
	@Test public void testCycleLimits() {
		int vertices = 1;
		int edges = 1;
		Graph graphToTest= GraphGenerator.cycle(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be cycle", "cycle", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices is null for the Graph cycle
	@Test(expected = ArrayIndexOutOfBoundsException.class)
	public void testCycleNullVertices() {
		int vertices = 0;
		Graph graphToTest= GraphGenerator.cycle(vertices);
	}

	// Test the case where the number of vertices is negative for the Graph cycle
	@Test(expected = IllegalArgumentException.class)
	public void testCycleNegativeVertices() {
		int vertices = -2;
		Graph graphToTest= GraphGenerator.cycle(vertices);
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph EulerianCycle --------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test the case where the number of edges is negative for the Graph EulerianCycle
	@Test(expected = IllegalArgumentException.class)
	public void testEulerianCycleNegativeEdges() {
		int vertices= 6;
		int edges = -6;
		Graph graphToTest = GraphGenerator.eulerianCycle(vertices, edges);
	}

	// Test the case where the number of vertices is negative for the Graph EulerianCycle
	@Test(expected = IllegalArgumentException.class)
	public void testEulerianCycleNegativeVertices() {
		int vertices= -18;
		int edges = 6;
		Graph graphToTest = GraphGenerator.eulerianCycle(vertices, edges);
	}

	// Test the case where the number of vertices and the number of edges are null for the Graph EulerianCycle
	@Test(expected = IllegalArgumentException.class)
	public void testEulerianCycleNull() {
		int vertices= 0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.eulerianCycle(vertices, edges);
	}

	// Test the type, the number of vertices and the number of edges for the Graph EulerianCycle
	@Test public void testEulerianCycleCreated() {
		int vertices = 12;
		int edges = 20;
		Graph graphToTest= GraphGenerator.eulerianCycle(vertices, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be eulerianCycle", "eulerianCycle", graphToTest.getTypeName()); 
	}

	// Test the case where the number of vertices and the number of edges are in the limit for the Graph EulerianCycle
	@Test public void testEulerianCycleLimits() {
		int vertices = 1;
		int edges = 1;
		Graph graphToTest = GraphGenerator.eulerianCycle(vertices, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be eulerianCycle", "eulerianCycle", graphToTest.getTypeName()); 
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph eulerianPath ---------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test case where the edges are negative for Graph eulerianPath
	@Test(expected = IllegalArgumentException.class)
	public void testEulerianPathNegativeEdges() {
		int vertices = 6;
		int edges = -6;
		Graph graphToTest = GraphGenerator.eulerianPath(vertices, edges);
	}

	// Test case where the vertices are negative for Graph eulerianPath
	@Test(expected = IllegalArgumentException.class)
	public void testEulerianPathNegativeVertices() {
		int vertices = -18;
		int edges = 6;
		Graph graphToTest = GraphGenerator.eulerianPath(vertices, edges);
	}

	// Test the type, the number of vertices and the number of edges for the Graph eulerianPath
	@Test public void testEulerianPathCreated() {
		int vertices = 12;
		int edges = 20;
		Graph graphToTest= GraphGenerator.eulerianPath(vertices, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be eulerianPath", "eulerianPath", graphToTest.getTypeName()); 
	}

	//Test the case where the number of vertices and the number of edges are on the limit for the Graph eulerianPath
	@Test public void testEulerianPathLimit() {
		int vertices = 1;
		int edges = 0;
		Graph graphToTest= GraphGenerator.eulerianPath(vertices, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be eulerianPath", "eulerianPath", graphToTest.getTypeName()); 
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph wheel ----------------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test the case where the vertices are too few for the  wheel Graph
	@Test(expected = IllegalArgumentException.class)
	public void testWheelTooFewVertices() {
		int vertices = 1;
		Graph graphToTest = GraphGenerator.wheel(vertices);
	}

	// Test the type and the vertices for the wheel Graph
	@Test public void testWheelCreated() {	
		int vertices = 12;
		int edges = 22;
		Graph graphToTest= GraphGenerator.wheel(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be wheel", "wheel", graphToTest.getTypeName()); 
	}

	//Test the case where the vertices number is on the limit for the  wheel Graph
	@Test public void testWheelLimits() {	
		int vertices = 2;
		int edges = 2;
		Graph graphToTest= GraphGenerator.wheel(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be wheel", "wheel", graphToTest.getTypeName()); 
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph Star ------------------------------ */
	/** ------------------------------------------------------------------------------------ */

	// Test the case where the vertices are too few for the Star Graph
	@Test(expected = IllegalArgumentException.class)
	public void testStarTooFewVertices() {
		int vertices = -3;
		Graph graphToTest = GraphGenerator.star(vertices);
	}

	// Test the case where the vertices are too few for the Star Graph
	@Test(expected = IllegalArgumentException.class)
	public void testStarNullVertices() {
		int vertices = 0;
		Graph graphToTest = GraphGenerator.star(vertices);
	}
	
	// Test the type and the vertices for the Star Graph
	@Test public void testStarCreated() {
		int vertices = 16;
		int edges = 15;
		Graph graphToTest= GraphGenerator.star(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be star", "star", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices are in the limit for the Star Graph
	@Test public void testStarLimits() {
		int vertices = 1;
		int edges = 0;
		Graph graphToTest= GraphGenerator.star(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be star", "star", graphToTest.getTypeName()); 
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph regular --------------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test the case where the vertices*degree is not even for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularVerticesDegreeEven() {
		int vertices = 3;
		int degree = 1;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}

	//Test the type and the vertices for the regular Graph
	@Test public void testRegularCreated() {
		int vertices = 16;
		int degree = 16;
		int edges = 128;
		Graph graphToTest= GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices number is negative for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularNegativeVertices() {
		int vertices = -3;
		int degree = 2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}

	// Test the case where the degree number is negative for the regular Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testRegularNegativeDegree() {
		int vertices = 5;
		int degree = -2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}

	// Test the case where the degree number and the vertices number are on the limits for the regular Graph
	@Test public void testRegularLimits() {
		int vertices = 0;
		int degree = 0;
		int edges = 0;
		Graph graphToTest= GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph Tree ------------------------------ */
	/** ------------------------------------------------------------------------------------ */

	// Test type and the number of vertices for the Tree Graph
	@Test public void testTreeCreated() {
		int vertices = 28;
		int edges = 27;
		Graph graphToTest= GraphGenerator.tree(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be tree", "tree", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices number is on the limit for the Tree Graph
	@Test public void testTreeLimits() {
		int vertices = 1;
		int edges = 0;
		Graph graphToTest= GraphGenerator.tree(vertices);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be tree", "tree", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices number is null for the Tree Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testTreeNullVertices() {
		int vertices = 0;
		Graph graphToTest= GraphGenerator.tree(vertices);
	}

	// Test the case where the vertices number is negative for the Tree Graph
	@Test(expected = IllegalArgumentException.class)
	public void testTreeNegativeVertices() {
		int vertices = -3;
		Graph graphToTest= GraphGenerator.tree(vertices);
	}
	
	/** 	
	  					+-----------------+-----------------+--------------+
	  					| Test cases for the Simple graph with probability |
	  					+-----------------+-----------------+--------------+
							+-------------------+-------------------+
							|    VERTICES       |    PROBABILITY	|
							+-------------------+-------------------+
							|-1          	    |-1.0          		|
							+-------------------+-------------------+
							|0                  |0.0          		|
							+-------------------+-------------------+
							|5                  |0.5        		|
							+-------------------+-------------------+
							|Integer.MAX_VALUE  |1.0        		|
							+-------------------+-------------------+
							|1000               |2.0          		|
							+-------------------+-------------------+
	
						+-----------------+-----------------+--------------+
						|  Test cases for the Graph bipartite Probability  |
						+-----------------+-----------------+--------------+
					+-------------------+-------------------+-------------------+
					|    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|
					+-------------------+-------------------+-------------------+
					|-10          	    |0          		|0.5				|
					+-------------------+-------------------+-------------------+
					|Integer.MAX_VALUE  |-7          		|0.0				|
					+-------------------+-------------------+-------------------+
					|0                  |7        		    |1.0				|
					+-------------------+-------------------+-------------------+
					|10  				|70        			|2.0				|
					+-------------------+-------------------+-------------------+
					|100                |Integer.MAX_VALUE  |-3.0			    |
					+-------------------+-------------------+-------------------+

	
	  			  			 +-------------------+-------------------+
	  			  			 |   Test cases for the Graph regular    |
	  			  			 +-------------------+-------------------+
							 +-------------------+-------------------+
							 |    VERTICES       |    DEGREES		 |
							 +-------------------+-------------------+
							 |-5          	     |1          		 |
							 +-------------------+-------------------+
							 |Integer.MAX_VALUE  |0          		 |
							 +-------------------+-------------------+
							 |11                 |2          		 |
							 +-------------------+-------------------+
							 |10                 |-2        		 |
							 +-------------------+-------------------+
							 |5  				 |3        			 |
							 +-------------------+-------------------+
							 |0               	 |Integer.MAX_VALUE	 |
							 +-------------------+-------------------+				
	 */
	
	/** ------------------------------------------------------------------------------------ */
	/** -------------------------------- EACH CHOICE TESTS --------------------------------- */
	/** -------------------------------------------------------------------------------------*/
	
	/** ------------------------------------------------------------------------------------ */
	/** ------------------- Tests for the Simple graph with probability -------------------- */
	/** ------------------------------------------------------------------------------------ */
	/** 						
						+-------------------+-------------------+
	  			  		|  		    EACH CHOICE TESTS           |
	  			  		+-------------------+-------------------+
						+-------------------+-------------------+
						|    VERTICES       |    PROBABILITY	|
						+-------------------+-------------------+
						|-1          	    |-1.0          		|
						+-------------------+-------------------+
						|0                  |0.0          		|
						+-------------------+-------------------+
						|5                  |0.5        		|
						+-------------------+-------------------+
						|Integer.MAX_VALUE  |1.0        		|
						+-------------------+-------------------+
						|1000               |2.0          		|
						+-------------------+-------------------+
						
	*/

	// Test the case when vertices and probability are negative.
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityEC1() {
		int vertices = -1;
		double probability = -1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the type and the vertices number for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityEC2() {
		int vertices = 0;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}	
	
	// Test the type and the vertices number  for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityEC3() {
		int vertices = 5;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices number is very high for Simple graph with probability
	@Test(expected = OutOfMemoryError.class)
	public void testSimpleGraphWithProbabilityEC4() {
		int vertices = Integer.MAX_VALUE;
		double probability = 1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is too high for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityEC5() {
		int vertices = 1000;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	/** ------------------------------------------------------------------------------------------- */
	/** ------------------------ Tests for the Graph bipartite Probability ------------------------ */
	/** ------------------------------------------------------------------------------------------- */
	/** 			
			
				+-----------------+-----------------+--------------+
				|  				  EACH CHOICE TESTS  			   |
				+-----------------+-----------------+--------------+
			+-------------------+-------------------+-------------------+
			|    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|
			+-------------------+-------------------+-------------------+
			|-10          	    |0          		|0.5				|
			+-------------------+-------------------+-------------------+
			|Integer.MAX_VALUE  |-7          		|0.0				|
			+-------------------+-------------------+-------------------+
			|0                  |7        		    |1.0				|
			+-------------------+-------------------+-------------------+
			|10  				|70        			|2.0				|
			+-------------------+-------------------+-------------------+
			|100                |Integer.MAX_VALUE  |-3.0			    |
			+-------------------+-------------------+-------------------+
	 */
	
	// Test the case where the vertices number is negative for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartiteGraphWithProbabilityEC1() {
		int verticesOne = -10;
		int verticesTwo = 0;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices number is very high for bipartite Probability Graph
	@Test(expected = OutOfMemoryError.class)
	public void testBipartiteGraphWithProbabilityEC2() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = -7;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the number of vertices is 0 for bipartite Probability Graph
	@Test public void testBipartiteGraphWithProbabilityEC3() {		
		int verticesOne = 0;
		int verticesTwo = 7;
		double probability = 1.0;
		int vertices = 7;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the probability is greater than 1.0 for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteGraphWithProbabilityEC4() {
		int verticesOne = 10;
		int verticesTwo = 70;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	
	// Test the case where the probability is too low and the vertices number is too high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartiteGraphWithProbabilityEC5() {
		int verticesOne = 100;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph regular --------------------------- */
	/** ------------------------------------------------------------------------------------ */
	/** 						
						
						+-------------------+-------------------+
	  			  		|  		    EACH CHOICE TESTS           |
	  			  		+-------------------+-------------------+
						+-------------------+-------------------+
						|    VERTICES       |    DEGREES		|
						+-------------------+-------------------+
						|-5          	    |1          		|
						+-------------------+-------------------+
						|Integer.MAX_VALUE  |0          		|
						+-------------------+-------------------+
						|11                 |2          		|
						+-------------------+-------------------+
						|10                 |-2        			|
						+-------------------+-------------------+
						|5  				|3        			|
						+-------------------+-------------------+
						|0               	|Integer.MAX_VALUE	|
						+-------------------+-------------------+
	 */
	
	// Test the case where the vertices number is negative for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphEC1() {
		int vertices = -5;
		int degree = 1;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices number is too high and the degree is 0 for the regular Graph
	@Test(expected = OutOfMemoryError.class)
	public void testRegularGraphEC2() {
		int vertices = Integer.MAX_VALUE;
		int degree = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices*degree is even for the regular Graph
	@Test public void testRegularGraphEC3() {
		int vertices = 11;
		int degree = 2;
		int edges = 11;
		Graph graphToTest= GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the case where the degree is negative for the regular Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testRegularGraphEC4() {
		int vertices = 10;
		int degree = -2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices*degree is not even for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphEC5() {
		int vertices = 5;
		int degree = 3;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the degree is very high for the regular Graph
	@Test public void testRegularGraphEC6() {	
		int vertices = 0;
		int degree = Integer.MAX_VALUE;
		int edges = 0;
		Graph graphToTest= GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------  ALL CHOICES TESTS ------------------------------- */
	/** ------------------------------------------------------------------------------------ */
	
	/** ------------------------------------------------------------------------------------ */
	/** ------------------- Tests for the Simple graph with probability -------------------- */
	/** ------------------------------------------------------------------------------------ */
	/** 						
																										+-------------------+-------------------+
																										|  		    ALL CHOICES TESTS           |
																										+-------------------+-------------------+
		+-------------------+-------------------+		+-------------------+-------------------+		+-------------------+-------------------+		+-------------------+-------------------+		+-------------------+-------------------+
		|    VERTICES       |    PROBABILITY	|       |    VERTICES       |    PROBABILITY	|       |    VERTICES       |    PROBABILITY	|       |    VERTICES       |    PROBABILITY	|       |    VERTICES       |    PROBABILITY	|
		+-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+
		|-1          	    |-1.0          		|       |-1          	    |0.0           		|       |-1          	    |0.5          		|       |-1          	    |1.0         		|       |-1          	    |2.0          		|
		+-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+
		|0                  |-1.0          		|       |0                  |0.0          		|       |0                  |0.5          		|       |0                  |1.0          		|       |0                  |2.0          		|
		+-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+
		|5                  |-1.0        		|       |5                  |0.0         		|       |5                  |0.5        		|       |5                  |1.0        		|       |5                  |2.0        		|
		+-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+
		|Integer.MAX_VALUE  |-1.0       		|       |Integer.MAX_VALUE  |0.0         		|       |Integer.MAX_VALUE  |0.5        		|       |Integer.MAX_VALUE  |1.0        		|       |Integer.MAX_VALUE  |2.0        		|
		+-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+
		|1000               |-1.0         		|       |1000               |0.0           		|       |1000               |0.5          		|       |1000               |1.0         		|       |1000               |2.0          		|
		+-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+       +-------------------+-------------------+
	
*/
	
	// Test the case where the vertices number and the probability are negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC1() {
		int vertices = -1;
		double probability = -1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is negative and the probability is 0  for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC2() {
		int vertices = -1;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC3() {
		int vertices = -1;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is negative and the probability is in the limit for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC4() {
		int vertices = -1;
		double probability = 1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is negative and the probability is out of the limit for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC5() {
		int vertices = -1;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is 0 and the probability is negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC6() {
		int vertices = 0;
		double probability = -1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices number is 0 and the probability is 0 for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC7() {
		int vertices = 0;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices number is 0 for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC8() {
		int vertices = 0;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices number is 0 and the probability is in the limit for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC9() {
		int vertices = 0;
		double probability = 1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices number is 0 and the probability is out of the limit for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC10() {
		int vertices = 0;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where  the probability is negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC11() {
		int vertices = 5;
		double probability = -1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where  the probability is 0 for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC12() {
		int vertices = 5;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the type, and the vertices for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC13() {
		int vertices = 5;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the probability is at the limit for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC14() {
		int vertices = 5;
		double probability = 1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the probability is out of the limit for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC15() {
		int vertices = 5;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}

	// Test the case where the probability is negative and the vertices are very high for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC16() {
		int vertices = Integer.MAX_VALUE;
		double probability = -1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the probability is 0 and the vertices are very high for Simple graph with probability
	@Test(expected = OutOfMemoryError.class)
	public void testSimpleGraphWithProbabilityAC17() {
		int vertices = Integer.MAX_VALUE;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the vertices are very high for Simple graph with probability
	@Test(expected = OutOfMemoryError.class)
	public void testSimpleGraphWithProbabilityAC18() {
		int vertices = Integer.MAX_VALUE;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the probability is at the limit and the vertices are very high for Simple graph with probability
	@Test(expected = OutOfMemoryError.class)
	public void testSimpleGraphWithProbabilityAC19() {
		int vertices = Integer.MAX_VALUE;
		double probability = 1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the probability is out of the limit and the vertices are very high for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC20() {
		int vertices = Integer.MAX_VALUE;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	// Test the case where the probability is negative for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC21() {
		int vertices = 1000;
		double probability = -1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);

	}
	// Test the case where the probability is 0 for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC22() {
		int vertices = 1000;
		double probability = 0.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the type and the number of vertices for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC23() {
		int vertices = 1000;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the type and the number of vertices for Simple graph with probability
	@Test public void testSimpleGraphWithProbabilityAC24() {
		int vertices = 1000;
		double probability = 1.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be simple", "simple", graphToTest.getTypeName()); 
	}
	
	// Test the case where the probability is out of limit for Simple graph with probability
	@Test(expected = IllegalArgumentException.class)
	public void testSimpleGraphWithProbabilityAC25() {
		int vertices = 1000;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.simple(vertices, probability);
	}
	
	/** ------------------------------------------------------------------------------------------- */
	/** ------------------------ Tests for the Graph bipartite Probability ------------------------ */
	/** ------------------------------------------------------------------------------------------- */
	/** 			
			
				+-----------------+-----------------+--------------+
				|  	Tests for the Graph bipartite Probability      |
				+-----------------+-----------------+--------------+
			+-------------------+-------------------+-------------------+
			|    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|
			+-------------------+-------------------+-------------------+
			|-10          	    |-7          		|-3.0				|
			+-------------------+-------------------+-------------------+
			|10  				|7  				|0.5				|
			+-------------------+-------------------+-------------------+
			|Integer.MAX_VALUE  |Integer.MAX_VALUE  |2.0				|	
			+-------------------+-------------------+-------------------+
			
			
																					  +-----------------+-----------------+
																					  |  	ALL CHOICES TESTS      		  |
																					  +-----------------+-----------------+
			+-------------------+-------------------+-------------------+	+-------------------+-------------------+-------------------+	+-------------------+-------------------+-------------------+
			|    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|   |    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|   |    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|-10          	    |-7          		|-3.0				|   |-10          	    |7         			|-3.0				|   |-10          	    |Integer.MAX_VALUE  |-3					|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|-10  				|-7         		|0.5				|   |-10  				|7          		|0.5				|   |-10  				|Integer.MAX_VALUE  |0.5				|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|-10                |-7       		    |2.0				|   |-10                |7        		    |2.0				|   |-10  				|Integer.MAX_VALUE  |2.0				|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			
			
			+-------------------+-------------------+-------------------+	+-------------------+-------------------+-------------------+	+-------------------+-------------------+-------------------+
			|    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|   |    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|   |    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|10          	    |-7          		|-3.0				|   |10          	    |7         			|-3.0				|   |10          	    |Integer.MAX_VALUE  |-3					|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|10  				|-7         		|0.5				|   |10  				|7          		|0.5				|   |10  				|Integer.MAX_VALUE  |0.5				|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|10                	|-7       		    |2.0				|   |10                 |7        		    |2.0				|   |10  				|Integer.MAX_VALUE  |2.0				|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			
			+-------------------+-------------------+-------------------+	+-------------------+-------------------+-------------------+	+-------------------+-------------------+-------------------+
			|    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|   |    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|   |    VERTICES_ONE   |    VERTICES-TWO	|	PROBABILITY		|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|Integer.MAX_VALUE  |-7          		|-3.0				|   |Integer.MAX_VALUE  |7         			|-3.0				|   |Integer.MAX_VALUE  |Integer.MAX_VALUE  |-3					|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|Integer.MAX_VALUE  |-7         		|0.5				|   |Integer.MAX_VALUE  |7          		|0.5				|   |Integer.MAX_VALUE  |Integer.MAX_VALUE  |0.5				|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+
			|Integer.MAX_VALUE  |-7       		    |2.0				|   |Integer.MAX_VALUE  |7        		    |2.0				|   |Integer.MAX_VALUE  |Integer.MAX_VALUE  |2.0				|
			+-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+   +-------------------+-------------------+-------------------+

	 */
	 
	// Test the case where the probability and the vertices are negative for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC1() {
		int verticesOne = -10;
		int verticesTwo = -7;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are negative for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartitegraphWithProbabilityAC2() {
		int verticesOne = -10;
		int verticesTwo = -7;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the vertices are negative for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC3() {
		int verticesOne = -10;
		int verticesTwo = -7;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability and the vertices are negative for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC4() {
		int verticesOne = -10;
		int verticesTwo = 7;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are negative for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartitegraphWithProbabilityAC5() {
		int verticesOne = -10;
		int verticesTwo = 7;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the vertices are negative and the probability is out of the limit for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC6() {
		int verticesOne = -10;
		int verticesTwo = 7;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is negative and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC7() {
		int verticesOne = -10;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are very high for bipartite Probability Graph
	@Test(expected = OutOfMemoryError.class)
	public void testBipartitegraphWithProbabilityAC8() {
		int verticesOne = -10;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the vertices are very high and the probability is out of range for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC9() {
		int verticesOne = -10;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the vertices are negative and the probability is out of range for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC10() {
		int verticesOne = 10;
		int verticesTwo = -7;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are negative for bipartite Probability Graph
	@Test public void testBipartitegraphWithProbabilityAC11() {
		int verticesOne = 10;
		int verticesTwo = -7;
		double probability = 0.5;
		int vertices = 3;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices are negative and the probability is out of range for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC12() {
		int verticesOne = 10;
		int verticesTwo = -7;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is out of range for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC13() {
		int verticesOne = 10;
		int verticesTwo = 7;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the type and the vertices number for bipartite Probability Graph
	@Test public void testBipartitegraphWithProbabilityAC14() {
		int verticesOne = 10;
		int verticesTwo = 7;
		double probability = 0.5;
		int vertices = 17;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}
	
	// Test the case where the probability is out of range for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC15() {
		int verticesOne = 10;
		int verticesTwo = 7;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is out of range and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC16() {
		int verticesOne = 10;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are very high for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartitegraphWithProbabilityAC17() {
		int verticesOne = 10;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is out of range and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC18() {
		int verticesOne = 10;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability and the vertices are negative for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC19() {
		int verticesOne = 10;
		int verticesTwo = -7;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the probability is negative and the vertices are very high for bipartite Probability Graph
	@Test(expected = OutOfMemoryError.class)
	public void testBipartitegraphWithProbabilityAC20() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = -7;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is out of range and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC21() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = -7;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is negative and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC22() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = 7;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are very high for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartitegraphWithProbabilityAC23() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = 7;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is out of range and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC24() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = 7;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is negative and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC25() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = -3.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}

	// Test the case where the vertices are very high for bipartite Probability Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testBipartitegraphWithProbabilityAC26() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = 0.5;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	// Test the case where the probability is out of range and the vertices are very high for bipartite Probability Graph
	@Test(expected = IllegalArgumentException.class)
	public void testBipartitegraphWithProbabilityAC27() {
		int verticesOne = Integer.MAX_VALUE;
		int verticesTwo = Integer.MAX_VALUE;
		double probability = 2.0;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, probability);
	}
	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for the Graph regular --------------------------- */
	/** ------------------------------------------------------------------------------------ */
	/** 						
						
						+-------------------+-------------------+
	  			  		|  	  Tests for the Graph regular       |
	  			  		+-------------------+-------------------+
						+-------------------+-------------------+
						|    VERTICES       |    DEGREES		|
						+-------------------+-------------------+
						|-5          	    |1          		|
						+-------------------+-------------------+
						|Integer.MAX_VALUE  |0          		|
						+-------------------+-------------------+
						|11                 |2          		|
						+-------------------+-------------------+
						|10               	|-2					|
						+-------------------+-------------------+
						|0               	|3					|
						+-------------------+-------------------+
						
																												+-------------------+-------------------+
																												|  		    ALL CHOICES TESTS           |
																												+-------------------+-------------------+
						+-------------------+-------------------+	+-------------------+-------------------+	+-------------------+-------------------+	+-------------------+-------------------+	+-------------------+-------------------+	
						|    VERTICES       |    DEGREES		|   |    VERTICES       |    DEGREES		|   |    VERTICES       |    DEGREES		|   |    VERTICES       |    DEGREES		|   |    VERTICES       |    DEGREES		|
						+-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+
						|-5          	    |1          		|   |-5          	    |0          		|   |-5          	    |2          		|   |-5          	    |-2          		|   |-5          	    |3          		|
						+-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+
						|Integer.MAX_VALUE  |1          		|   |Integer.MAX_VALUE  |0          		|   |Integer.MAX_VALUE  |2          		|   |Integer.MAX_VALUE  |-2          		|   |Integer.MAX_VALUE  |3          		|
						+-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+
						|11                 |1          		|   |11                 |0          		|   |11                 |2          		|   |11                 |-2          		|   |11                 |3          		|
						+-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+
						|10               	|1					|   |10               	|0					|   |10               	|2					|   |10               	|-2					|   |10               	|3					|
						+-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+
						|0               	|1					|   |0               	|0					|   |0               	|2					|   |0               	|-2					|   |0               	|3					|
						+-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+   +-------------------+-------------------+

	 */

	// Test the case where the vertices are negative for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC1() {
		int vertices = -5;
		int degree = 1;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are negative and the degree is 0 for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC2() {
		int vertices = -5;
		int degree = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are negative for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC3() {
		int vertices = -5;
		int degree = 2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices and the degree are negative for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC4() {
		int vertices = -5;
		int degree = -2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are negative for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC5() {
		int vertices = -5;
		int degree = 3;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are very high for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC6() {
		int vertices = Integer.MAX_VALUE;
		int degree = 1;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are very high and the degree is 0 for the regular Graph
	@Test(expected = OutOfMemoryError.class)
	public void testRegularGraphAC7() {
		int vertices = Integer.MAX_VALUE;
		int degree = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are very high for the regular Graph
	@Test(expected = OutOfMemoryError.class)
	public void testRegularGraphAC8() {
		int vertices = Integer.MAX_VALUE;
		int degree = 2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are very high and the degree is negative for the regular Graph
	@Test(expected = OutOfMemoryError.class)
	public void testRegularGraphAC9() {
		int vertices = Integer.MAX_VALUE;
		int degree = -2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices are very high for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC10() {
		int vertices = Integer.MAX_VALUE;
		int degree = 3;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices*degree is not even for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC11() {
		int vertices = 11;
		int degree = 1;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}

	// Test the case where the degree is 0 for the regular Graph
	@Test public void testRegularGraphAC12() {
		int vertices = 11;
		int degree = 0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the type, the vertices and the degree for the regular Graph
	@Test public void testRegularGraphAC13() {
		int vertices = 11;
		int degree = 2;
		int edges = 11;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the case where the degree is negative for the regular Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testRegularGraphAC14() {
		int vertices = 11;
		int degree = -2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices*degree is not even for the regular Graph
	@Test(expected = IllegalArgumentException.class)
	public void testRegularGraphAC15() {
		int vertices = 11;
		int degree = 3;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the type, the vertices and the degree for the regular Graph
	@Test public void testRegularGraphAC16() {
		int vertices = 10;
		int degree = 1;
		int edges = 5;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}

	// Test the case where the degree is 0 for the regular Graph
	@Test public void testRegularGraphAC17() {
		int vertices = 10;
		int degree = 0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the type, the vertices and the degree for the regular Graph
	@Test public void testRegularGraphAC18() {
		int vertices = 10;
		int degree = 2;
		int edges = 10;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}

	// Test the case where the degree is negative for the regular Graph
	@Test(expected = NegativeArraySizeException.class)
	public void testRegularGraphAC19() {
		int vertices = 10;
		int degree = -2;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
	}
	
	// Test the case where the vertices*degree is even for the regular Graph
	@Test public void testRegularGraphAC20() {
		int vertices = 10;
		int degree = 3;
		int edges = 15;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices are 0 for the regular Graph
	@Test public void testRegularGraphAC21() {
		int vertices = 0;
		int degree = 1;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices and the degree are 0 for the regular Graph
	@Test public void testRegularGraphAC22() {
		int vertices = 0;
		int degree = 0;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices are 0 for the regular Graph
	@Test public void testRegularGraphAC23() {
		int vertices = 0;
		int degree = 2;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices are 0 and the degree is negative for the regular Graph
	@Test public void testRegularGraphAC24() {
		int vertices = 0;
		int degree = -2;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
	
	// Test the case where the vertices are 0 for the regular Graph
	@Test public void testRegularGraphAC25() {
		int vertices = 0;
		int degree = 3;
		int edges = 0;
		Graph graphToTest = GraphGenerator.regular(vertices, degree);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V()); 
		assertEquals("Edges must be "+edges, edges, graphToTest.E());
		assertEquals("Type name must be regular", "regular", graphToTest.getTypeName()); 
	}
}