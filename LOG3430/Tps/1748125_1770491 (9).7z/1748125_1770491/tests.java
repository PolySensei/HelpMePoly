package tests;
import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdRandom;

import org.junit.Test;

/** A class that contains a conception of unit tests to test the GraphGenerator class */

public class tests {

	@BeforeClass public static void testSetup()  {}
	@AfterClass public static void testCleanup() {}

	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------- Tests for QUEUE ---------------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test Queue constructor
	@Test public void TestQueueConstructor() {
		Queue queue =new Queue();
		assertEquals("n must be 0", 0, queue.size()); 
	}
	
	// Test isEmpty() method
	@Test public void TestisEmpty() {
		Queue queue =new Queue();
		assertEquals("return value of isempty() must be true", true, queue.isEmpty()); 
	}
	
	// Test isEmpty() method
	@Test public void Testsize() {
		Queue queue =new Queue();
		assertEquals("return value of size() must be 0", 0, queue.size()); 
		queue.enqueue(1);
		assertEquals("return value of size() must be 1", 1, queue.size()); 
	}
	
	// Test peek() method With Empty Queue
	@Test(expected = NoSuchElementException.class)
	public void TestPeekWithEmptyQueue() {
		Queue queue =new Queue();
		queue.peek();
	}
	
	// Test peek() method With full Queue
	@Test public void TestPeekWithFullQueue() {
		Queue queue =new Queue();
		queue.enqueue(1);
		assertEquals("return value of peek() must be 1", 1, queue.peek());
		assertEquals("return value of size() must be 1", 1, queue.size());
	}
	
	
	// Test enqueue() method With empty Queue
	@Test public void TestEnqueueWithEmptyQueue() {
		Queue queue =new Queue();
		queue.enqueue(11);
		assertEquals("return value of peek() must be 11", 11, queue.peek());
		assertEquals("return value of size() must be 1", 1, queue.size());
	}
	
	// Test enqueue() method With full Queue
	@Test public void TestEnqueueWithFullQueue() {
		Queue queue =new Queue();
		queue.enqueue(11);
		queue.enqueue(23);
		queue.enqueue(15);
		assertEquals("return value of peek() must be 11", 11, queue.peek());
		assertEquals("return value of size() must be 3", 3, queue.size());
	}
	
	// Test dequeue() method With empty Queue
	@Test(expected = NoSuchElementException.class)
	public void TestDequeueWithEmptyQueue() {
		Queue queue =new Queue();
		queue.dequeue();
	}
	
	// Test dequeue() method With full Queue
	@Test public void TestDequeueWithFullQueue() {
		Queue queue =new Queue();
		queue.enqueue(11);
		queue.enqueue(19);
		assertEquals("return value of dequeue() must be 11", 11, queue.dequeue());
		assertEquals("return value of size() must be 1", 1, queue.size());
	}
	
	// Test dequeue() method With just one item in Queue
	@Test public void TestDequeueWithOnlyOneItemInQueue() {
		Queue queue =new Queue();
		queue.enqueue(11);
		assertEquals("return value of dequeue() must be 11", 11, queue.dequeue());
		assertEquals("return value of size() must be 0", 0, queue.size());
	}
	
	// Test toString() method With full Queue
	@Test public void TestToString() {
		Queue queue =new Queue();
		queue.enqueue(11);		
		queue.enqueue(13);

		assertEquals("return value of toString() must be '11 13'", "11 13 ", queue.toString());
	}
}