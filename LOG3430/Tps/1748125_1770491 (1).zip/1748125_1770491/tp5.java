package tp5;
import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdRandom;

/** A class that contains a conception of unit tests to test the QUEUE class */

public class tp5 {

	@BeforeClass public static void testSetup()  {}
	@AfterClass public static void testCleanup() {}

	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------- Tests for QUEUE --------------------------------- */
	/** ------------------------------------------------------------------------------------ */
	/**
											   +-----------------+-----------------+--------------+
											   |              MaDUM of the class Queue            |
											   +-----------------+-----------------+--------------+
					
	+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+
	|         *         |      Queue()     	|	  isEmpty()		|	    size()		|	    peek()		|	  enqueue()		|	  dequeue()		|	  toString()	|
	+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+
	|first        	    |C          		|O		    		|   				|O	    			|T   				|T      			|O      			|
	+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+
	|last               |C          		|   				|   				|   				|T      			|T      			|O      			|
	+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+
	|n                  |C        		    |   				|R  				|   				|T   				|T   				|O  				|
	+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+-------------------+

	*/

	
	/** ---------------------------------- Tests sequences for the slice first --------------------------------- */
	/**
								  +-----------------+-----------------+--------------+
								  |       Tests sequences for the slice first      	 |
								  +-----------------+-----------------+--------------+
					
	  			  	+-------------------+-------------------+-------------------+-------------------+
					|Queue()     	    |euqueue()		    |dequeue()		    |peek()		        |
					+-------------------+-------------------+-------------------+-------------------+
					|Queue()          	|euqueue()		    |peek()   			|	    			|
					+-------------------+-------------------+-------------------+-------------------+
					|Queue()          	|euqueue()   		|isEmpty() 			|   				|
					+-------------------+-------------------+-------------------+-------------------+
					|Queue()        	|euqueue()   		|dequeue()  		|isEmpty()			|
					+-------------------+-------------------+-------------------+-------------------+
					|Queue()      		|euqueue()   		|dequeue()  		|toString()		    |
					+-------------------+-------------------+-------------------+-------------------+
	*/
	
	// Test Queue() enqueue() dequeue() peek() sequence for the attribute first .
	@Test(expected = NoSuchElementException.class)
	public void firstTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(11);
		queue.dequeue();
		queue.peek();
	}
	
	// Test Queue()	enqueue() peek() sequence for the attribute first .
	@Test public void secondTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(11);
		queue.peek();
		assertEquals("peek must be 11", 11, queue.peek());
		assertEquals("first.item  must be 11", 11, queue.getFirst()); 
		assertEquals("last.item must be 11", 11, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
	}
	
	// Test Queue()	enqueue() isEmpty() sequence for the attribute first .
	@Test public void thirdTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(13);
		queue.isEmpty();
		assertEquals("peek must be 13", 13, queue.peek());
		assertEquals("first.item  must be 13", 13, queue.getFirst()); 
		assertEquals("last.item must be 13", 13, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
		assertEquals("isEmpty must be false", false, queue.isEmpty()); 
	}
	
	// Test Queue()	enqueue() dequeue() isEmpty() sequence for the attribute first .
	@Test public void fourthTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(13);
		queue.dequeue();
		queue.isEmpty();
		assertEquals("first.item  must be null", null, queue.getFirst()); 
		assertEquals("last.item must be null", null, queue.getLast()); 
		assertEquals("n must be 0", 0, queue.size()); 
		assertEquals("isEmpty must be true", true, queue.isEmpty()); 
	}
	
	// Test Queue()	enqueue() enqueue() toString() sequence for the attribute first .
	@Test public void fifthTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(13);
		queue.enqueue(15);
		assertEquals("peek must be 13", 13, queue.peek());
		assertEquals("first.item  must be 13", 13, queue.getFirst()); 
		assertEquals("last.item must be 15", 15, queue.getLast()); 
		assertEquals("n must be 2", 2, queue.size()); 
		assertEquals("toString must be '13 15'", "13 15 ", queue.toString()); 
	}
	

	/** ---------------------------------- Tests sequences for the slice last --------------------------------- */
	/**
								+-----------------+-----------------+--------------+
								|        Tests sequences for the slice last        |
								+-----------------+-----------------+--------------+
					
	  			  	+-------------------+-------------------+-------------------+-------------------+
					|Queue()     	    |euqueue()		    |dequeue()		    |toString()		    |
					+-------------------+-------------------+-------------------+-------------------+
					|Queue()          	|euqueue()		    |toString()   		|	    			|
					+-------------------+-------------------+-------------------+-------------------+
					|Queue()          	|dequeue()   		|toString() 		|   				|
					+-------------------+-------------------+-------------------+-------------------+
	*/

	// Test Queue()	enqueue() dequeue()	toString() sequence for the attribute last .
	@Test public void firstTestSequence_last() {
		Queue queue = new Queue();
		queue.enqueue(17);
		queue.dequeue();
		assertEquals("first.item  must be null", null, queue.getFirst()); 
		assertEquals("last.item must be null", null, queue.getLast()); 
		assertEquals("n must be 0", 0, queue.size()); 
		assertEquals("toString must be ''", "", queue.toString()); 
	}
	
	// Test Queue()	enqueue() toString() sequence for the attribute last .
	@Test public void secondTestSequence_last() {
		Queue queue = new Queue();
		queue.enqueue(19);
		assertEquals("peek must be 19", 19, queue.peek());
		assertEquals("first.item  must be 19", 19, queue.getFirst()); 
		assertEquals("last.item must be 19", 19, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
		assertEquals("toString must be '19 '", "19 ", queue.toString()); 
	}
	
	// Test Queue()	dequeue() toString() sequence for the attribute last .
	@Test(expected = NoSuchElementException.class)
	public void thirdTestSequence_last() {
		Queue queue = new Queue();
		queue.dequeue();
		queue.toString();
	}

	
	/** ---------------------------------- Tests sequences for the slice n --------------------------------- */
	/**
													+-----------------+-----------------+--------------+
													|      	   Tests sequences for the slice n         |
													+-----------------+-----------------+--------------+
					
	+-------------------+-----------+---------------+-----------+-------------------+-------------------+-------------------+-------------------+-----------+
	|Queue()     	    |size()		|enqueue()		|size()		|dequeue()		    |toString()		    |size()		        |    		        |   		|
	+-------------------+-----------+---------------+-----------+-------------------+-------------------+-------------------+-------------------+-----------+
	|Queue()          	|size()		|enqueue()   	|size()		|enqueue()   	    |toString()   	    |size()		        |       	        |	    	|
	+-------------------+-----------+---------------+-----------+-------------------+-------------------+-------------------+-------------------+-----------+
	|Queue()          	|size()   	|enqueue() 		|size()   	|enqueue() 			|size() 			|   		        |        		    |   	    |
	+-------------------+-----------+---------------+-----------+-------------------+-------------------+-------------------+-------------------+-----------+
	|Queue()        	|size()   	|enqueue()  	|size()   	|enqueue()  		|size()  		    |toString()		    |dequeue()  	    |size()   	|
	+-------------------+-----------+---------------+-----------+-------------------+-------------------+-------------------+-------------------+-----------+	
	*/
	
	// Test Queue()	size() enqueue() size() dequeue() toString() Size() sequence for the attribute n .
	@Test public void firstTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.enqueue(21);
		queue.size();
		queue.dequeue();
		queue.toString();
		queue.size();
		assertEquals("first.item  must be null", null, queue.getFirst()); 
		assertEquals("last.item must be null", null, queue.getLast()); 
		assertEquals("n must be 0", 0, queue.size()); 
		assertEquals("toString must be ''", "", queue.toString()); 
	}
	
	// Test Queue()	size()	dequeue() size() enqueue() toString() size() sequence for the attribute n .
	@Test(expected = NoSuchElementException.class)
	public void secondTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.dequeue();
		queue.size();
		queue.enqueue(21);
		queue.toString();
		queue.size();
	}
	
	// Test Queue()	size()	enqueue() size() enqueue() size() sequence for the attribute n .
	@Test public void thirdTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.enqueue(23);
		queue.size();
		queue.enqueue(39);
		queue.size();
		assertEquals("peek must be 23", 23, queue.peek());
		assertEquals("first.item  must be 23", 23, queue.getFirst()); 
		assertEquals("last.item must be 39", 39, queue.getLast()); 
		assertEquals("n must be 2", 2, queue.size()); 
		assertEquals("toString must be '23 39 '", "23 39 ", queue.toString()); 
	}
	
	// Test Queue()	size()	enqueue() size() enqueue() size() toString() dequeue() size() sequence for the attribute n .
	@Test public void fourTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.enqueue(23);
		queue.size();
		queue.enqueue(39);
		queue.size();
		queue.toString();
		queue.dequeue();
		queue.size();
		assertEquals("peek must be 39", 39, queue.peek());
		assertEquals("first.item  must be 39", 39, queue.getFirst()); 
		assertEquals("last.item must be 39", 39, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
		assertEquals("toString must be '39 '", "39 ", queue.toString()); 
	}
}