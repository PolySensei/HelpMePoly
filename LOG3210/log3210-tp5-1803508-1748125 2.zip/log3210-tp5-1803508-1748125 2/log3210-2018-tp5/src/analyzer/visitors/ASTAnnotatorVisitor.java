package analyzer.visitors;

import analyzer.ast.*;

import java.util.HashSet;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class ASTAnnotatorVisitor implements ParserVisitor
{

    // TODO:: Est-ce que l'on aurait besoin d'un objet pour encapsuler plus d'information ou seulement une string est suffisante?
    HashSet<Object> m_nodes = new HashSet<Object>();
    HashSet<Object> m_leafs = new HashSet<Object>();
    HashSet<Object> m_links = new HashSet<Object>();
    HashSet<String> variables = new HashSet<String>();
    HashSet<String> usefulVariables = new HashSet<String>();

    List<SimpleNode> nodes = new ArrayList<SimpleNode>();
    HashSet<Object> varVive = new HashSet<Object>();
    Integer numberOfStatements = 0;

    private final PrintWriter m_writer;

    public ASTAnnotatorVisitor(PrintWriter writer) {
        m_writer = writer;
    }

    // TODO:: Présentement data est inutilisée, pouvez-vous vous en servir pour autre chose?

    // Paramètre data: On ne transmet rien aux enfants
    // Valeur de retour: On ne retourne rien aux parents
    public Object visit(SimpleNode node, Object data) {
        return null;
    }

    // Paramètre data: On ne transmet rien aux enfants
    // Valeur de retour: On ne retourne rien aux parents
    public Object visit(ASTProgram node, Object data) {

        node.childrenAccept(this, null);

        return null;
    }


    public Object visit(ASTBlock node, Object data) {
        node.childrenAccept(this, null);
        for(int i = nodes.size()-1; i > 0; i--){
            // A = B + C
            // SI A est une variable vive OU B/C sont des variables utilisées dans le calcul de A
            if(varVive.contains(nodes.get(i).getVarDefinie()) || usefulVariables.contains(nodes.get(i).getVarDefinie())){
              if(!usefulVariables.contains(nodes.get(i).getOperationGauche())){
                  usefulVariables.add(nodes.get(i).getOperationGauche());
              }
              if(!usefulVariables.contains(nodes.get(i).getOperationDroite())){
                  usefulVariables.add(nodes.get(i).getOperationDroite());
              }
            } else {
                nodes.get(i).setEstMort(true);
            }
        }

        return null;
    }


    public Object visit(ASTLive node, Object data) {
        node.childrenAccept(this, null);
        // Ajouter tous les variables vives initiales
        for(int i =0; i<node.getLive().size(); i++){
            varVive.add(node.getLive().get(i));
        }
        return null;
    }


    public Object visit(ASTStmt node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }


    public Object visit(ASTAssignStmt node, Object data) {
         // Assigner le numero de l'instruction au node
        ((SimpleNode)node).setInstructionNumber(numberOfStatements + 1);
        numberOfStatements++;

        // Assigner les variables
        String assigned = (String)node.jjtGetChild(0).jjtAccept(this, null);
        String left = (String)node.jjtGetChild(1).jjtAccept(this, null);
        String right = (String)node.jjtGetChild(2).jjtAccept(this, null);

        // assigned = left (operateur) right
        ((SimpleNode)node).setVarDefinie(assigned);
        ((SimpleNode)node).setOperationGauche(left);
        ((SimpleNode)node).setOperateur(node.getOp());
        ((SimpleNode)node).setOperationDroite(right);

        if(!variables.contains(assigned)){
            variables.add(assigned);
        }
        if(!variables.contains(left)){
            variables.add(left);
        }
        if(!variables.contains(right)){
            variables.add(right);
        }

        // On sauvegarde le node
        nodes.add((SimpleNode)node);

        int lastDef = -1;
        int lastUsed = -1;
        for(int i =0; i<nodes.size()-1; i++){
            // SI A = B + C
            //    D = B + C
            // OU D = C + B

            if((nodes.get(i).getOperationGauche() + nodes.get(i).getOperateur() + nodes.get(i).getOperationDroite()).equals(((SimpleNode)node).getOperationGauche() + ((SimpleNode)node).getOperateur() + ((SimpleNode)node).getOperationDroite())
                     ||
                    (nodes.get(i).getOperationGauche() + nodes.get(i).getOperateur() + nodes.get(i).getOperationDroite()).equals(((SimpleNode)node).getOperationDroite() + ((SimpleNode)node).getOperateur() + ((SimpleNode)node).getOperationGauche())

                    ){
                // SI variable pas redefinie
                for(int j = 0; j<=i; j++) {
                    if(nodes.get(j).getVarDefinie() != ((SimpleNode)node).getOperationGauche() && nodes.get(j).getVarDefinie() != ((SimpleNode)node).getOperationDroite()){
                        // SI A = A
                        if(nodes.get(j).getVarDefinie().equals(((SimpleNode)node).getVarDefinie())){
                            ((SimpleNode)node).setEstMort(true);
                        } else {
                            ((SimpleNode) node).setEstIdentique(true);
                            ((SimpleNode) node).setVarRedef(nodes.get(i).getVarDefinie());
                        }
                    }
                }
            }

            // Derniere definition
            if(nodes.get(i).getVarDefinie().equals(node.getVarDefinie())){
                if(nodes.get(i).getInstructionNumber() > lastDef) {
                    lastDef = nodes.get(i).getInstructionNumber();
                }
            }

            // Derniere utilisation
            if(nodes.get(i).getOperationGauche().equals(node.getVarDefinie()) || nodes.get(i).getOperationDroite().equals(node.getVarDefinie())){
                if(nodes.get(i).getInstructionNumber() > lastUsed) {
                    lastUsed = nodes.get(i).getInstructionNumber();
                }
            }
        }

        // SI
        if(lastUsed < lastDef) {
            nodes.get(lastDef - 1).setEstMort(true);
        }


        return null;
    }


    public Object visit(ASTAssignUnaryStmt node, Object data) {
        // Assigner le numero de l'instruction au node
        ((SimpleNode)node).setInstructionNumber(numberOfStatements + 1);
        numberOfStatements++;

        // Assigner les variables
        String assigned = (String)node.jjtGetChild(0).jjtAccept(this, null);
        String left = (String)node.jjtGetChild(1).jjtAccept(this, null);
        String right = null;

        // assigned = left (operateur) right
        ((SimpleNode)node).setVarDefinie(assigned);
        ((SimpleNode)node).setOperationGauche(left);
        ((SimpleNode)node).setOperationDroite(right);

        if(!variables.contains(assigned)){
            variables.add(assigned);
        }
        if(!variables.contains(left)){
            variables.add(left);
        }
        if(!variables.contains(right)){
            variables.add(right);
        }

        // On sauvegarde le node
        nodes.add((SimpleNode)node);

        int lastDef = -1;
        int lastUsed = -1;
        for(int i =0; i<nodes.size()-1; i++){
            // SI A = B + C
            //    D = B + C
            // OU D = C + B

            if((nodes.get(i).getOperationGauche() + nodes.get(i).getOperateur() + nodes.get(i).getOperationDroite()).equals(((SimpleNode)node).getOperationGauche() + ((SimpleNode)node).getOperateur() + ((SimpleNode)node).getOperationDroite())
                    ||
                    (nodes.get(i).getOperationGauche() + nodes.get(i).getOperateur() + nodes.get(i).getOperationDroite()).equals(((SimpleNode)node).getOperationDroite() + ((SimpleNode)node).getOperateur() + ((SimpleNode)node).getOperationGauche())

                    ){
                // SI variable pas redefinie
                for(int j = 0; j<=i; j++) {
                    if(nodes.get(j).getVarDefinie() != ((SimpleNode)node).getOperationGauche() && nodes.get(j).getVarDefinie() != ((SimpleNode)node).getOperationDroite()){
                        // SI A = A
                        if(nodes.get(j).getVarDefinie().equals(((SimpleNode)node).getVarDefinie())){
                            ((SimpleNode)node).setEstMort(true);
                        } else {
                            ((SimpleNode) node).setEstIdentique(true);
                            ((SimpleNode) node).setVarRedef(nodes.get(i).getVarDefinie());
                        }
                    }
                }
            }

            // Derniere definition
            if(nodes.get(i).getVarDefinie().equals(node.getVarDefinie())){
                if(nodes.get(i).getInstructionNumber() > lastDef) {
                    lastDef = nodes.get(i).getInstructionNumber();
                }
            }

            // Derniere utilisation
            if(nodes.get(i).getOperationGauche().equals(node.getVarDefinie()) || nodes.get(i).getOperationDroite().equals(node.getVarDefinie())){
                if(nodes.get(i).getInstructionNumber() > lastUsed) {
                    lastUsed = nodes.get(i).getInstructionNumber();
                }
            }
        }

        // SI
        if(lastUsed < lastDef) {
            nodes.get(lastDef - 1).setEstMort(true);
        }


        return null;
    }


    public Object visit(ASTAssignDirectStmt node, Object data) {
        // Assigner le numero de l'instruction au node
        ((SimpleNode)node).setInstructionNumber(numberOfStatements + 1);
        numberOfStatements++;

        // Assigner les variables
        String assigned = (String)node.jjtGetChild(0).jjtAccept(this, null);
        String left = (String)node.jjtGetChild(1).jjtAccept(this, null);
        String right = null;

        // assigned = left (operateur) right
        ((SimpleNode)node).setVarDefinie(assigned);
        ((SimpleNode)node).setOperationGauche(left);
        ((SimpleNode)node).setOperationDroite(right);

        if(!variables.contains(assigned)){
            variables.add(assigned);
        }
        if(!variables.contains(left)){
            variables.add(left);
        }
        if(!variables.contains(right)){
            variables.add(right);
        }

        // On sauvegarde le node
        nodes.add((SimpleNode)node);

        int lastDef = -1;
        int lastUsed = -1;
        for(int i =0; i<nodes.size()-1; i++){
            // SI A = B + C
            //    D = B + C
            // OU D = C + B

            if((nodes.get(i).getOperationGauche() + nodes.get(i).getOperateur() + nodes.get(i).getOperationDroite()).equals(((SimpleNode)node).getOperationGauche() + ((SimpleNode)node).getOperateur() + ((SimpleNode)node).getOperationDroite())
                    ||
                    (nodes.get(i).getOperationGauche() + nodes.get(i).getOperateur() + nodes.get(i).getOperationDroite()).equals(((SimpleNode)node).getOperationDroite() + ((SimpleNode)node).getOperateur() + ((SimpleNode)node).getOperationGauche())

                    ){
                // SI variable pas redefinie
                for(int j = 0; j<=i; j++) {
                    if(nodes.get(j).getVarDefinie() != ((SimpleNode)node).getOperationGauche() && nodes.get(j).getVarDefinie() != ((SimpleNode)node).getOperationDroite()){
                        // SI A = A
                        if(nodes.get(j).getVarDefinie().equals(((SimpleNode)node).getVarDefinie())){
                            ((SimpleNode)node).setEstMort(true);
                        } else {
                            ((SimpleNode) node).setEstIdentique(true);
                            ((SimpleNode) node).setVarRedef(nodes.get(i).getVarDefinie());
                        }
                    }
                }
            }

            // Derniere definition
            if(nodes.get(i).getVarDefinie().equals(node.getVarDefinie())){
                if(nodes.get(i).getInstructionNumber() > lastDef) {
                    lastDef = nodes.get(i).getInstructionNumber();
                }
            }

            // Derniere utilisation
            if(nodes.get(i).getOperationGauche().equals(node.getVarDefinie()) || nodes.get(i).getOperationDroite().equals(node.getVarDefinie())){
                if(nodes.get(i).getInstructionNumber() > lastUsed) {
                    lastUsed = nodes.get(i).getInstructionNumber();
                }
            }
        }

        // SI
        if(lastUsed < lastDef) {
            nodes.get(lastDef - 1).setEstMort(true);
        }
        return null;
    }


    public Object visit(ASTExpr node, Object data) {
        return node.jjtGetChild(0).jjtAccept(this, null);
    }


    public Object visit(ASTIntValue node, Object data) {
        return String.valueOf(node.getValue());
    }


    public Object visit(ASTIdentifier node, Object data) {
        return node.getValue();
    }

}
