package analyzer.visitors;

import analyzer.ast.*;

import java.io.PrintWriter;

public class ForStmtVisitor implements ParserVisitor {

    private final PrintWriter m_writer;
    private int m_currentNumber = 0;

    public ForStmtVisitor(PrintWriter writer) {
        m_writer = writer;
    }

    @Override
    public Object visit(SimpleNode node, Object data) {
        return null;
    }

    @Override
    public Object visit(ASTProgram node, Object data) {
        // STARTS HERE
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        assignNumber(node);
        return null;
    }

    @Override
    public Object visit(ASTBlock node, Object data) {
        node.childrenAccept(this, null);
        assignNumber(node);
        return null;
    }

    @Override
    public Object visit(ASTStmt node, Object data) {
        if (node.jjtGetChild(0).getClass() == ASTIntAssignStmt.class ||
                node.jjtGetChild(0).getClass() == ASTFloatAssignStmt.class ||
                node.jjtGetChild(0).getClass() == ASTArrayAssignStmt.class ||
                node.jjtGetChild(0).getClass() == ASTForStmt.class) {
            node.jjtGetChild(0).jjtAccept(this, null);
            return null;
        } else {
            throw new RuntimeException("Unexpected child");
        }
        //assignNumber(node)
    }

    @Override
    public Object visit(ASTIntAssignStmt node, Object data) {
        assignNumber(node);
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTFloatAssignStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTArrayAssignStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTForStmt node, Object data) {
        Node arriereGrandParent = node.jjtGetParent().jjtGetParent().jjtGetParent();
        if(arriereGrandParent.getClass() == ASTForStmt.class){
            ASTForStmt forArriereGrandParent = ((ASTForStmt)arriereGrandParent);
            node.setImbrication(forArriereGrandParent.getImbrication() + 1);
        }
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        if(arriereGrandParent.getClass() == ASTForStmt.class) {
            printForExpr((ASTForStmt)arriereGrandParent);
            ((ASTForStmt)arriereGrandParent).setAlreadyPrinted(true);
            printForExpr(node);
            node.setAlreadyPrinted(true);
        } else if(node.getAlreadyPrinted() == false){
            printForExpr(node);
        }
        return null;
    }

    public void printForExpr(ASTForStmt node){
        m_writer.print("FOR : " + node.getImbrication() + ", ");
        m_writer.print(node.getTableauParcouru() + ", ");
        m_writer.print(((ASTProgram)getAncester(node, ASTProgram.class)).getVariablesGlobales() + ", ");
        m_writer.print(node.getvariableLocaleAss() + ", ");
        m_writer.print(node.getVariablesLocalesDef() + ", ");
        m_writer.print(node.getVariablesRedefinies() + ", ");
        m_writer.print(node.getVariablesRequises() + ", ");
        if(node.getTailleTableauModifie() == false) {
            m_writer.print("False, ");
        } else {
            m_writer.print("True, ");
        }
        if(node.getVariableLocaleDejaDef() == false) {
            m_writer.print("False;\n");
        } else {
            m_writer.print("True;\n");
        }
    }

    public Node getAncester(Node node, Class myClass){
        Node temp = node;
        while(temp.jjtGetParent().getClass() != myClass) {
            temp = temp.jjtGetParent();
        }
        return temp.jjtGetParent();
    }

    public Node getAncesterByNumber(Node node, Integer number){
        Node temp = node;
        for(int i=0; i < number; i++){
            temp = temp.jjtGetParent();
        }
        return temp;
    }

    @Override
    public Object visit(ASTExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }



    @Override
    public Object visit(ASTIntAddExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTIntMultExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }


    @Override
    public Object visit(ASTIntUnaryOpExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTIntBasicExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTFloatAddExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTFloatMultExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }


    @Override
    public Object visit(ASTFloatUnaryOpExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTFloatBasicExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }



    @Override
    public Object visit(ASTArrayContExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTArrayRepExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }


    @Override
    public Object visit(ASTArrayInvExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }


    @Override
    public Object visit(ASTArrayBasicExpr node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTArrayAccess node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTFctStmt node, Object data) {
        for (int i = 0; i < node.jjtGetNumChildren(); i++) {
            node.jjtGetChild(i).jjtAccept(this, null);
        }
        return null;
    }

    @Override
    public Object visit(ASTIdentifier node, Object data) {
        Node parent = node.jjtGetParent();
        Node ancetreQuatre = getAncesterByNumber(node, 4);
        if(parent.getClass() == ASTArrayBasicExpr.class){
            Node ancetre = getAncesterByNumber(node, 5);
            if(ancetre.getClass() == ASTForStmt.class) {
                ((ASTForStmt)ancetre).setTableauParcouru(node.getValue());
            }
        } else if (parent.getClass() == ASTForStmt.class) {
            if(getAncesterByNumber(node, 4).getClass() == ASTProgram.class){
                if (((ASTProgram)getAncesterByNumber(node,4)).getVariablesGlobales().contains(node.getValue())) {
                    ((ASTForStmt)parent).setVariableLocaleDejaDef(true);
                }
            }
            ((ASTForStmt)parent).setvariableLocaleAss(node.getValue());
        } else if (ancetreQuatre.getClass() == ASTProgram.class){
            ((ASTProgram)ancetreQuatre).setVariablesGlobales(node.getValue());
        } else if (node.jjtGetParent().getClass() == ASTArrayAssignStmt.class ||
                node.jjtGetParent().getClass() == ASTFloatAssignStmt.class ||
                node.jjtGetParent().getClass() == ASTIntAssignStmt.class) {
            if (ancetreQuatre.getClass() == ASTForStmt.class) {
                if(((ASTForStmt)ancetreQuatre).getvariableLocaleAss().equals(node.getValue())){
                    ((ASTForStmt)ancetreQuatre).addVariableRedefinies(((ASTForStmt)ancetreQuatre).getTableauParcouru());
                } else {
                    ((ASTForStmt)ancetreQuatre).addVariableRedefinies(node.getValue());
                }
            }

        } else if(getAncesterByNumber(node, 5).getClass()==ASTForStmt.class){
            if(ancetreQuatre.getClass()==ASTIntAddExpr.class || ancetreQuatre.getClass()==ASTFloatAddExpr.class ||
                    ancetreQuatre.getClass()==ASTArrayContExpr.class) {
                ((ASTForStmt)getAncesterByNumber(node, 5)).addVariableRequise(node.getValue());
            }
        }


        return null;
    }

    @Override
    public Object visit(ASTIntValue node, Object data) {
        assignNumber(node);
        return null;
    }

    @Override
    public Object visit(ASTRealValue node, Object data) {
        assignNumber(node);
        return null;
    }

    @Override
    public Object visit(ASTArrayValue node, Object data) {
        assignNumber(node);
        return null;
    }


    private void assignNumber(SimpleNode node) {
        node.setNumber(m_currentNumber);
        m_currentNumber++;
    }
}
