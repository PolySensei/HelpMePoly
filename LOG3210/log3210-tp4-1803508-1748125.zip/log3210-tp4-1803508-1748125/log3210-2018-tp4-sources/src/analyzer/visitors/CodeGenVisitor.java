package analyzer.visitors;

import analyzer.ast.*;
import sun.misc.resources.Messages_de;

import java.io.PrintWriter;

public class CodeGenVisitor implements ParserVisitor {

    private final PrintWriter m_writer;
    private Integer numberOfTemps = 1;

    public CodeGenVisitor(PrintWriter writer) {
        m_writer = writer;
    }

    @Override
    public Object visit(SimpleNode node, Object data) {
        return data;
    }



    @Override
    public Object visit(ASTProgram node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTBlock node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTStmt node, Object data) {
        node.childrenAccept(this, null);
        m_writer.print("\n\n");
        return null;
    }

    @Override
    public Object visit(ASTIntAssignStmt node, Object data) {
        node.jjtGetChild(0).jjtAccept(this, null);
        m_writer.print("=");
        node.jjtGetChild(1).jjtAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTFloatAssignStmt node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTArrayAssignStmt node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTForStmt node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }



    @Override
    public Object visit(ASTExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }



    @Override
    public Object visit(ASTIntAddExpr node, Object data) {
        node.childrenAccept(this, null);
        m_writer.print(node.jjtGetValue());
        return null;
    }

    @Override
    public Object visit(ASTIntMultExpr node, Object data) {
        node.childrenAccept(this, null);
        for(int i=0; i<node.jjtGetNumChildren() - 1; i++){
            if (node.jjtGetNumChildren() > 2) {
                m_writer.print("\n");
                m_writer.print("t" + numberOfTemps.toString() + " = ");
                numberOfTemps++;
                node.jjtGetChild(i).jjtAccept(this, null);
                m_writer.print(node.jjtGetValue());
                m_writer.print(" * ");
                node.jjtGetChild(i+1).jjtAccept(this, null);
                m_writer.print(node.jjtGetValue());
                m_writer.print("\n");
            }
        }
        if(node.jjtGetParent().getClass() == ASTIntAddExpr.class) {
            ((ASTIntAddExpr)node.jjtGetParent()).jjtSetValue(node.jjtGetValue());
        }
        return null;
    }


    @Override
    public Object visit(ASTIntUnaryOpExpr node, Object data) {
        node.childrenAccept(this, null);
        if(node.jjtGetParent().getClass() == ASTIntMultExpr.class) {
            ((ASTIntMultExpr)node.jjtGetParent()).jjtSetValue(node.jjtGetValue());
        }
        return null;
    }

    @Override
    public Object visit(ASTIntBasicExpr node, Object data) {
        node.childrenAccept(this, null);
        if(node.jjtGetParent().getClass() == ASTIntUnaryOpExpr.class) {
            ((ASTIntUnaryOpExpr)node.jjtGetParent()).jjtSetValue(node.jjtGetValue());
        }
        return null;
    }

    @Override
    public Object visit(ASTFloatAddExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTFloatMultExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }


    @Override
    public Object visit(ASTFloatUnaryOpExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTFloatBasicExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }



    @Override
    public Object visit(ASTArrayContExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTArrayRepExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }


    @Override
    public Object visit(ASTArrayInvExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }


    @Override
    public Object visit(ASTArrayBasicExpr node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }

    @Override
    public Object visit(ASTArrayAccess node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }



    @Override
    public Object visit(ASTIdentifier node, Object data) {
        node.childrenAccept(this, null);

        m_writer.print(node.getValue());
        return null;
    }

    @Override
    public Object visit(ASTIntValue node, Object data) {
        node.childrenAccept(this, null);
        if(node.jjtGetParent().getClass() == ASTIntBasicExpr.class) {
            ((ASTIntBasicExpr)node.jjtGetParent()).jjtSetValue(node.getValue());
        }
        //m_writer.print(node.getValue());
        return null;
    }

    @Override
    public Object visit(ASTRealValue node, Object data) {
        node.childrenAccept(this, null);
        //m_writer.print(node.getValue());
        return null;
    }

    @Override
    public Object visit(ASTArrayValue node, Object data) {
        node.childrenAccept(this, null);
        return null;
    }


}
