t=*[0.0,1.0,3.0];
t2=*t|~(t|(2#[0.0,4.0]));
z=.0.0;
for e in t do{
    for e2 in t2 do{
        z=.e*.e2;
    }
}