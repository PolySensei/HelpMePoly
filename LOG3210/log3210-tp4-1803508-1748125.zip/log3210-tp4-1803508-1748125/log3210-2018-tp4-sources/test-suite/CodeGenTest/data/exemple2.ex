n=100;
t=*n#[0.0];
t2=*n#[0.0];
q=.0.9;
qn=q;

for e in t do{
    e=.qn;
    qn=.qn*.q;
}

qn=q;

for e2 in t2 do{
    e2=.1.0-.qn;
    qn=.qn*.q;
}