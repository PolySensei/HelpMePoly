e=a*b*c*d;
a=5;
b=2;
c=4;
d=a+b+2*c-b*(c-5);
f=a+b+c+d+e;
