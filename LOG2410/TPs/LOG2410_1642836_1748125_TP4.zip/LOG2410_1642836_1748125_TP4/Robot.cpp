#include "Robot.h"
#include "CmdAbs.h"

void Robot::executerProgramme(CmdAbs * programme)
{
	programme->executer(*this);
}

void Robot::prendrePhoto(void) 
{ 
	m_camera.prendrePhoto();
}

int Robot::getNbPhotos(void)
{
	return m_camera.getNbPhotos(); 
}

void Robot::changerResolution(int dimX, int dimY) 
{ 
	m_camera.changerResolution(dimX, dimY);
}

void Robot::changerSensibilite(int sensib) 
{ 
	m_camera.changerSensibilite(sensib);
}

void Robot::activerFlash(void) 
{ 
	m_camera.activerFlash();
}

void Robot::desactiverFlash(void)
{
	m_camera.desactiverFlash();
}

CameraAbs::Resolution_type Robot::getMemoireRestante(void) 
{ 
	return m_camera.getMemoireRestante(); 
}

int Robot::getChargeRestante(void) const
{
	return m_camera.getChargeRestante(); 
}

void Robot::getResolution(int & dimX, int & dimY) 
{ 
	m_camera.getResolution(dimX, dimY);
}

int Robot::getSensibilite(void) 
{ 
	return m_camera.getSensibilite(); 
}

bool Robot::getActivationFlash(void) 
{ 
	return m_camera.getActivationFlash(); 
}

void Robot::changerOrientationAbsolue(double longitude, double latitude)
{
	m_longitude = longitude;
	m_latitude = latitude;
}

void Robot::changerOrientationRelative(double incLongitude, double incLatitude)
{
	m_longitude + incLongitude;
	m_latitude + incLatitude;
}

void Robot::getOrientation(double & longitude, double & latitude) const
{
	longitude = m_longitude;
	latitude = m_latitude;
}
