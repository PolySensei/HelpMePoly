#include "VisiteurCalcOrientation.h"
#include "CmdBoucleFor.h"
#include "CmdOrienterRobot.h"
#include "CmdPrendrePhoto.h"
#include "CmdTournerRobot.h"

VisiteurCalcOrientation::VisiteurCalcOrientation(void)
	: m_longitude(0.0), m_latitude(0.0)
{
}

void VisiteurCalcOrientation::traiterCmdBoucleFor(CmdBoucleFor & cmd)
{
	for (int i = 0; i < cmd.getNumberChildren(); i++) {
		for(int j = 0; j < cmd.getNbRepetitions(); j++) {
			cmd.getChild(i)->accepterVisiteur(*this);
		}
	}
}

void VisiteurCalcOrientation::traiterCmdOrienterRobot(CmdOrienterRobot & cmd)
{
	m_longitude += cmd.getLongitude();
	m_latitude += cmd.getLatitude();
}

void VisiteurCalcOrientation::traiterCmdPrendrePhoto(CmdPrendrePhoto & cmd)
{
	
}

void VisiteurCalcOrientation::traiterCmdTournerRobot(CmdTournerRobot & cmd)
{
	m_longitude += cmd.getIncLongitude();
	m_latitude += cmd.getIncLatitude();
}

double VisiteurCalcOrientation::getLongitude(void) const
{
	return m_longitude; 
}

double VisiteurCalcOrientation::getLatitude(void) const
{
	return m_latitude; 
}
