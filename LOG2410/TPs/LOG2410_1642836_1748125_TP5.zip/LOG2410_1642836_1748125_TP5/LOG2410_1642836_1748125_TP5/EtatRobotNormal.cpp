#include "EtatRobotNormal.h"
#include "CmdAbs.h"

void EtatRobotNormal::executerProgramme(CmdAbs * programme)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		programme->executer(m_robot);
	}
}

void EtatRobotNormal::prendrePhoto(void) 
{ 
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.prendrePhoto();
	}
}

void EtatRobotNormal::changerResolution(int dimX, int dimY) 
{ 
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.changerResolution(dimX, dimY);
	}
}

void EtatRobotNormal::changerSensibilite(int sensib) 
{ 
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.changerSensibilite(sensib);
	}
}

void EtatRobotNormal::activerFlash(void) 
{ 
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.activerFlash();
	}
}

void EtatRobotNormal::desactiverFlash(void) 
{ 
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.desactiverFlash();
	}
}

void EtatRobotNormal::changerOrientationAbsolue(double longitude, double latitude)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		changerLongitudeLatitude(longitude, latitude);
	}
}

void EtatRobotNormal::changerOrientationRelative(double incLongitude, double incLatitude)
{
	double longitude;
	double latitude;
	m_robot.getOrientation(longitude, latitude);

	if (m_robot.verifierEtat() == ResultatTest::succes) {
		changerLongitudeLatitude(incLongitude + longitude, incLatitude+ latitude);
	}
}
