#include <iostream>

#include "VisiteurGenCPP.h"
#include "CmdBoucleFor.h"
#include "CmdOrienterRobot.h"
#include "CmdPrendrePhoto.h"
#include "CmdTournerRobot.h"

using namespace std;

void VisiteurGenCPP::genererIndentation(void)
{
	for (int i = 0; i < m_indent; ++i)
		std::cout << "\t";
}

VisiteurGenCPP::VisiteurGenCPP(std::string nomRobot) 
	: m_indent(0), m_nomRobot(nomRobot)
{
}

void VisiteurGenCPP::traiterCmdBoucleFor(CmdBoucleFor & cmd)
{
	cout << "for (int i" << m_indent << "= 0; i" << m_indent << " < " << cmd.getNumberChildren() << "; ++i" << m_indent << " )" << endl;
	genererIndentation();
	cout << "{" << endl;
	
	m_indent++;
	
	
	for (int i = 0; i < cmd.getNumberChildren(); i++) {
		genererIndentation();
		cmd.getChild(i)->accepterVisiteur(*this);
		
	}
	m_indent--;
	genererIndentation();
	cout << "}" << endl;
	
}

void VisiteurGenCPP::traiterCmdOrienterRobot(CmdOrienterRobot & cmd)
{
	cout << m_nomRobot << "." << "changerOrientationAbsolue(" << cmd.getLongitude() << ", " << cmd.getLatitude() << ");" << endl;
}

void VisiteurGenCPP::traiterCmdPrendrePhoto(CmdPrendrePhoto & cmd)
{
	cout << m_nomRobot << "." << "prendrePhoto();" << endl;
}

void VisiteurGenCPP::traiterCmdTournerRobot(CmdTournerRobot & cmd)
{
	cout << m_nomRobot << "." << "tournerRobot(" << cmd.getIncLongitude() << ", " << cmd.getIncLatitude() << ");" << endl;
}
