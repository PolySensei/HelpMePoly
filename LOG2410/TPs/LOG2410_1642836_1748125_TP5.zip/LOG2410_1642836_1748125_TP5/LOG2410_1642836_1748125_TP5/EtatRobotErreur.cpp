
#include <iostream>

#include "EtatRobotErreur.h"
#include "CmdAbs.h"

void EtatRobotErreur::executerProgramme(CmdAbs * programme)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		programme->executer(m_robot);
	}
}

void EtatRobotErreur::prendrePhoto(void)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.prendrePhoto();
	}
}

void EtatRobotErreur::changerResolution(int dimX, int dimY)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.changerResolution(dimX, dimY);
	}
}

void EtatRobotErreur::changerSensibilite(int sensib)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.changerSensibilite(sensib);
	}
}

void EtatRobotErreur::activerFlash(void)
{
	if (m_robot.verifierEtat() == ResultatTest::succes) {
		m_camera.activerFlash();
	}
}

void EtatRobotErreur::desactiverFlash(void)
{
	if (m_robot.verifierEtat() == ResultatTest::echec) {
		m_camera.desactiverFlash();
	}
}

void EtatRobotErreur::changerOrientationAbsolue(double longitude, double latitude)
{

	if (m_robot.verifierEtat() == ResultatTest::succes) {
		changerLongitudeLatitude(longitude, latitude);
	}
}

void EtatRobotErreur::changerOrientationRelative(double incLongitude, double incLatitude)
{
	double longitude;
	double latitude;
	m_robot.getOrientation(longitude, latitude);

	if (m_robot.verifierEtat() == ResultatTest::succes) {
		changerLongitudeLatitude(incLongitude + longitude, incLatitude + latitude);
	}
}
