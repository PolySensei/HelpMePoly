import java.awt.Color;
import java.awt.PageAttributes.ColorType;

/**
 * Classe PixelMapPlus
 * Image de type noir et blanc, tons de gris ou couleurs
 * Peut lire et ecrire des fichiers PNM
 * Implemente les methodes de ImageOperations
 * @author : 
 * @date   : 
 */

public class PixelMapPlus extends PixelMap implements ImageOperations 
{
	/**
	 * Constructeur creant l'image a partir d'un fichier
	 * @param fileName : Nom du fichier image
	 */
	PixelMapPlus(String fileName)
	{
		super( fileName );
	}
	
	/**
	 * Constructeur copie
	 * @param type : type de l'image a creer (BW/Gray/Color)
	 * @param image : source
	 */
	PixelMapPlus(PixelMap image)
	{
		super(image); 
	}
	
	/**
	 * Constructeur copie (sert a changer de format)
	 * @param type : type de l'image a creer (BW/Gray/Color)
	 * @param image : source
	 */
	PixelMapPlus(ImageType type, PixelMap image)
	{
		super(type, image); 
	}
	
	/**
	 * Constructeur servant a allouer la memoire de l'image
	 * @param type : type d'image (BW/Gray/Color)
	 * @param h : hauteur (height) de l'image 
	 * @param w : largeur (width) de l'image
	 */
	PixelMapPlus(ImageType type, int h, int w)
	{
		super(type, h, w);
	}
	
	/**
	 * Genere le negatif d'une image
	 */
	public void negate()
	{
		for (int i = 0; i < this.height; i++)
		{
			for(int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = this.imageData[i][j].Negative();
			}
		}
	}
	
	/**
	 * Convertit l'image vers une image en noir et blanc
	 */
	public void convertToBWImage()
	{
		// compl�ter
		AbstractPixel[][] copie = imageData;
		AllocateMemory(ImageType.BW, height, width);
		
		for (int i = 0; i < this.height; i++)
		{
			for(int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = copie[i][j].toBWPixel();
			}
		}
	}
	
	/**
	 * Convertit l'image vers un format de tons de gris
	 */
	public void convertToGrayImage()
	{
		// compl�ter
		AbstractPixel[][] copie = imageData;
		AllocateMemory(ImageType.Gray, height, width);
		
		for (int i = 0; i < this.height; i++)
		{
			for(int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = copie[i][j].toGrayPixel();
			}
		}
		
		this.imageType = ImageType.Gray;
	}
	
	/**
	 * Convertit l'image vers une image en couleurs
	 */
	public void convertToColorImage()
	{
		// compl�ter
		AbstractPixel[][] copie = imageData;
		AllocateMemory(ImageType.Color, height, width);
		
		for (int i = 0; i < this.height; i++)
		{
			for(int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = copie[i][j].toColorPixel();
			}
		}
		
		this.imageType = ImageType.Color;
	}
	
	public void convertToTransparentImage()
	{
		// compl�ter
		AbstractPixel[][] copie = imageData;
		AllocateMemory(ImageType.Transparent, height, width);
		for (int i = 0; i < this.height; i++)
		{
			for(int j = 0; j < this.width; j++)
			{
				this.imageData[i][j] = copie[i][j].toTransparentPixel();
			}
		}
		
		this.imageType = ImageType.Transparent;
	}
	
	/**
	 * Fait pivoter l'image de 10 degres autour du pixel (row,col)=(0, 0)
	 * dans le sens des aiguilles d'une montre (clockWise == true)
	 * ou dans le sens inverse des aiguilles d'une montre (clockWise == false).
	 * Les pixels vides sont blancs.
	 * @param clockWise : Direction de la rotation 
	 */
	public void rotate(int a, int b, double angleRadian)
	{
		PixelMapPlus copie = new PixelMapPlus(imageType, this);
		int x = 0, y = 0;
		
		for(int i = 0; i < height; i++)
		{
			for(int j = 0; j < width; j++)
			{
				x = (int) (Math.cos(angleRadian) * j + Math.sin(angleRadian) * i - Math.cos(angleRadian) * a - Math.sin(angleRadian) * b + a);
				y = (int) (- Math.sin(angleRadian) * j + Math.cos(angleRadian) * i + Math.sin(angleRadian) * a - Math.cos(angleRadian) * b + b);
				
				if(y >= height || x >= width  || x < 0 || y < 0) 
				{
					switch (imageType)
					{
						case BW:
							this.imageData[i][j] = new BWPixel();
							break;
						case Gray:
							this.imageData[i][j] = new GrayPixel();
							break;
						case Color:
							this.imageData[i][j] = new ColorPixel();
							break;
						case Transparent:
							this.imageData[i][j] = new TransparentPixel();
							break;	
					}
				}
				else
				{
					this.imageData[i][j] = copie.getPixel(y, x);
				}
			}
		}
	}
	
	/**
	 * Modifie la longueur et la largeur de l'image 
	 * @param w : nouvelle largeur
	 * @param h : nouvelle hauteur
	 */
	public void resize(int w, int h) throws IllegalArgumentException
	{
		if(w < 0 || h < 0)
			throw new IllegalArgumentException();
		
		PixelMapPlus copie = new PixelMapPlus(imageType, this);
		// compl�ter
		AllocateMemory(imageType, h, w);
		
		for(int i = 0; i < copie.height; i++)
		{
			for(int j = 0; j < copie.width; j++)
			{
				imageData[i*height/copie.height][j*width/copie.width]
						= copie.imageData[i][j];
			}
		}
	}
	
	/**
	 * Insert pm dans l'image a la position row0 col0
	 */
	public void inset(PixelMap pm, int row0, int col0)
	{
		// compl�ter
		if (pm.getType() != imageType)
		{
			pm = new PixelMap(imageType, pm);
		}
		
		for (int i = row0; i < row0 + pm.height; i++)
		{
			for (int j = col0; j < col0 + pm.width; j++)
			{
				imageData[i][j] = pm.getPixel(i - row0, j - col0);
			}
		}
	}
	
	/**
	 * Decoupe l'image 
	 */
	public void crop(int h, int w)
	{
		// compl�ter		
		if(w < 0 || h < 0)
			throw new IllegalArgumentException();
		
		PixelMapPlus copie = new PixelMapPlus(imageType, this);
		// compl�ter
		AllocateMemory(imageType, h, w);
		
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				if (i >= copie.height || j >= copie.width)
				{
					switch (imageType)
					{
						case BW:
							this.imageData[i][j] = new BWPixel();
							break;
						case Gray:
							this.imageData[i][j] = new GrayPixel();
							break;
						case Color:
							this.imageData[i][j] = new ColorPixel();
							break;
						case Transparent:
							this.imageData[i][j] = new TransparentPixel();
							break;	
					}
				}
				else
				{
					this.imageData[i][j] = copie.getPixel(i, j);
				}
			}
		}
	}
	
	/**
	 * Effectue une translation de l'image 
	 */
	public void translate(int rowOffset, int colOffset)
	{
		// compl�ter
		PixelMapPlus copie = new PixelMapPlus(imageType, this);
		
		for (int i = 0; i < height; i++)
		{
			for (int j = 0; j < width; j++)
			{
				if (i - rowOffset < 0 || j - colOffset < 0 || i - rowOffset >= height || j - colOffset >= width)
				{
					switch (imageType)
					{
						case BW:
							this.imageData[i][j] = new BWPixel();
							break;
						case Gray:
							this.imageData[i][j] = new GrayPixel();
							break;
						case Color:
							this.imageData[i][j] = new ColorPixel();
							break;
						case Transparent:
							this.imageData[i][j] = new TransparentPixel();
							break;	
					}
				}
				else
				{
					this.imageData[i][j] = copie.getPixel(i - rowOffset, j - colOffset);
				}
			}
		}		
	}
	
	/**
	 * Effectue un zoom autour du pixel (x,y) d'un facteur zoomFactor 
	 * @param x : colonne autour de laquelle le zoom sera effectue
	 * @param y : rangee autour de laquelle le zoom sera effectue  
	 * @param zoomFactor : facteur du zoom a effectuer. Doit etre superieur a 1
	 */
	public void zoomIn(int x, int y, double zoomFactor) throws IllegalArgumentException
	{
		if(zoomFactor < 1.0)
			throw new IllegalArgumentException();
		
		// compl�ter
		PixelMapPlus copie = new PixelMapPlus(imageType, this);
		int newHeight = (int) (height/zoomFactor);
		int newWidth = (int) (width/zoomFactor);
		
		int offsetX = 0, offsetY = 0;
		
		if (x - newWidth/2 < 0)
		{
			offsetX = newWidth/2 - x;
		}
		else if (x + newWidth/2 > width)
		{
			offsetX = -(newWidth/2 + x - width);
		}
		
		if (y - newHeight/2 < 0)
		{
			offsetY = newHeight/2 - y;
		}
		else if (y + newHeight/2 > height)
		{
			offsetY = -(newHeight/2 + y - height);
		}
		
		//Les 2 facons de faire sont bonnes, faut choisir celle qu'on prefere
		for(int i = 0; i < newWidth; i++)
		{
			for(int j = 0; j < newHeight; j++)
			{
				int valY = j + (y - newHeight/2 + offsetY);
				int valX = i + (x - newWidth/2 + offsetX);
				this.imageData[j* (int)zoomFactor][i* (int)zoomFactor] = copie.getPixel(valY, valX);
				this.imageData[j* (int)zoomFactor][i* (int)zoomFactor + 1] = copie.getPixel(valY, valX);
				this.imageData[j* (int)zoomFactor + 1][i* (int)zoomFactor] = copie.getPixel(valY, valX);
				this.imageData[j* (int)zoomFactor + 1][i* (int)zoomFactor + 1] = copie.getPixel(valY, valX);
			}
		}
		/*for(int i = x - newWidth/2 + offsetX; i < x - newWidth/2 + offsetX + newWidth; i++)
		{
			for(int j = y - newHeight/2 + offsetY; j < y - newHeight/2 + offsetY + newHeight; j++)
			{
				int newY = (j - (y - newHeight/2 + offsetY)) * (int)zoomFactor;
				int newX = (i - (x - newWidth/2 + offsetX)) * (int)zoomFactor;
				this.imageData[newY][newX] = copie.getPixel(j, i);
				this.imageData[newY][newX + 1] = copie.getPixel(j, i);
				this.imageData[newY+ 1][newX] = copie.getPixel(j, i);
				this.imageData[newY+ 1][newX + 1] = copie.getPixel(j, i);
			}
		}*/
	}
}
