
public class CustomStack<AnyType> {
	   

	    private Node tete;

	    private class Node {
	      
			
			private AnyType data;
	        private Node next;
	    }
	    
    
    private int size = 0; // Nombre d'éléments dans la pile
    
    // Initialisation de la pile
    public CustomStack() {
    
    tete=null;
  
    }
    
    // Enlève l'élément au sommet de la pile et le renvoie
    public AnyType pop() throws EmptyStackException {
       
    	
    	
    	if(size==0)
			throw new EmptyStackException();
    	//conservation de l'element supprime
    	AnyType data=tete.data;
    	//l'element suivant remplace l'element en tete
    	tete = tete.next;
    	//taille diminue
    	size--;
    	return data;

    		
    }
    
    // Ajoute un élément au sommet de la pile
    public void push(AnyType element) {
        
        Node vieilleTete = tete;
        tete= new Node();
        //la tete contient le nouvel element
        tete.data=element;
        //l element suivant sera l'ancienne tete
        tete.next=vieilleTete;
        //la taille augmente
        size++;
    }
    
    // Renvoie l'élément au sommet de la pile sans l'enlever
    public AnyType peek() {
        // ne renvoit rien si la liste est vide
    	if(empty()==true)
			return null;
    	else
    		return tete.data;
        
    }
    
    // Renvoie le nombre d'éléments dans la pile
    public int size() {
        return size;        
    }
    
    // Indique si la pile est vide
    public boolean empty() {
        return size == 0;        
    }
    
}
