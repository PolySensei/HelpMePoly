
public class LinkedListQueue<AnyType> implements Queue<AnyType>
{	
	// Un noeud de la file
	@SuppressWarnings("hiding")
	private class Node<AnyType> 
	{
		private AnyType data;
		private Node next;
		
		public Node(AnyType data, Node next) 
		{
			this.data = data;
			this.next = next;
		}

		public void setNext(Node next) 
		{
			this.next = next;
		}
		
		public Node<AnyType> getNext() 
		{
			return next;
		}
		
		public AnyType getData() 
		{
			return data;
		}
	}
   
	private int size = 0;		//Nombre d'elements dans la file.
	
	private Node<AnyType> last;	//Dernier element de la liste
	
	//Indique si la file est vide
	public boolean empty() 
	{ 
		return size == 0; 
	}
	
	//Retourne la taille de la file
	public int size() 
	{ 
		return size; 
	}
	
	//Retourne l'element en tete de file
	//Retourne null si la file est vide
	//complexit� asymptotique: O(1)
	public AnyType peek()
	{
		
		if(empty()==true)
			return null;
		else
		//l'element en tete de file
		return last.getNext().getData();
	}
	
	//Retire l'element en tete de file
	//complexit� asymptotique: O(1)
	public void pop() throws EmptyQueueException
	{
		
		//ne retire rien quand la liste est vide
		if(size==0)
			throw new EmptyQueueException();
		else
		{
		//element en tete de liste es remplacer
		last.setNext((last.getNext()).getNext());
		//la taille diminue
		size--;
		}
	}
	
	//Ajoute un element a la fin de la file
	//complexit� asymptotique: O(1)
	public void push(AnyType item)
	{		
		
		
		if(size==0){
			//nouveau node avec l'item sans prochaine valeur
			Node newNode= new Node (item, null);
			newNode.setNext(newNode);
			//derniere valeur correspond au nouveau node
			last=newNode;
			
			}
		else
		{
			// Sinon l'avant-dernier item pointera vers le nouveau	
			Node newNode= new Node (item, last.getNext());
			last.setNext(newNode);
			last=newNode;
		}
		//augmentation de la taille
		size++;
	}
}

	
