



public class ArrayQueue<AnyType> implements Queue<AnyType>
{
	private int size = 0;		//Nombre d'elements dans la file.
	private int startindex = 0;	//Index du premier element de la file
	private AnyType[] table;
   
	@SuppressWarnings("unchecked")
	public ArrayQueue() 
	{
		//Initialisation de la liste a 10 cases libres
		table = (AnyType[]) new Object[10];
	}
	
	//Indique si la file est vide
	public boolean empty() 
	{ 
		return size == 0; 
	}
	
	//Retourne la taille de la file
	public int size() 
	{ 
		return size; 
	}
	
	//Retourne l'element en tete de file
	//Retourne null si la file est vide
	//complexit� asymptotique: O(1)
	public AnyType peek()
	{
		
		//retourne null si le startindex est a 0 de la liste
		if(table[startindex]==null)
			return null;
		//sinon retourne l'element ou est le startindex de la liste
		else
			return table[startindex];
	}
	
	//Retire l'element en tete de file
	//complexit� asymptotique: O(1)
	public void pop() throws EmptyQueueException
	{
		//lancer l'exception si il ny a aucun element dans la liste
		if (size == 0)
			throw new EmptyQueueException();
		
		else{
			//l'element est supprimer
		table[startindex]=null;
		//augmentation du startindex pour retirer lelement
		startindex++;
		//verification que le startindex nest pas plus grand que la longueur de la liste
		if(startindex>=table.length)
			startindex=0;
		size--;
		}
	}
	
	//Ajoute un element a la fin de la file
	//Double la taille de la file si necessaire (utiliser la fonction resize definie plus bas)
	//complexit� asymptotique: O(1) ( O(N) lorsqu'un redimensionnement est necessaire )
	public void push(AnyType item)
	{
		
		int endIndex = size + startindex; //fin de l'inde
		//on double la taille de la liste quand endIndex est plus grand ou egal que celle-ci
		if(endIndex >=table.length)
			this.resize(2);
			//ajout de l'element a la liste	
		table[endIndex]=item;
		//la taille est augmente
		size++;
				
		
	}
   
	//Redimensionne la file. La capacite est multipliee par un facteur de resizeFactor.
	//Replace les elements de la file au debut du tableau
	//complexit� asymptotique: O(N)
	@SuppressWarnings("unchecked")
	private void resize(int resizeFactor)
	{
		
		AnyType[] vieuTableau=table;
		//on creer une nouvelle liste avec un taille mutliplier par un facteur d'agrandissment
		table = (AnyType[]) new Object[(vieuTableau.length)*resizeFactor];
		
		//les elements de l'ancienne liste sont inserer dans la nouvelle
		for(int i=0; i<vieuTableau.length;i++)
		{
			table[i]=vieuTableau[i];
			
		}
		
		
	}   
}

