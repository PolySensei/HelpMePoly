

/**
 * Classe PixelMapPlus
 * Image de type noir et blanc, tons de gris ou couleurs
 * Peut lire et ecrire des fichiers PNM
 * Implemente les methodes de ImageOperations
 * @author : L�andre Chamberland-Dozois
 * @date   : 13 septembre 2016
 */

public class PixelMapPlus extends PixelMap implements ImageOperations 
{
	/**
	 * Constructeur creant l'image a partir d'un fichier
	 * @param fileName : Nom du fichier image
	 */
	PixelMapPlus(String fileName)
	{
		super( fileName );
	}
	
	/**
	 * Constructeur copie
	 * @param type : type de l'image a creer (BW/Gray/Color)
	 * @param image : source
	 */
	PixelMapPlus(PixelMap image)
	{
		super(image); 
	}
	
	/**
	 * Constructeur copie (sert a changer de format)
	 * @param type : type de l'image a creer (BW/Gray/Color)
	 * @param image : source
	 */
	PixelMapPlus(ImageType type, PixelMap image)
	{
		super(type, image); 
	}
	
	/**
	 * Constructeur servant a allouer la memoire de l'image
	 * @param type : type d'image (BW/Gray/Color)
	 * @param h : hauteur (height) de l'image 
	 * @param w : largeur (width) de l'image
	 */
	PixelMapPlus(ImageType type, int h, int w)
	{
		super(type, h, w);
	}
	
	/**
	 * Genere le negatif d'une image
	 */
	
	
	public void negate()
	{
		for(int i = 0; i<this.height; i++) {
			for(int j = 0; j<this.width; j++) {
				this.imageData[i][j] = this.imageData[i][j].Negative();
			}
		}
	}
	
	/**
	 * Convertit l'image vers une image en noir et blanc
	 **/
	public void convertToBWImage()
	{
		for(int i = 0; i<this.height; i++) {
			for(int j = 0; j<this.width; j++) {
				this.imageData[i][j] = this.imageData[i][j].toBWPixel();
			}
		}
		this.imageType = ImageType.BW;
	}
	
	/**
	 * Convertit l'image vers un format de tons de gris
	 */
	public void convertToGrayImage()
	{
		for(int i = 0; i<this.height; i++) {
			for(int j = 0; j<this.width; j++) {
				this.imageData[i][j] = this.imageData[i][j].toGrayPixel();
			}
		}
		this.imageType = ImageType.Gray;
	}
	
	/**
	 * Convertit l'image vers une image en couleurs
	 */
	public void convertToColorImage()
	{
		for(int i = 0; i<this.height; i++) {
			for(int j = 0; j<this.width; j++) {
				this.imageData[i][j] = this.imageData[i][j].toColorPixel();
			}
		}
		this.imageType = ImageType.Color;
	}
	
	public void convertToTransparentImage()
	{
		for(int i = 0; i<this.height; i++) {
			for(int j = 0; j<this.width; j++) {
				this.imageData[i][j] = this.imageData[i][j].toTransparentPixel();
			}
		}
		this.imageType = ImageType.Transparent;
	}
	
	/**
	 * Fait pivoter l'image de 10 degres autour du pixel (row,col)=(0, 0)
	 * dans le sens des aiguilles d'une montre (clockWise == true)
	 * ou dans le sens inverse des aiguilles d'une montre (clockWise == false).
	 * Les pixels vides sont blancs.
	 * @param clockWise : Direction de la rotation 
	 */
	public void rotate(int a, int b, double angleRadian)
	{
		// compl�ter
		PixelMapPlus copie = new PixelMapPlus(this);
		int x = 0, y=0;
		for(int i = 0; i<this.height; i++) {
			for(int j = 0; j<this.width; j++) {
				x = (int)(Math.cos(angleRadian)*j + Math.sin(angleRadian)*i 
					- Math.cos(angleRadian)*a - Math.sin(angleRadian)*b + a);  
				y = (int)(-Math.sin(angleRadian)*j + Math.cos(angleRadian)*i 
						+ Math.sin(angleRadian)*a - Math.cos(angleRadian)*b + b);
				if (x<0 || x>=this.width || y<0 || y>=this.height) {
					this.imageData[i][j] = new BWPixel(true);
				} else {
					this.imageData[i][j] = copie.getPixel(x, y);
				}
			}
		}
		
	}
	
	/**
	 * Modifie la longueur et la largeur de l'image 
	 * @param w : nouvelle largeur
	 * @param h : nouvelle hauteur
	 */
	public void resize(int w, int h) throws IllegalArgumentException
	{
		if(w < 0 || h < 0)
			throw new IllegalArgumentException();
		
		// compl�ter
		PixelMapPlus copie = new PixelMapPlus(this);
		double ratioW = ((double)this.width)/w;
		double ratioH = ((double)this.height)/h;
		AllocateMemory(this.imageType,h,w);
		for (int i = 0; i < this.height;i++) {
			for (int j = 0;j<this.width;j++) {
				this.imageData[i][j] = copie.getPixel((int)ratioH*i, (int)ratioW*j);
			}
		}
		
	}
	
	/**
	 * Insert pm dans l'image a la position row0 col0
	 */
	public void inset(PixelMap pm, int row0, int col0)
	{
		// compl�ter
		for (int i = row0; (i < row0 + pm.getHeight()) && (i < this.height) ;i++) {
			for (int j = col0; (j < col0 + pm.getWidth()) && (j < this.width) ;j++){
				this.imageData[i][j] = pm.getPixel(i-row0, j-col0);
			}
		}
		
	}
	
	/**
	 * Decoupe l'image 
	 */
	public void crop(int h, int w)
	{
		PixelMapPlus copie = new PixelMapPlus(this);
		AllocateMemory(this.imageType, h, w);
		for (int i = 0; i < h; i++) {
			for (int j = 0; j < w; j++) {
				
				if (copie.getWidth() <= j || copie.getHeight() <= i) {
					this.imageData[i][j] = new BWPixel(true);
				} else {
					this.imageData[i][j] = copie.getPixel(i,j);
				}
				
			}
		}
	}
	
	/**
	 * Effectue une translation de l'image 
	 */
	public void translate(int rowOffset, int colOffset)
	{
		PixelMapPlus copie = new PixelMapPlus(this);
		for (int i = 0; i<this.height; i++) {
			for (int j = 0; j<this.width; j++) {
				if (i-rowOffset<0 || j-colOffset<0 ){
					this.imageData[i][j] = new BWPixel(true);
				} else {
					this.imageData[i][j] = copie.getPixel(i - rowOffset, j- colOffset);
				}
				
			}
		}
	}
	
	/**
	 * Effectue un zoom autour du pixel (x,y) d'un facteur zoomFactor 
	 * @param x : colonne autour de laquelle le zoom sera effectue
	 * @param y : rangee autour de laquelle le zoom sera effectue  
	 * @param zoomFactor : facteur du zoom a effectuer. Doit etre superieur a 1
	 */
	public void zoomIn(int x, int y, double zoomFactor) throws IllegalArgumentException
	{
		if(zoomFactor < 1.0)
			throw new IllegalArgumentException();
		
		PixelMapPlus copie = new PixelMapPlus(this);
		int newWidth = (int)(this.width/zoomFactor);
		int newHeight = (int)(this.height/zoomFactor);
		double ratioW = (double)newWidth/((double)this.width);
		double ratioH = (double)newHeight/((double)this.height);
		for (int i = 0; i < this.height; i++) {
			for (int j = 0; j < this.width; j++) {
				this.imageData[i][j] = copie.getPixel(y - newHeight/2 + (int)(ratioH*i), x - newWidth/2 + (int)(ratioW*j));
			}
		}
		
	}
}
