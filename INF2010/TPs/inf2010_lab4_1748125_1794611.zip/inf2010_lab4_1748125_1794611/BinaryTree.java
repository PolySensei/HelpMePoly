public class BinaryTree<AnyType> {
	private Node<AnyType> root = null; // Racine de l'arbre

	// insert element in arbre 
	public void insert (AnyType elem) {
	        if(root==null){
	        	this.root= new Node<AnyType>(elem);
	        }else	
	        	insert(root, elem);      
	}
	
	
	
	@SuppressWarnings("unchecked")
	private void insert(Node<AnyType> node, AnyType elem) {
		
	
		int compareResult = ((Comparable<Integer>) elem).compareTo((Integer) node.val);
		if(compareResult < 0 )
		{
			if (node.left != null)
				insert(node.left, elem);
			else 
				node.left = new Node<AnyType>(elem);
		}
		else if ( compareResult > 0 )
		{
			if (node.right != null)
				insert(node.right, elem);
			else 
				node.right = new Node<AnyType>(elem);
		}
		else
		; // Rejeter en cas de doublon
	
	}
    
	
	public int getHauteur () {
		return this.getHauteur(this.root);
	}
 
	public String printPrefixe() {
		return "{ " + this.printPrefixe(this.root) + " }";
	}
	public String printInFixe() {
		return "{ " + this.printInfixe(this.root) + " }";
	}
	
	public String printPostFixe() {
		return "{ " + this.printPostfixe(this.root) + " }";
	}
	
	private int getHauteur(Node<AnyType> tree) {
		if (tree == null)
			return -1;
		else
			return 1 + Math.max(getHauteur(tree.left), getHauteur(tree.right)); 
		
	}	
	
	@SuppressWarnings("unchecked")
	private String printPrefixe(Node<AnyType> node) {
		String result = "";
		if( node != null )
		{
		result = node.val + " " + printPrefixe( node.left ) + printPrefixe( node.right  );
		//result= printPrefixe( node.left );
		//result = printPrefixe( node.right  );
		}
		return result;
	}

	@SuppressWarnings("unchecked")
	private String printInfixe(Node<AnyType> node) {
		String result = "";
		if( node != null )
		{
		//result =printInfixe( node.left );
		result =printInfixe( node.left ) + node.val + " " + printInfixe( node.right);
		//result = printInfixe( node.right);
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	private String printPostfixe(Node<AnyType> node) {
		String result = "";
		if( node != null )
		{
		//printPostfixe( node.left );
		//printPostfixe( node.right );
		result=printPostfixe( node.left )+ printPostfixe( node.right )+  node.val + " " ;
		}
		return result;
	}
	
	private class Node<AnyType> {
		AnyType val; // Valeur du noeud
		Node right; // fils droite
		Node left; // fils gauche

		public Node (AnyType val) {
			this.val = val;
			right = null;
			left = null;
		}

	}


}


