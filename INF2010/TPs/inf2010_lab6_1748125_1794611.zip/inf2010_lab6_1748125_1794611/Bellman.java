import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Stack;
import java.util.Vector;


public class Bellman {
	private Graph graph;
	private Node sourceNode;
	private List<Vector<Double>> piTable =  new ArrayList<Vector<Double>>();
	private List<Vector<Integer>> rTable =  new ArrayList<Vector<Integer>>();
	
	public Bellman (Graph g) {
		this.graph = g;
	}
	
	public void setSourceNode(Node source) {
		this.sourceNode = source;
	}
	
	public void shortestPath() {
		// completer
		
		Vector<Double> containerPi= new Vector<Double>();
		Vector<Integer> containerR= new Vector<Integer>();
		piTable.add(new Vector<Double>(graph.getNodes().size()));
		rTable.add(new Vector<Integer>(graph.getNodes().size()));
		
		// initialise iteration 0 
		piTable.get(0).add((double) 0);
		for(int i =1 ; i < graph.getNodes().size();i++)
		{
			piTable.get(0).add(Graph.inf);
		}
		
		for(int i =0 ; i < graph.getNodes().size();i++)
		{
			rTable.get(0).add(0);
		}
		
		
		containerPi.add((double) 0);
		for(int i =1 ; i < graph.getNodes().size();i++)
		{
			containerPi.add(Graph.inf);
		}
		
		for(int i =0 ; i < graph.getNodes().size();i++)
		{
			containerR.add(0);
		}
		
	
		for(int i =0 ; i < graph.getNodes().size();i++)
		{
			boolean stop = true;
			for( Edge edge : graph.getEdges()){
			
				if(piTable.get(i).get(edge.getDestination().getId()-1) > (piTable.get(i).get(edge.getSource().getId()-1) +edge.getDistance()) && piTable.get(i).get(edge.getSource().getId()-1) != Graph.inf )
				{
					if((piTable.get(i).get(edge.getSource().getId()-1) +edge.getDistance())<containerPi.get(edge.getDestination().getId()-1)){
					containerPi.insertElementAt(piTable.get(i).get(edge.getSource().getId()-1) +edge.getDistance(),edge.getDestination().getId()-1);
					containerPi.remove(edge.getDestination().getId());
					
					
					containerR.insertElementAt(edge.getSource().getId(),edge.getDestination().getId()-1 );
					containerR.remove(edge.getDestination().getId());}
				}
			}
			piTable.add(new Vector<Double>(graph.getNodes().size()));
			rTable.add(new Vector<Integer>(graph.getNodes().size()));
			
			
		
			for(int j =0 ; j<containerPi.size();j++)
			{
				piTable.get(i+1).add(containerPi.get(j));
				if (!(piTable.get(i+1).get(j).equals(piTable.get(i).get(j))))
					stop=false;
			}
		
			for(int j =0 ; j<containerR.size();j++)
			{
				rTable.get(i+1).add(containerR.get(j));
			}
			
			if(stop)
			break;
			
		}
	
	}
	
	public void  diplayShortestPaths() {
		Stack<Node> path=new Stack<Node>();
		Node origineCircuit = null;
		String output = "=> Les chemins sont :\n";
		
		for(int i = 1; i <= graph.getNodes().size(); i++)
		{
			origineCircuit = graph.getNodeById(i);
			path.push(origineCircuit);
			
			do{
				int nodeId= rTable.get(rTable.size() - 1).get(path.peek().getId()-1);
				if(nodeId==0)
					nodeId++;
				path.push(graph.getNodeById(nodeId));
			}while(path.peek() != sourceNode && path.peek() != origineCircuit);
			
			if(origineCircuit==sourceNode && path.size()==2)
			{
				
				path.clear();
			}
			
			else if(path.peek() == origineCircuit){
				System.out.print("=> Le graphe contient un circuit de co�t n�gatif :\n[" + origineCircuit.getName()
						+ " - " + origineCircuit.getName() + "] ");
				while(!path.isEmpty())
					if(path.size()==1)
					System.out.print (path.pop().getName());
					else 
					System.out.print (path.pop().getName() + " -> ");
				return;
				
				
			}
			else{
				output += "[" + sourceNode.getName() + " - " + graph.getNodes().get(i-1).getName() + "] "
						+ piTable.get(piTable.size() - 1).get(i-1) + " : " + path.pop().getName();
				while(!path.isEmpty())
					output += " -> " + path.pop().getName();
				output += "\n";
			}
			
	}
		System.out.print(output);
	}

	public void displayTables() {
	
		System.out.print("<< PITable >>: \n");
		System.out.print("k    :    ");
		for(Node node : graph.getNodes())
		{
			System.out.print(node.getName() + "            ");
		}
		System.out.println();
		int k=0;
		for(Vector<Double> i : piTable)
		{ 
			
			
			System.out.print(k+ "    :    ");
			k++;
			for(Double j : i)
			{
				if (j.equals(Graph.inf))
					System.out.print("inf"+  "          ");
				else if(j<0)
				System.out.print(j+  "         ");	
				else		
				System.out.print(j+  "          ");
			}
			System.out.println();
		}
			
		System.out.println();
		System.out.print("<< RTable >>: \n");
		System.out.print("k    :    ");
		for(Node node : graph.getNodes())
		{
			System.out.print(node.getName() + "            ");
		}
		System.out.println();
		int l=0;
		for(Vector<Integer> i : rTable)
		{ 
			
			
			System.out.print(l+ "    :    ");
			l++;
			for(Integer j : i)
			{
				if (j==0)
					System.out.print("-"+  "            ");
				else		
				System.out.print(graph.getNodeById(j).getName()+ "            ");
			}
			System.out.println();
		}
	}
}