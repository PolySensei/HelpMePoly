
#include <stdio.h>

unsigned int Decryption_fct(unsigned int crypted,unsigned int key)
{
	unsigned int decrypted;
    
	/*
	 * Remplacez le code suivant par de l'assembleur en ligne
	 * en utilisant le moins d'instructions possible
	
	permutation de décryptage; 4 bit = 1 nibble
	crypted[nib1,nib2,nib3,nib4,nib5,nib6,nib7,nib8] -->
	--> decrypted[nib5,nib4,nib8,nib1,nib6,nib2,nib3,nib7]
	*/

	/*decrypted = ((crypted & 0xf0000000) >> 12 | 
		     (crypted & 0xf000000)  >> 16 |
		     (crypted & 0xf00000)   >> 16 |
		     (crypted & 0xf0000)    << 8  |
			 (crypted & 0xf000)     << 16 |
		     (crypted & 0xf00)      << 4  |
		     (crypted & 0xf0)       >> 4  |
		     (crypted & 0xf)        << 20 )  |
		     key;*/
	
	
	asm volatile (
		// instructions...
		"movl %1, %%eax\n\t"
		"andl $0xf0000000, %%eax\n\t"
		"shrl $12, %%eax\n\t"
		"movl %%eax, %0\n\t"
		
		"movl %1, %%eax\n\t"
		"andl $0xff00000, %%eax\n\t" // on fait deux décallage en 1 
		"shrl $16, %%eax\n\t"
		"orl %%eax, %0\n\t"
		
		"movl %1, %%eax\n\t"
		"andl $0xf0000, %%eax\n\t"
		"shll $8, %%eax\n\t"
		"orl %%eax, %0\n\t"
		
		"movl %1, %%eax\n\t"
		"andl $0xf000, %%eax\n\t"
		"shll $16, %%eax\n\t"
		"orl %%eax, %0\n\t"
		
		"movl %1, %%eax\n\t"
		"andl $0xf00, %%eax\n\t"
		"shll $4, %%eax\n\t"
		"orl %%eax, %0\n\t"
		
		"movl %1, %%eax\n\t"
		"andl $0xf0, %%eax\n\t"
		"shrl $4, %%eax\n\t"
		"orl %%eax, %0\n\t"
		
		"movl %1, %%eax\n\t"
		"andl $0xf, %%eax\n\t"
		"shrl $20, %%eax\n\t"
		"orl %%eax, %0\n\t"
		
		"orl %2, %0\n\t"
		
		:"=r"(decrypted) // sorties (s'il y a lieu) 
		:"g"(crypted),"g"(key)// entrées	
		:"%eax" // registres modifiés (s'il y a lieu)
	);
	
	return decrypted;
}

int main()
{
	unsigned int data = 0x12345678;
	unsigned int key =0x0c0180c;

	printf("Représentation cryptée  :   %08x\n"
	       "Représentation decryptée:   %08x\n",
	       data,
	       Decryption_fct(data,key));

	return 0;
}
