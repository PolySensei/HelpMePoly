import { Component } from '@angular/core';

/**
 * Defines the component responsible to display the contact page.
 */
@Component({
  selector: 'contact',
  templateUrl: './contact.component.html'
})
export class ContactComponent { }
