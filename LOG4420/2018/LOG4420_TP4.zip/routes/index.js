const express = require("express");
const router = express.Router();

const productsManager = require("../managers/products");
const shoppingCartManager = require("../managers/shopping-cart");

/**
 * Gets the items count in the shopping cart.
 *
 * @return {number}   The items count.
 */
function getItemsCount() {
  return shoppingCartManager.getItems().reduce((sum, item) => sum + item.quantity, 0);
}

/**
 * Formats the specified number as a price.
 *
 * @param price         The price to format.
 * @returns {string}    The price formatted.
 */
function formatPrice(price) {
  return price.toFixed(2).replace(".", ",") + "&thinsp;$";
}


// Initialize the shopping cart session.
router.use((req, res, next) => {
  shoppingCartManager.initialize(req.session);
  next();
});

// Home Page
router.get([ "/", "/accueil" ], (req, res) => {
  res.render("home", { title: "Accueil", nav: "home", itemsCount: getItemsCount() });
});

// Products Page
router.get("/produits", (req, res) => {
  productsManager.getProducts().done(result => {
    res.render("products", { title: "Produits", nav:
      "products", productsList: result.data, itemsCount: getItemsCount(), formatPrice: formatPrice });
  });
});

// Product Page
router.get("/produits/:id", (req, res) => {
  productsManager.getProduct(req.params.id).done(result => {
    res.render("product", { title: "Produit", nav: "products",
      product: result.data, itemsCount: shoppingCartManager.getItems().length, formatPrice: formatPrice });
  });
});

// Contact Page
router.get("/contact", (req, res) => {
  res.render("contact", { title: "Contact", nav: "contact", itemsCount: getItemsCount() });
});

// Shopping Cart Page
router.get("/panier", (req, res) => {
  productsManager.getProducts("alpha-asc").done(result => {
    const products = result.data;
    const items = shoppingCartManager.getItems();

    function getItemAssociatedWithProduct(productId) {
      return items.find(item => item.productId === productId);
    }
    let total = 0;
    const resultedItems = products.filter(product => getItemAssociatedWithProduct(product.id) !== undefined)
      .map(product => {
        const item = getItemAssociatedWithProduct(product.id);
        const productTotal = product.price * item.quantity;

        total += productTotal;
        return {
          product: product,
          quantity: item.quantity,
          total: productTotal
        };
      });

    res.render("shopping-cart", { title: "Panier", nav: "cart",
      items: resultedItems, total: total, itemsCount: getItemsCount(), formatPrice: formatPrice });
  });
});

// Order Page
router.get("/commande", (req, res, next) => {
  const itemsCount = getItemsCount();
  if (itemsCount > 0) {
    res.render("order", { title: "Commande", nav: "", itemsCount: itemsCount });
  } else {
    next();
  }
});

// Confirmation Page
router.post("/confirmation", (req, res, next) => {
  const orderManager = require("../managers/orders");
  orderManager.getOrders().then(result => {
    if (result.data.length > 0) {
      function pad(number, width) {
        const symbol = '0';
        number = number + '';
        return number.length >= width ? number : new Array(width - number.length + 1).join(symbol) + number;
      }

      const order = result.data[result.data.length - 1];
      res.render("confirmation", { title: "Confirmation", nav: "",
        itemsCount: getItemsCount(), order: order, pad: pad });
    } else {
      next();
    }
  });
});

module.exports = router;
