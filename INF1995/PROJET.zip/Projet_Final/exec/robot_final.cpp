/****************************************************************************
* Fichier: test_lignenoire.cpp
* Auteurs: David Tremblay (1748125) et Alexandre Clark (1803508) EQUIPE 0121
* Date: 
* Mise a jour : 
* Description: Capteur ligne noire
****************************************************************************/

#define F_CPU 8000000
#define FREQ_CPU 8000000
#include <avr/io.h>
#include "lib.h"
#include "../includes/memoire_24.h"
#include "../includes/can.h" // Nécessaire pour effectuer une conversion analogique numérique

#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03

#define CAPTEUR1 0x10
#define CAPTEUR2 0x20
#define CAPTEUR3 0x04
#define CAPTEUR4 0x08
#define CAPTEUR5 0x01
#define TCS_OUT_POS PB0
#define TCS_OUT_PORT PINB

uint8_t tableau[3];
uint8_t indice=0;

uint8_t state =0;


uint8_t vitesseMAX = 55.0;

#define ROND 0x01
#define CARRE 0x02
#define OCTO 0x03
uint8_t zero=0.0;
uint8_t distances[50];
uint8_t distance=0;
uint8_t compteurOcto=0;
uint8_t compteurCarre=0;

/*************************************************LIBRARY*************************************************************/
// fonction



uint32_t count()
{
	 if(!(TCS_OUT_PORT & (1<<TCS_OUT_POS)))
       {
              while(!(TCS_OUT_PORT & (1<<TCS_OUT_POS)));      //Wait for rising edge    
       }



	while(TCS_OUT_PORT & (1<<TCS_OUT_POS));  //Wait for falling edge
	TCNT1=0x0000;        //Reset Counter
	TCCR1B=(1<<CS10);    //Prescaller = F_CPU/1 (Start Counting)
	while(!(TCS_OUT_PORT & (1<<TCS_OUT_POS)));      //Wait for rising edge  
	//Stop Timer
	TCCR1B=0x00;
	return ((float)F_CPU/TCNT1);

}
		
uint32_t mesureRouge(){
	// s2 à 0 et s3 à 0 (rouge)
	// 0000 1110
	PORTB = 0x0E;
	uint32_t rouge;
	rouge = count();
	_delay_ms(10);
	rouge += count();
	_delay_ms(10);
	rouge += count();
			
return rouge/3.3;
                
}

uint32_t mesureBleu(){
	// s2 à 0 et s3 à 1 (bleu)
	// 1000 1110
	// 0010 0010
	// 1010 1110
	PORTB = 0x8E;
	//PORTB |= 0x20;
	uint32_t bleu;
	bleu = count();
	_delay_ms(10);
	bleu += count();
	_delay_ms(10);
	bleu += count();
			
return bleu/3.3;
                
}

uint32_t mesureBlanc(){
	// s2 à 1 et s3 à 0 (blanc)
	// 0100 1100
	PORTB = 0x4E;
	
	//PORTB |= 0x10;
       // PORTB ^= 0x20;
	uint32_t blanc;

	blanc = count();
	_delay_ms(10);
	blanc += count();
	_delay_ms(10);
	blanc += count();
			
return blanc/3.3;
                
}
// orange = s3 = 32
//vert = s2 = 16
uint32_t mesureVert(){
	// s2 à 1 et s3 à 1 (vert)
	// 1100 1110
	PORTB = 0xCE;
	uint32_t vert;
	vert = count();
	_delay_ms(10);
	vert += count();
	_delay_ms(10);
	vert += count();
			
return vert/3.3;
                
}

void PWMPiezo (double frequence)
{
	// COM0B1 , COM0B0 , WGM01, WGM00 sont actifs
	// COM0B1/C0M0B0 : set OC0B on compare match, clear OC0B at BOTTOM
	// WGM02/WGM01/WGM01 : Fast PWM, top = OCR0A
	TCCR0A = 0x33;
	// CS01 , CS00 et WGM02 sont actifs 
	// CS01/CS00 : Prescaler à 64
	TCCR0B = 0x0D;
	// OCR0A en MAX	
	OCR0A = frequence-1;
	OCR0B = OCR0A / 2 ; // PWM de 50%

}

void arreterPiezo()
{

   TCCR0B = 0x08; // Pour arreter.
   return;

}

void choisirFrequence(uint8_t note)
{
	uint8_t frequence[37]={71 , 67 , 63 ,60, 56, 53 , 50 ,47,45,42,40, 38, 36, 34, 32, 30, 28, 27,25, 24, 23, 	21, 20,19, 18 , 17, 16,15, 14, 	14, 13, 12, 11, 10, 10, 9, 9};
	
	if (note == 0) {
		arreterPiezo();
	}
	else
	// Les notes commencent à 45 donc on fait -45
	// pour commencer à l'index 0
	PWMPiezo(frequence[note-45]);

}



void playSong3() // Grieg: In the Hall of the Mountain King
{
    DDRB = 0xff;
    int chanson[] = {52, 54, 55, 57, 59, 55, 59,59 , 58, 54, 58,58 , 57, 53, 57,57, 52, 54,55,57,59,55,59,64,62,59,55,59,62,62,0};
   
	// j = nombre de répétitions de la chanson
        for (int j=0; j<2; j++) 
	{
        	for (int i=0; i<31; i++) 
       		{
        		int note = chanson[i];
			choisirFrequence(note);
           		_delay_ms(200);	
		}
	}
        arreterPiezo();
        //PORTB=0;
}






uint8_t updateState(uint16_t resultat)
{
	// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);
	return resultat;
}

	

bool arretAvantDetection(uint8_t dist){
	bool stateTEMP=0;
	if(dist >= 115)
		stateTEMP= 1;
	return stateTEMP;
	}
	
void detecterFormePiece(){
	can adc;
	_delay_ms(1000);
      //  bool arret=false;
       // can adc;
       /* while(!arret){
			uint16_t temp=adc.lecture(0x01);
			uint8_t distTemp=updateState(temp);
			arret=arretAvantDetection(distTemp);
			avancer(vitesseMAX,vitesseMAX);
		}
	*/
        tournerGauche(vitesseMAX+5,vitesseMAX+5);
        _delay_ms(1000);
        tournerDroite(vitesseMAX+5,vitesseMAX+5);
        for(uint8_t i=0; i<50; i++){
                uint16_t temp=adc.lecture(0x01);
                distance=updateState(temp);
                distances[i]=distance;
                _delay_ms(40);
            			
        }
	while(!(PINC & CAPTEUR3))
	{				
		tournerDroite(vitesseMAX,vitesseMAX);
	}
        avancer(0,0);
        for(uint8_t i=3; i<48; i++){
            if((distances[i+1]>distances[i])&&(distances[i+2]>distances[i])&&(distances[i-1]>distances[i])&&(distances[i-2]>distances[i])){
                if(distances[i]<80){
                    compteurCarre++;
                }
                else if((distances[i]>90)&&(distances[i-2]>=distances[i-1])&&(distances[i+2]>=distances[i+1])&&((distances[i-3]>distances[i-2])||(distances[i+3]>distances[i+2]))) {
                     compteurOcto++;   
                }
                
            }
        }

        _delay_ms(500);
       
       
        if(compteurCarre>=1){
		choisirFrequence(45);
		_delay_ms(1000);
		arreterPiezo();
            	tableau[indice] = 'B';
            
        }
        else if(compteurOcto>=2){
		PORTD &= 0xFC;
		PORTD |= 0x02;
		_delay_ms(1000);
		PORTD &= 0xFC;
		tableau[indice] = 'R';
            
        }
        else if(compteurOcto<=1&&compteurCarre==0){
		PORTD &= 0xFC;
		PORTD |= 0x01;
		_delay_ms(1000);
		PORTD &= 0xFC;
		tableau[indice] = 'V';
			
        }
}





/*************************************************LIBRARY*************************************************************/
int main(){
 	//uint8_t vitesseMAX = 80;
	DDRA = 0x00; // PORT A est en mode entrée
	DDRD = 0xFF; // PORT D est en mode sortie
	DDRC = 0x00; // PORT C est en mode entrée
	DDRB = 0xFE;
	bool enMarche = true;
	bool debut = true;
	bool detection = false;
	PORTC = 0x00;
	PORTB = 0x00;
	PORTD = 0x00;
	
	uint32_t r,v,b;
	//uint8_t tableau[3];
	uint8_t compteur=0;
	bool rougePresent = false;
	bool vertPresent = false;
	bool bleuPresent = false;

	// distance
	zero=0.0;
	distance=0;
	compteurOcto=0;
	compteurCarre=0;

	uint8_t dist;
	
	uint16_t temp;
	can adc;

	for(;;)  // boucle sans fin
	{
		temp=adc.lecture(0x01);
		dist=updateState(temp);
		if(dist >= 100)
		{
			detecterFormePiece();
		}



		if(detection)
		{
			
			
			r = mesureRouge();
			v = mesureVert();
			b = mesureBleu();
			
			
			if(r>35000 && b> 35000 && v> 35000)
			{
				PORTD &= 0xFC;
				arreterPiezo();	
				compteur = 0;
				rougePresent = false;
				vertPresent = false;
				bleuPresent = false;
				
			}
			else if(r>b && r> v)
			{   
				PORTD &= 0xFC;
			      	PORTD |= 0x02;
				arreterPiezo();	
				if((tableau[compteur]== 'R')&& !rougePresent)
				{
					compteur++;
					rougePresent = true;
				}
				
							
			}
			else if(b>v && b>r)
			{ 
			      	choisirFrequence(45);
							
				PORTD &= 0xFC;
				if((tableau[compteur]== 'B') && !bleuPresent)
				{
					compteur++;
					bleuPresent = true;
				}
			} 
			
			else if(v>b && v> r)
			{
				PORTD &= 0xFC;
			        PORTD |= 0x01;
				arreterPiezo();	
				if((tableau[compteur]=='V') && !vertPresent)
				{
					compteur++;
					vertPresent = true;
				}		
			}
			
			if (compteur ==3)
			{
				enMarche= false;
				detection = false;
				avancer(0,0);
				playSong3();
				
			}
		
			_delay_ms(100);
			

		
		}

		
		

		if (enMarche)
		{
			
			// Cas ou toutes les lumieres sont allumées
			// DÉBUT
			if((PINC & CAPTEUR5)&&(PINC & CAPTEUR4)&&(PINC & CAPTEUR3)&&(PINC & CAPTEUR1)&&(PINC & CAPTEUR2)
			&& debut)
			{
				avancer(vitesseMAX,vitesseMAX);
				_delay_ms(500);	
				debut = false;
				
			}
			

			// 5 - 4 
			else if((PINC & CAPTEUR5)&&(PINC & CAPTEUR4)&& !detection)
			{

				avancer(vitesseMAX,vitesseMAX);
				_delay_ms(1300);
				tournerDroite(vitesseMAX,vitesseMAX);
				_delay_ms(1000);
				
				//
				while(!(PINC & CAPTEUR3))
				{				
					tournerDroite(vitesseMAX,vitesseMAX);
				}
				avancer(vitesseMAX,vitesseMAX);
			}

			// 1 - 2 
			else if((PINC & CAPTEUR1)&&(PINC & CAPTEUR2)&& !detection)
			{

				avancer(vitesseMAX,vitesseMAX);
				_delay_ms(1300);
				tournerGauche(vitesseMAX,vitesseMAX);
				_delay_ms(1000);
				
				//
				while(!(PINC & CAPTEUR3))
				{				
					tournerGauche(vitesseMAX,vitesseMAX);
				}
				avancer(vitesseMAX,vitesseMAX);
				detection = true;
			}
			

			// 2
			else if((PINC & CAPTEUR2) || PINC & CAPTEUR1)
			{
				avancer(vitesseMAX-10.0,vitesseMAX);
				//_delay_ms(250);

			}
			// 4
			else if((PINC & CAPTEUR4) || PINC & CAPTEUR5)
			{
				avancer(vitesseMAX,vitesseMAX-10.0);
				
				//_delay_ms(250);
			}
			// 3
			else if(PINC & CAPTEUR3)
				avancer(vitesseMAX,vitesseMAX);
				//playSong3();
		}
		else
		{
			//playSong3();
			//avancer(0,0);
			
			
		}

	}
   	return 0;
}





