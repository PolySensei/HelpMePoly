/************************************************************************************
* Fichier: test_lignenoire.cpp
* Auteurs: ÉQUIPE 0121 : A.Clark - D.Tremblay - Saif Belhattab - L.Lucas - O.Mounir
* Date: 6 Décembre 2016
* Mise a jour : 1 Décembre 2016
* Description: Épreuve finale INF1995 : main
************************************************************************************/

#define F_CPU 8000000
#define FREQ_CPU 8000000
#include <avr/io.h>
#include "lib.h"
#include "../includes/memoire_24.h"
#include "../includes/can.h" // Nécessaire pour effectuer une conversion analogique numérique

// Nécessaires??? *************
#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03
// *************
#define CAPTEUR1 0x10
#define CAPTEUR2 0x20
#define CAPTEUR3 0x04
#define CAPTEUR4 0x08
#define CAPTEUR5 0x01
#define TCS_OUT_POS PB0
#define TCS_OUT_PORT PINB

// Initialisation des variables globales
bool enMarche = true;
bool debut = true;
bool detection = false;
bool reussite = false;
bool rougePresent = false;
bool vertPresent = false;
bool bleuPresent = false;
uint8_t vitesseMAX = 50.0;
//uint32_t r,v,b;
	
uint8_t compteur=0;	
uint8_t indice =3;
uint8_t compteurDroite = 0;
uint8_t rayon = 115;
	
// Tableau contenant les pièces parcourues
uint8_t tableau[3];


/*************************************************LIBRARY*************************************************************/

void arreterMoteurs()
{
	avancer(0,0);
}

uint8_t conversion8bits(uint16_t resultat)
{
	
	// On décale les 16 bits vers la droite puisque les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);

	// Maximum int sur 8 bits : 2⁸ -1 = 255 
	// On a 3 états (lumière basse/normale/forte)
	// donc 255 / 3 = 85
	
	// Lumière faible
	
	
	return resultat;
}


uint32_t count()
{
	// On s'assure que la sortie OUT du capteur TCS est en front montant
	 if(!(TCS_OUT_PORT & (1<<TCS_OUT_POS)))
       {
              while(!(TCS_OUT_PORT & (1<<TCS_OUT_POS)));      
       }


	// On attend un front descendant
	while(TCS_OUT_PORT & (1<<TCS_OUT_POS)); 
	// Réinitialisation du compteur 1 
	TCNT1=0x0000;     
	// Initialisation du prescaler à 1   
	TCCR1B=(1<<CS10);  
	// On attend un front montant  
	while(!(TCS_OUT_PORT & (1<<TCS_OUT_POS)));        
	// On arrête le compteur
	// La valeur de notre compteur est donc
	// la distance entre un front descendant et un front montant
	// puisque le PWM de OUT changera selon le filtre activé
	// permettra de déterminer quelle couleur est plus ou moins présente
	TCCR1B=0x00;
	return ((float)F_CPU/TCNT1);

}
		
uint32_t mesureRouge(){
	// 0000 1110 = 0E
	// On active le filtre rouge (S2/S3 = 0/0)
	// On active le divide à 1 (S0/S1 = 1/1)
	PORTB = 0x0E;
	uint32_t rouge;
	// On compte 3 fois
	rouge = count();
	_delay_ms(10);
	rouge += count();
	_delay_ms(10);
	rouge += count();
	// On retourne a moyenne sur 10 de nos résultats	
return rouge/3.3;
                
}

uint32_t mesureBleu(){
	// 1000 1110 = 0x8E
	// On active le filtre bleu (S2/S3 = 0/1)
	// On active le divide à 1 (S0/S1 = 1/1)
	PORTB = 0x8E;
	uint32_t bleu;
	bleu = count();
	_delay_ms(10);
	bleu += count();
	_delay_ms(10);
	bleu += count();
			
return bleu/3.3;
                
}

uint32_t mesureBlanc(){
	// 0100 1110 = 0x4E
	// On active le filtre blanc (S2/S3 = 1/0)
	// On active le divide à 1 (S0/S1 = 1/1)
	PORTB = 0x4E;
	uint32_t blanc;

	blanc = count();
	_delay_ms(10);
	blanc += count();
	_delay_ms(10);
	blanc += count();
			
return blanc/3.3;
                
}

uint32_t mesureVert(){
	// 1100 1110 = 0xCE
	// On active le filtre vert (S2/S3 = 1/1)
	// On active le divide à 1 (S0/S1 = 1/1)
	PORTB = 0xCE;
	uint32_t vert;
	vert = count();
	_delay_ms(10);
	vert += count();
	_delay_ms(10);
	vert += count();
			
return vert/3.3;
                
}

void PWMPiezo (double frequence)
{
	// COM0B1 , COM0B0 , WGM01, WGM00 sont actifs
	// COM0B1/C0M0B0 : set OC0B on compare match, clear OC0B at BOTTOM
	// WGM02/WGM01/WGM01 : Fast PWM, top = OCR0A
	TCCR0A = 0x33;
	// CS01 , CS00 et WGM02 sont actifs 
	// CS01/CS00 : Prescaler à 64
	TCCR0B = 0x0D;
	// OCR0A en MAX	
	OCR0A = frequence-1;
	OCR0B = OCR0A / 2 ; // PWM de 50%

}

void arreterPiezo()
{

   TCCR0B = 0x08; // Pour arreter.
   return;

}

void choisirFrequence(uint8_t note)
{
	uint8_t frequence[37]={71 , 67 , 63 ,60, 56, 53 , 50 ,47,45,42,40, 38, 36, 34, 32, 30, 28, 27,25, 24, 23, 	21, 20,19, 18 , 17, 16,15, 14, 	14, 13, 12, 11, 10, 10, 9, 9};
	
	if (note == 0) {
		arreterPiezo();
	}
	else
	// Les notes commencent à 45 donc on fait -45
	// pour commencer à l'index 0
	PWMPiezo(frequence[note-45]);

}


void playSong3() // Grieg: In the Hall of the Mountain King
{
    DDRB = 0xff;
    int chanson[] = {52, 54, 55, 57, 59, 55, 59,59 , 58, 54, 58,58 , 57, 53, 57,57, 52, 54,55,57,59,55,59,64,62,59,55,59,62,62,0};
   
	// j = nombre de répétitions de la chanson
        for (int j=0; j<2; j++) 
	{
        	for (int i=0; i<31; i++) 
       		{
        		int note = chanson[i];
			choisirFrequence(note);
           		_delay_ms(200);	
		}
	}
        arreterPiezo();
        //PORTB=0;
}


void detectionCouleur(){
			uint32_t r,v,b;
			r = mesureRouge();
			v = mesureVert();
			b = mesureBleu();
			
			
			if(r>35000 && b> 35000 && v> 35000)
			{
				PORTD &= 0xFC;
				arreterPiezo();	
				compteur = 0;
				rougePresent = false;
				vertPresent = false;
				bleuPresent = false;
				
			}
			else if(r>b && r> v)
			{   
				PORTD &= 0xFC;
			      	PORTD |= 0x01;
				arreterPiezo();	
				if((tableau[compteur]== 'R')&& !rougePresent)
				{
					compteur++;
					rougePresent = true;
				}
				
							
			}
			else if(b>v && b>r)
			{ 
			      	choisirFrequence(45);
							
				PORTD &= 0xFC;
				if((tableau[compteur]== 'B') && !bleuPresent)
				{
					compteur++;
					bleuPresent = true;
				}
			} 
			
			else if(v>b && v> r)
			{
				PORTD &= 0xFC;
			        PORTD |= 0x02;
				arreterPiezo();	
				if((tableau[compteur]=='V') && !vertPresent)
				{
					compteur++;
					vertPresent = true;
				}		
			}
			
			if (compteur ==3)
			{
				enMarche= false;
				detection = false;
				reussite = true;
								
			}
		
			_delay_ms(100);
			
}

void suivreLigne()
{
	// AU DEBUT
	// Première lecture des 5 capteurs allumer
	if((PINC & CAPTEUR5)&&(PINC & CAPTEUR4)&&(PINC & CAPTEUR3)&&(PINC & CAPTEUR1)&&(PINC & CAPTEUR2)&& debut)
	{
		avancer(vitesseMAX,vitesseMAX);
		_delay_ms(500);	
		debut = false;
		// Les prochaines fois que 5 capteurs sont allumés
		// le robot va exécuter une rotation vers la droite		
	}
		
	// *******************Liste de condition selon les priorités***************************	

	// Si les capteurs 5 et 4 (Extrémité droite) sont actifs
	// et que la détection de couleur n'est pas active
	// (Le robot ne doit pas tourner s'il est en mode détection couleurs)
	else if((PINC & CAPTEUR5)&&(PINC & CAPTEUR4)&& !detection)
	{
		// On continue d'avancer pour centrer les roues
		avancer(vitesseMAX,vitesseMAX);
		_delay_ms(1300);
		// On ferme les moteurs puis on initie la rotation vers la droite
		arreterMoteurs();
		_delay_ms(250);
		tournerDroite(vitesseMAX-5,vitesseMAX-5);
		_delay_ms(500);
				
		// Tant que le capteur 4 n'est pas actif 
		// (Prend en compte la vitesse de rotation préalable)
		while(!(PINC & CAPTEUR4))
		{	
			// Rotation vers la droite			
			tournerDroite(vitesseMAX,vitesseMAX);
		}
		// On éteint les moteurs puis avance vers l'avant
		arreterMoteurs();
		_delay_ms(300);
		avancer(vitesseMAX,vitesseMAX);
		_delay_ms(350);
		// On incrémente le nombre de fois qu'on compte à droite
		// pour ainsi fermer le capteur lorsque le robot
		// n'est pas dans une pièce
		compteurDroite++;
	}

	// Si les capteurs 1 et 2 (Extrémité gauche) sont actifs
	else if((PINC & CAPTEUR1)&&(PINC & CAPTEUR2)&& (indice==0) && (!detection))
	{
		// Centrer les roues
		avancer(vitesseMAX,vitesseMAX);
		_delay_ms(1300);
		arreterMoteurs();
		_delay_ms(250);
		tournerGauche(vitesseMAX-5,vitesseMAX-5);
		_delay_ms(500);
				
		// Réaligner sur la ligne	
		while(!(PINC & CAPTEUR2))
		{				
			tournerGauche(vitesseMAX,vitesseMAX);
		}
		arreterMoteurs();
		_delay_ms(300);
		avancer(vitesseMAX,vitesseMAX);
		// Si on tourne à gauche on est donc à la sortie de la troisième pièce
		// On doit donc commencer la détection de couleurs
		detection = true;
	}
			

	// Si le capteur 1 ou 2 est actif
	else if((PINC & CAPTEUR2) || PINC & CAPTEUR1)
	{
		// On corrige la trajectoire 
		// en diminuant la vitesse de la roue appropriée
		avancer(vitesseMAX-10.0,vitesseMAX);
				

	}
	// Si le capteur 4 ou 5 est actif
	else if((PINC & CAPTEUR4) || PINC & CAPTEUR5)
	{
		// correction de la trajectoire
		avancer(vitesseMAX,vitesseMAX-10.0);
				
				
	}
	// Si le capteur 3 est actif (milieu)
	
	else if(PINC & CAPTEUR3)
		avancer(vitesseMAX,vitesseMAX);
				
}

// A COMMENTER (LOUIS/OTHMAN)
void detectionFormePiece(can& adc){
	// Initialisation des variables
	uint8_t distances[60];
	uint8_t distance=0;
	uint8_t compteurOcto=0;
	uint8_t compteurCarre=0;
	uint16_t temp=0;
       
	// Arret des moteurs
	arreterMoteurs();
	_delay_ms(300);
	// Rotation de 90 degré vers la gauche
        tournerGauche(vitesseMAX+5,vitesseMAX+5);
        _delay_ms(1300);
	// Arret des moteurs
	arreterMoteurs();	
	_delay_ms(300);
	// On amorce une rotation vers la droite
        tournerDroite(vitesseMAX+5,vitesseMAX+5);
	
        for(uint8_t i=0; i<60; i++)
	{
                temp=adc.lecture(0x01);
                distance=conversion8bits(temp);
                distances[i]=distance;
                _delay_ms(40);   			
        }
	// On éteint les moteurs
        arreterMoteurs();
	
        for(uint8_t i=3; i<58; i++){
            if((distances[i+1]>distances[i])&&(distances[i+2]>distances[i])&&(distances[i-1]>distances[i])&&(distances[i-2]>distances[i])){
                if(distances[i]<80){
                    compteurCarre++;
                }
                else if((distances[i]>90)&&(distances[i-2]>=distances[i-1])&&(distances[i+2]>=distances[i+1])&&((distances[i-3]>distances[i-2])||(distances[i+3]>distances[i+2]))) {
                     compteurOcto++;   
                }
                
            }
        }

	_delay_ms(300);
	// Tant que le capteur4 n'est pas activé 
	// (Prend en compte la vitesse de rotation préalable)
	// On fait tourner le robot vers la droite
	while(!(PINC & CAPTEUR4))
	{				
		tournerDroite(vitesseMAX+10,vitesseMAX+5);
	}
	// Arrêt des moteurs lorsque sur la ligne
	arreterMoteurs();

	// DÉTERMINATION DE LA PIÈCE
	// ***Expliquer compteur carré
	// CARRÉ
        if(compteurCarre>=1){
            	// Émission d'un son aigu pendant 2 secondes
		choisirFrequence(70);
		_delay_ms(2000);
		arreterPiezo();
		// ********Nécessaire? à tester
		PORTD &= 0xFC;
		// Étant donné que les parcours sont dans l'ordre inverse de celui de lecture
		// on remplie le tableau à partir de la fin
		tableau[indice-1] = 'B';
		// on décrémente l'indice pour se rapprocher du début
		indice--;
        }

	// ***Expliquer compteur octo
	// OCTOGONE
        else if(compteurOcto>=2){
		// On s'assure de bien fermer les pins de la DEL
		// à l'aide d'un masque
		PORTD &= 0xFC;
		// On allume la DEL en rouge pendant 2 secondes
		PORTD |= 0x01;     
		_delay_ms(2000);
		PORTD &= 0xFC;
		// On écrit dans le tableau la lettre reliée à la pièce
		// (toujours en partant de la fin)
		tableau[indice-1] = 'R';
		indice--;
        }

	// ***Expliquer compteur octo + carre
	// CERCLE
        else if(compteurOcto<=1&&compteurCarre==0){
		// On allume la DEL en vert pendant 1 seconde
                PORTD &= 0xFC;
	        PORTD |=0x02; //Vert
                _delay_ms(2000);
                PORTD &= 0xFC; 
	        tableau[indice-1] = 'V';
	        indice--;
        }
	
}
// On détermine la distance lue par le capteur de distance
uint8_t verifierDistance(can& adc)
{
	uint8_t dist2;
	uint16_t temp;
	// Lecture grâce à l'objet CAN passé en paramètre
	temp=adc.lecture(0x01);
	dist2=conversion8bits(temp);
	return dist2;
}
// Routine d'exécution lorsque le parcours est réussi par le robot
// (joue une chanson en tournant puis s'arrête)
void sequenceReussite()
{
	arreterMoteurs();
	_delay_ms(500);
	//tournerDroite(100,100);
	playSong3();
	//arreterMoteurs();
	reussite=false;
}
/*************************************************LIBRARY*************************************************************/
int main(){
 	
	DDRA = 0x00; // PORT A est en mode entrée
	DDRB = 0xFE; // La première PIN du PORTB est en mode entrée 
		     // et le reste du port est en mode sortie
	DDRC = 0x00; // PORT C est en mode entrée
	DDRD = 0xFF; // PORT D est en mode sortie
	
	
	
	// On s'assure que les ports sont à 0x00
	// pour le bon fonctionnement du programme
	PORTC = 0x00;
	PORTB = 0x00;
	PORTD = 0x00;
	
	// initialisation des variables
	uint8_t dist;
	can adc;

	// Boucle tant que le robot n'a pas fini son parcours
	while(enMarche)  
	{
		suivreLigne();

		// On vérifie si un objet est devant le robot
		dist= verifierDistance(adc);
		
		// Si le robot est devant un objet à une distance du rayon d'une pièce
		// qu'il est dans une pièce
		// et qu'il n'a pas parcouru 3 pièces
		if((dist > rayon) && (indice != 0) && (compteurDroite %2 !=0)){
			// On active la séquence de détection d'une pièce
			detectionFormePiece(adc);
		}			
		// Si la détection de la couleur est activée
		if(detection)
		{
			// Activation de la séquence de détectionCouleur
			detectionCouleur();
			
		}
		// Si le robot reconnait la bonne séquence de pièce
		if (reussite)
		{
			// Activation de la séquence de réussite
			sequenceReussite();
		}
	
		

	}
   	return 0;
}





