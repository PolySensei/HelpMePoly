/****************************************************************************
* Fichier: main.cpp
* Auteurs: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 11 novembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 2
****************************************************************************/

#define F_CPU 8000000
#define FREQ_CPU 8000000
#include <avr/io.h>
#include "lib.h"
#include "../includes/memoire_24.h"
#include "../includes/can.h" // Nécessaire pour effectuer une conversion analogique numérique

#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03

#define AVANCER 0x10
#define RECULER 0x11
#define GAUCHE 0x12
#define DROITE 0x13

	

uint8_t state =0;

// fonction
uint8_t updateState(uint16_t resultat)
{
	uint8_t stateTEMP=0;
	// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);

	// Maximum int sur 8 bits : 2⁸ -1 = 255 
	// On a 3 états (lumière basse/normale/forte)
	// donc 255 / 3 = 85
	
	// Lumière faible
	if(resultat >= 100)
		stateTEMP= 1;
	
	return stateTEMP;
}

int main(){
 
	DDRA = 0x00; // PORT A est en mode entrée
	DDRD = 0xFF; // PORT D est en mode sortie
	DDRC = 0x00; // PORT C est en mode entrée
	DDRB = 0xFF;
	can conversion;	
	bool arret = false;
	PORTC = 0x00;
	PORTB = 0x00;
	for(;;)  // boucle sans fin
	{
		state = updateState(conversion.lecture(0x04));
		switch (state) 
		{
			case 0 
:
			{
				// moteur en marche
				//avancer(100,100);
				arret = false;
				break;
			}

			case 1 :
			{
				// arreter moteurs
				ajustementPWM(0,0,0x10);
				arret = true;
				break;
			}

			
		}
		// 5  4  3  2  1
		
		// CENTRE (3)
		
		
		// 3
		if(PINC & 0x04)
			avancer(100,100);

		

		// 2
		if(PINC & 0x20)
			avancer(60,100);
		
		
		// 4
		if(PINC & 0x08)
			avancer(100,60);

		// 1
		if(PINC & 0x10)
			avancer(20,100);

		// 5
		if(PINC & 0x01)
			avancer(100,20);
		
		_delay_ms(250);
	}
   	return 0;
}





