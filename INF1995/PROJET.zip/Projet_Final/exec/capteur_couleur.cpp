/****************************************************************************
* Fichier: test_lignenoire.cpp
* Auteurs: David Tremblay (1748125) et Alexandre Clark (1803508) EQUIPE 0121
* Date: 
* Mise a jour : 
* Description: Capteur ligne noire
****************************************************************************/

#define F_CPU 8000000
#define FREQ_CPU 8000000
#include <avr/io.h>
#include "lib.h"
#include "../includes/memoire_24.h"
#include "../includes/can.h" // Nécessaire pour effectuer une conversion analogique numérique

//#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03

#define CAPTEUR1 0x10
#define CAPTEUR2 0x20
#define CAPTEUR3 0x04
#define CAPTEUR4 0x08
#define CAPTEUR5 0x01


	

uint8_t state =0;
uint8_t Count =0;
uint8_t ROUGE;
uint8_t BLEU;
uint8_t VERT;
uint8_t BLANC;


void initialisation ( void ) {

	
	cli ();

	// Permettre les interruptions externes

	EIMSK |= _BV(INT0);

	// Sensibiliser les interruptions externes aux

	// changements de niveau du bouton-poussoir

	EICRA |= (1 << ISC00) ;

	sei ();

}





int main(){
	DDRA = 0x00; // PORT A est en mode entrée
	DDRD = 0xFF; // PORT D est en mode sortie
	DDRC = 0x00; // PORT C est en mode entrée
	DDRB = 0xFE;


	uint8_t vitesseMAX = 50.0;
	can conversion;
	bool arret = false;
	//bool debut = true;
	PORTC = 0x00;
	PORTB = 0x00;
	
	for(;;)  // boucle sans fin
	{
		//
		// OUT = PINA & 0x08
		// S2 et S3 est en mode lecture de rouge
		uint16_t compteurROUGE;
		uint16_t compteurVERT;
		uint16_t compteurBLEU;
		uint16_t compteurBLANC;
		// S0 et S1 en mode divide 1:1
		PORTB |= 0x08;
		PORTB |= 0x04;
		// DEL du capteur allumée
		PORTB |= 0x02;
		// Si OUT est activé
		
		if(PINB & 0x01)
			// Allumer Del sans altérer le reste du port D
			PORTD |= 0x02;
		uint8_t couleur =0;
		//switch(couleur)
		{
		// S2 et S3 est en mode lecture de rouge
		//PORTB |= 0x08;
		//PORTB |= 0x04;	
		//if (PIN
		/*******************************************************/
		 switch(couleur)
            {
                case 0:
		// s2 à 0 et s3 à 0 (rouge)
                    _delay_ms(5000);
                    ROUGE = Count;
                    couleur++;
                break;
                case 1:
		    //s2 à 0 et s3 à 1 (bleu)
                    PORTB |= 0x20;
                    _delay_ms(5000);
                    BLEU = Count;
                    couleur++;
                break;
                case 2:
		// s2 à 1 et s3 à 0 (blanc)
                    PORTB |= 0x10;
                    PORTB ^= 0x20;
                    _delay_ms(5000);
                    BLANC = Count;
                    couleur++;
                break;
                case 3:
		// s2 à 1 et s3 à 1 (vert)
                    PORTB |= 0x10;
                    PORTB |= 0x20;
                    _delay_ms(50000);
                    VERT = Count;
		    //Reinitialise s2 et s3 à 0
		    PORTB ^= 0x10;
                    PORTB ^= 0x20;
                    couleur = 0;
                break;
            }



	/************************************************/
		
		
		}
		

static void interrupt isroutine(void)            
{    
    
    if(INTF == 1)
    {     
 
    }
    if(CCP1IF == 1)
    {     
 Count = CCPR1;
 TMR1H = 0x00;
 TMR1L = 0x00;
 
 CCP1IF = 0;
 
    }
    
    if(TMR1IF == 1)
    { 
 TMR1H = 0x00;
 TMR1L = 0x00; 
 TMR1IF = 0;
 over = 1;
 } 
 
 
    
}

	}
   	return 0;
}





