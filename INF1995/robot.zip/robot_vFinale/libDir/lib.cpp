#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>		// Nécessaire pour utiliser la commande "_delay_ms()"
#include <avr/interrupt.h>	// Nécessaire pour les interruptions	



#define ROUGE 0x04
#define VERT 0x08
#define AMBRE 0x03

#define AVANCER 0x10
#define RECULER 0x11
#define GAUCHE 0x12
#define DROITE 0x13


// **********************************DEL**************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************

void allumerLumiere(uint8_t couleur)
{
	switch(couleur)
	{
		case 0x08:
		{
			PORTC = 0x08;
		}

		case 0x04:
		{
			PORTC = 0x04;
		}

		case 0x03:
		{
			PORTC = 0x04;        // DEL rouge
          		_delay_ms(3);

           		PORTC= 0x08;        // DEL verte
           		_delay_ms(17);	
		}
	}
          
}

// Fait clignoter la lumière X fois dans une période Y avec la couleur choisie
// X : compteur , Y : intervalle
void lumiereClignotante(uint8_t compteur, uint8_t couleur)
{

	for(int i =0; i<compteur; i++)
	{
		
		allumerLumiere(couleur);
		_delay_ms(500);
		PORTC = 0x00;
		_delay_ms(500);
	}
}

// ******************************Conversion analogique numérique**************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************


uint8_t conversion16a8bits(uint16_t resultat)
{
// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);
	return resultat;
}


// **********************************************Moteurs**********************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************

// Ajustement PWM

void ajustementPWM ( uint8_t puissanceGauche, uint8_t puissanceDroite, uint8_t mode) {
	// Port D en mode sortie
	DDRD=0xFF;
	// COM1A1, COM1B1 et WGM10 actif

	// COM1A1/COM1B1 : Clear OC1A et OC1B on Compare Match
	// WGM10 : PWM, Phase correct 8-bit

	// Documentation Atmel p.128-130
	TCCR2A = 0xA1;
	TCCR2B = (1<<CS21); //0x02
	
	if(mode == 0x10)
	{
		// Port D à 0
		// 0000 0011
		PORTD &= 0x03;
		OCR2A = 0xFF * (puissanceDroite/100.0);
		OCR2B = 0xF4 * ((puissanceGauche)/100.0);
	}
	if(mode == 0x11)
	{
		// On active les pins "Direction" des deux moteurs à 1 (la direction est inversée)
		// 0011 0000
		PORTD |= 0x30;
		OCR2A = 0xFF * (puissanceDroite/100.0);
		OCR2B = 0xF4 * ((puissanceGauche)/100.0);	
	}

	if(mode == 0x12)
	{
		// On active la pin "Direction" du moteur de gauche
		// donc moteur gauche va vers l'arrière 
		// et moteur droit va vers l'avant
		// 0100 0000
		PORTD |= 0x10;
		OCR2A = 0xFF * (puissanceDroite/100.0);
		OCR2B = 0xF4 * ((puissanceGauche)/100.0);		
	}

	if(mode == 0x13)
	{
		// On active la pin "Direction" du moteur de droite
		// donc moteur droit va vers l'arrière 
		// et moteur gauche va vers l'avant
		// 0010 0000
		PORTD |= 0x20;
		OCR2A = 0xF4 * (puissanceDroite/100.0);
		OCR2B = 0xF4 * ((puissanceGauche)/100.0);		
	}
	
	
}


// Avancer

void avancer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 0x10);	
}

// Reculer

void reculer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 0x11);	
}

// Tourner vers la gauche

void tournerGauche(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 0x12);	
}

// Tourner vers la droite

void tournerDroite(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 0x13);	
}

// Prescaler à 1024 + mode CTC (Clear counter on compare match)
void setPrescaler1024() 
{
	TCCR1B = ((1<<CS02) | (1<<CS00)) | (1<<WGM02) ;
}


