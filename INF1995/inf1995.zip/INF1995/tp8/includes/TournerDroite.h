#ifndef TOURNERDROITE_H
#define TOURNERDROITE_H

#define F_CPU 8000000UL
#include "AjustementPWM.h"
#include <avr/io.h>
#include <util/delay.h>  

void tournerDroite(uint8_t puissanceGauche, uint8_t puissanceDroite);

#endif
