#ifndef AJUSTEMENTPWM_H
#define AJUSTEMENTPWM_H

#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>  


void ajustementPWM ( uint8_t puissanceGauche, uint8_t puissanceDroite, int test);

#endif
