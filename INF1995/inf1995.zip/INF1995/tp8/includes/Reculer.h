#ifndef RECULER_H
#define RECULER_H

#define F_CPU 8000000UL
#include "AjustementPWM.h"
#include <avr/io.h>
#include <util/delay.h>  


void reculer(uint8_t puissanceGauche, uint8_t puissanceDroite);

#endif
