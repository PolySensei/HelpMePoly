#ifndef AVANCER_H
#define AVANCER_H
#define F_CPU 8000000UL

#include "AjustementPWM.h"

#include <avr/io.h>
#include <util/delay.h>  

void avancer(uint8_t puissanceGauche, uint8_t puissanceDroite);

#endif
