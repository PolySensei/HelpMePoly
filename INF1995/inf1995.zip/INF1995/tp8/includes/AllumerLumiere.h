
#ifndef ALLUMERLUMIERE_H
#define ALLUMERLUMIERE_H

#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>  

void allumerLumiere(int test);

#endif
