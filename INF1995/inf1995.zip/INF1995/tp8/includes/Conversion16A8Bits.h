#ifndef CONVERSION16A8BITS_H
#define CONVERSION16A8BITS_H

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>  


uint8_t conversion16a8bits(uint16_t resultat);

#endif
