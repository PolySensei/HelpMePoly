#ifndef LUMIERECLIGNOTANTE_H
#define LUMIERECLIGNOTANTE_H

#define F_CPU 8000000UL
#include "AllumerLumiere.h"
#include <avr/io.h>
#include <util/delay.h>  


void lumiereClignotante(uint8_t compteur, uint8_t couleur, uint8_t intervalle);

#endif
