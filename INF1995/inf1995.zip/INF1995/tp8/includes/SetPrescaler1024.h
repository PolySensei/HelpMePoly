#ifndef SETPRESCALER1024_H
#define SETPRESCALER1024_H

#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>  

void setPrescaler1024();

#endif
