#include "../includes/Conversion16A8Bits.h"

uint8_t conversion16a8bits(uint16_t resultat)
{
// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);
	return resultat;
}
