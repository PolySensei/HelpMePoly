#include "../includes/AllumerLumiere.h"

void allumerLumiere(int test)
{
	switch(test)
	{
		case 0:
		{
			PINB = 0x02;
		}

		case 1:
		{
			PINB = 0x01;
		}

		case 3:
		{
			PINB = 0x01;        // DEL rouge
          	_delay_ms(3);

           	PINB = 0x02;        // DEL verte
           	_delay_ms(17);	
		}
	}
          
}
