#include "../includes/SetPrescaler1024.h"

void setPrescaler1024() 
{
	TCCR1B = ((1<<CS02) | (1<<CS00)) | (1<<WGM02) ;
}
