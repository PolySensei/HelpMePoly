#include "../includes/AjustementPWM.h"

void ajustementPWM ( uint8_t puissanceGauche, uint8_t puissanceDroite, int test/*std::string mode*/) {
	// Port D en mode sortie
	DDRD=0xFF;
	// 
	TCCR1A = 0xA1;
	/*
	if(mode == "AVANCER")
	{
		// Port D à 0
		PORTD = 0x00;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);
	};
	if(mode == "RECULER")
	{
		// On active les pins "Direction" des deux moteurs à 1 (la direction est inversée)
		PORTD |= 0xC0;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);	
	};

	if(mode == "GAUCHE")
	{
		// On active la pin "Direction" du moteur de gauche
		// donc moteur gauche va vers l'arrière 
		// et moteur droit va vers l'avant
		PORTD |= 0x40;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	};

	if(mode == "DROITE")
	{
		// On active la pin "Direction" du moteur de droite
		// donc moteur droit va vers l'arrière 
		// et moteur gauche va vers l'avant
		PORTD |= 0x80;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	};*/
	if(test == 0)
	{
		// Port D à 0
		PORTD = 0x00;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);
	}
	if(test == 1)
	{
		// On active les pins "Direction" des deux moteurs à 1 (la direction est inversée)
		PORTD |= 0xC0;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);	
	}

	if(test == 2)
	{
		// On active la pin "Direction" du moteur de gauche
		// donc moteur gauche va vers l'arrière 
		// et moteur droit va vers l'avant
		PORTD |= 0x40;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	}

	if(test == 3)
	{
		// On active la pin "Direction" du moteur de droite
		// donc moteur droit va vers l'arrière 
		// et moteur gauche va vers l'avant
		PORTD |= 0x80;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);	
	}
}
