#include "../includes/Reculer.h"

void reculer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 1);	
}
