#include "../includes/TournerGauche.h"

void tournerGauche(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 2);	
}
