#include "../includes/Avancer.h"

void avancer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, 0);	
}
