#include "../includes/LumiereClignotante.h"

void lumiereClignotante(uint8_t compteur, uint8_t couleur, uint8_t intervalle)
{

	for(int i =0; i<compteur; i++)
	{
		
		allumerLumiere(couleur);
		_delay_ms(20);
		PORTB = 0x00;
		_delay_ms(20);
	}
}
