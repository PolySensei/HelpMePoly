
#include <avr/io.h>

#include "includes/AllumerLumiere.h"
#include "includes/TournerGauche.h"



int main() {
	// mode sortie
	DDRB= 0xFF;

	// mode entrée
	DDRD= 0x00;

	allumerLumiere(1);

	tournerGauche(0,1);

	return 0;
}
