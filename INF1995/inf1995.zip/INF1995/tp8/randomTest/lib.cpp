#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>		// Nécessaire pour utiliser la commande "_delay_ms()"
#include <avr/interrupt.h>	// Nécessaire pour les interruptions	

#include "can.h"	// Conversion analogique numérique
#include "memoire_24.h"   // Nécessaire pour effectuer des opérations sur la mémoire


#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03

// **********************************DEL**************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************

void allumerLumiere(uint8_t couleur)
{
	switch(couleur)
	{
		case VERT:
		{
			PINB = VERT;
		}

		case ROUGE:
		{
			PINB = ROUGE;
		}

		case AMBRE:
		{
			PINB = 0x01;        // DEL rouge
          		_delay_ms(3);

           		PINB = 0x02;        // DEL verte
           		_delay_ms(17);	
		}
	}
          
}

// Fait clignoter la lumière X fois dans une période Y avec la couleur choisie
// X : compteur , Y : intervalle
void lumiereClignotante(uint8_t compteur, uint8_t couleur, uint8_t intervalle)
{

	for(int i =0; i<compteur; i++)
	{
		
		allumerLumiere(uint8_t couleur);
		_delay_ms(500/(compteur/intervalle));
		PORTB = 0x00;
		_delay_ms(500/(compteur/intervalle));
	}
}

// ******************************Conversion analogique numérique**************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************


uint8_t conversion16a8bits(uint16_t resultat)
{
// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);
}


// **********************************************Moteurs**********************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************

// Ajustement PWM

void ajustementPWM ( uint8_t puissanceGauche, uint8_t puissanceDroite, string mode) {
	// Port D en mode sortie
	DDRD=0xFF;
	// 
	TCCR1A = 0xA1;
	
	if(mode == "AVANCER")
	{
		// Port D à 0
		PORTD = 0x00;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);
	}
	if(mode == "RECULER")
	{
		// On active les pins "Direction" des deux moteurs à 1 (la direction est inversée)
		PORTD |= 0xC0;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);	
	}

	if(mode == "GAUCHE")
	{
		// On active la pin "Direction" du moteur de gauche
		// donc moteur gauche va vers l'arrière 
		// et moteur droit va vers l'avant
		PORTD |= 0x40;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	}

	if(mode == "DROITE")
	{
		// On active la pin "Direction" du moteur de droite
		// donc moteur droit va vers l'arrière 
		// et moteur gauche va vers l'avant
		PORTD |= 0x80;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	}
}


// Avancer

void avancer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, "AVANCER");	
}

// Reculer

void reculer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, "RECULER");	
}

// Tourner vers la gauche

void tournerGauche(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, "GAUCHE");	
}

// Tourner vers la droite

void tournerDroite(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, "DROITE");	
}

// Prescaler à 1024 + mode CTC (Clear counter on compare match)
void setPrescaler1024() 
{
	TCCR1B = ((1<<CS02) | (1<<CS00)) | (1<<WGM02) ;
}



// ******************************can.h****************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
can::can()
{
   // ADC mux : reference analogique externe
   //           ajuste a droite
   ADMUX  = ( 0 << REFS1 ) | ( 0 << REFS0 ) | ( 0 << ADLAR ) | ( 0 << MUX4 ) |
            ( 0 << MUX3 ) | ( 0 << MUX2 ) | ( 0 << MUX1) | ( 0 << MUX0 ) ;

   // ADC Status and Control Register A : 
   //  Active le convertisseur mais sans demarrer de conversion pour l'instant.
   //  Pas de declanchement automatique et aucune interruption suivant
   //  la fin d'une convertion. Division de l'horloge par 64 (il faudra
   //  donc 13 cycles du convertisseur * 64 pour terminer une conversion
   //  soit 832 cycles d'horloge soit 104 micro-secondes
   ADCSRA = ( 1 << ADEN ) | ( 0 << ADSC )  | ( 0 << ADATE ) | ( 0 << ADIF ) |
            ( 0 << ADIE ) | ( 1 << ADPS2 ) | ( 1 << ADPS1 ) | ( 0 << ADPS0 ) ;
}

// Destructeur:  Arreter le convertisseur pour sauver sur la consommation.
can::~can()
{
   // rendre le convertisseur inactif.
   ADCSRA = 0 << ADEN ;
}

uint16_t
can::lecture( uint8_t pos)
{
   uint16_t adcVal;

   // Garder les bits de ADMUX intacts, sauf les bit permettant 
   // la selection de l'entree
   ADMUX  &=  ~(( 1 << MUX4 ) | ( 1 << MUX3 ) | 
                ( 1 << MUX2 ) | ( 1 << MUX1)  | ( 1 << MUX0 ));

   // selectionner l'entree voulue
   ADMUX |= ((pos & 0x07) << MUX0) ;

   // demarrer la conversion
   ADCSRA |= ( 1 << ADSC );

   // Attendre la fin de la conversion soit 13 cycles du convertisseur.
   while( ! (ADCSRA & ( 1 << ADIF ) ) );

   // important: remettre le bit d'indication de fin de cycle a zero 
   // pour la prochaine conversion ce qui se fait en l'ajustant a un.
   ADCSRA |= (1 << ADIF);

   // Aller chercher le resultat sur 16 bits.
   adcVal =   ADCL ;
   adcVal +=  ADCH << 8;

   // resultat sur 16 bits
   return adcVal;
}


// **************************************memory_24.h**************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************


uint8_t Memoire24CXXX::m_adresse_peripherique = 0xA0;

/******************************************************************************/
/* void Memoire24CXXX::Memoire24CXXX()                                        */
/*                                                                            */
/*      Constructeur: ajuste la taille de la page et procede a                */
/*                    l'initialisation                                        */
/*                                                                            */
/* Parametre d'entree  : aucun                                                */
/* Parametre de sortie : aucun                                                */
/******************************************************************************/
Memoire24CXXX::Memoire24CXXX()
  : PAGE_SIZE(128)
{
   init();
}


/******************************************************************************/
/* void Memoire24CXXX::~Memoire24CXXX()                                       */
/*                                                                            */
/*      Destructeur: ne fait rien                                             */
/*                                                                            */
/* Parametre d'entree  : aucun                                                */
/* Parametre de sortie : aucun                                                */
/******************************************************************************/
Memoire24CXXX::~Memoire24CXXX()
{
   // rien a faire... 
}


/******************************************************************************/
/* void Memoire24CXXX::init(void)                                             */
/*                                                                            */
/*      Initialisation du port serie et de l'horloge de l'interface I2C       */
/*                                                                            */
/* Parametre d'entree  : aucun                                                */
/* Parametre de sortie : aucun                                                */
/******************************************************************************/
void Memoire24CXXX::init()
{
   choisir_banc(0);
   // Initialisation de l'horloge de l'interface I2C
   TWSR = 0;
   // prediviseur
   TWBR =  (F_CPU / 100000UL - 16) / 2;

}

/******************************************************************************/
/* uint8_t Memoire24CXXX::choisir_banc(const uint8_t banc)                    */
/*                                                                            */
/*      Choisir un banc de memoire                                            */
/*                                                                            */
/* Parametre d'entree  : uint8_t banc - le banc de memoire a choisir          */
/* Parametre de sortie : uint8_t      - rv si c'est un succes, 255 si echec   */
/******************************************************************************/
uint8_t Memoire24CXXX::choisir_banc(const uint8_t banc)
{
   uint8_t temp = banc & 0x03;
   uint8_t rv = 255;
   if(banc == temp)
   {
      Memoire24CXXX::m_adresse_peripherique = (0xA0 | ( banc << 1 ));
      rv = Memoire24CXXX::m_adresse_peripherique;
   }
   return rv;
}


/******************************************************************************/
/*                Lecture sequentielle de l'eeprom I2C                        */
/*                                                                            */
/* Le microcontroleur est en mode maitre. Il realise un acquittement (ACK) de */
/* la memoire a la fin de chaque lecture a l'exception de la derniere ou il   */
/* n'acquitte pas la reception (NACK) pour que la memoire place la ligne SDA  */
/* a un niveau haut et libere le bus et il transmet ensuite la condition      */
/* d'arret.                                                                   */
/*                                                                            */
/* a la premiere etape on verifie si le cycle d'ecriture precedent est        */
/* termine. On transmet :                                                     */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande d'ecriture                         */
/*   Si le cycle d'ecriture precedent est en cours on recommence la sequence  */
/*                                                                            */
/* A la deuxieme etape on transmet :                                          */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresses physique        */
/*                              + commande d'ecriture                         */
/*   - L'adresse : poids fort suivi du poids faible                           */
/*                                                                            */
/* A la troisieme etape on transmet :                                         */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande de lecture                         */
/*                                                                            */
/* A la quatrieme etape on realise une lecture sequentielle :                 */
/*   - Lecture en boucle - Commande de depart de transmission avec ACK,       */
/*                         attente de reception et lecture de la donnee       */
/*   - Derniere lecture  - Commande de depart de transmission avec NACK,      */
/*                         attente de reception et lecture de la donnee       */
/*                         Le NACK indique a la memoire la fin du transfert   */
/*   - Transmission de la condition d'arret                                   */
/*                                                                            */
/* Parametres d'entree  : uint16_t adresse - adresse de debut de lecture      */
/*                        int longueur     - nombre de donnees a retourner    */
/*                                           (variante de la 2eme procedure)  */
/* Parametres de sortie : uint8_t *donnee  - donnees lues                     */
/*                                                                            */
/******************************************************************************/
uint8_t Memoire24CXXX::lecture(const uint16_t adresse, uint8_t *donnee)
{
  uint8_t rv = 0;

  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for (;;)
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
      ;

    TWDR = m_adresse_peripherique;    //controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);     // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
      ;
    if (TWSR==0x18)         // 0x18 = cycle d'ecriture termine
       break;
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
    ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR =  ( adresse >> 8 );            // 8 bits de poids fort de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                      // 8 bits de poids faible de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);       // R.�Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
    ;

  //_______________ Transmission de la condition de depart ________________
  //  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);    // Condition de fin
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;

  //__________________ Transmission du code de controle ___________________
  TWDR =  m_adresse_peripherique + 1;   // Controle - bit 0 a 1 lecture 
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;

  //________________________ Lecture de l'eeprom __________________________
  TWCR = _BV(TWINT) | _BV(TWEN);     // R.�Z., interrupt. - Depart de transm.+NACK
  while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
    ;
  *donnee = TWDR;

  //________________ Transmission de la condition d'arret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);
  return rv;
}


uint8_t Memoire24CXXX::lecture(const uint16_t adresse, uint8_t *donnee,
                               uint8_t longueur)
{
  uint8_t twcr;

  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for (;;)
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0) ;   // Attente de fin de transmission

    TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
       ;
    if (TWSR==0x18)                      // 0x18 = cycle d'ecriture termine
       break;
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)    // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;        // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR = adresse >> 8;                  // 8 bits de poids fort de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                       // 8 bits de poids faible de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR =  m_adresse_peripherique + 1;  // Controle - bit 0 a 1, lecture
  TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
     ;

  //________________________ Lecture de l'eeprom __________________________
  // La memoire transmet 8 bits de donnee et le recepteur transmet un
  // acquittement (ACK). Si c'est la derniere donnee le recepteur n'acquitte
  // pas la reception (NACK) et il transmet ensuite la condition de stop.
  // Le ACK est realisee par le recepteur en placant TWEA a 1 au lieu de le
  // laisser a 0.
  for (twcr = _BV(TWINT) | _BV(TWEN) | _BV(TWEA) ; longueur > 0; longueur--)
  {
      if (longueur == 1)
         twcr = _BV(TWINT) | _BV(TWEN);  // Derniere donnee, NACK
      TWCR = twcr;                       // R. a Z., interrupt. - Depart de transm.
      while ((TWCR & _BV(TWINT)) == 0) ; // Attente de fin de transmission
         *donnee++ = TWDR;               // Lecture
  }

  //________________ Transmission de la condition d'arret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);

  return 0;
}


/******************************************************************************/
/*                                                                            */
/*      ecriture d'un bloc de donnees en mode page dans l'eeprom I2C          */
/*                                                                            */
/* On ne peut ecrire qu'une seule page a la fois dans une eeprom et il faut   */
/* s'assurer de ne pas depasser cette limite pour eviter le repliement. Cette */
/* fonction se termine apres l'ecriture d'un bloc de donnees dans une seule   */
/* page. On doit la rappeler plusieurs fois si la longueur d'un bloc de       */
/* donnees depasse les limites d'une page.                                    */
/*                                                                            */
/* Les memoires eeprom i2c ne generent pas de signal d'acquittement pendant   */
/* un cycle d'ecriture. Pour s'assurer que l'eeprom est libre pour l'ecriture */
/* d'une ou de plusieurs nouvelles donnees, on transmet en boucle une         */
/* condition de depart et un octet de controle d'ecriture et on attend un     */
/* signal d'acquittement. On peut ensuite entreprendre la procedure           */
/* d'ecriture. Cette verification est placee au debut de la fonction car le   */
/* temps d'acces permet a la condition de stop precedente de se completer.    */
/*                                                                            */
/* A la premiere, etape on calcule la longueur maximum que l'on peut placer   */
/* dans une page afin d'eviter le repliement dans l'ecriture des donnees      */
/*                                                                            */
/* A la deuxieme etape, on verifie si le cycle d'ecriture precedent est       */
/* termine. On transmet :                                                     */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande d'ecriture                         */
/*   Si le cycle d'ecriture precedent est en cours on recommence la sequence  */
/*                                                                            */
/* A la troisieme etape, on transmet :                                        */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande d'ecriture                         */
/*                                                                            */
/* A la quatrieme etape, on ecrit la donnee :                                 */
/*   - Transmission de la donnee + commande de depart de transmission avec    */
/*     ACK et attente de fin de transmission.                                 */
/*   - Transmission de la condition d'arret pour demarrer le cycle d'ecriture */
/*                                                                            */
/* Parametres d'entree  : uint16_t adresse - adresse de debut de lecture      */
/*                        uint8_t *donnee  - donnees a ecrire dans l'eeprom   */
/*                        int longueur     - longueur du bloc de donnees      */
/* Parametre de sortie  : uint8_t rv       - nombre de donnees ecrites        */
/*                                                                            */
/******************************************************************************/
uint8_t Memoire24CXXX::ecriture(const uint16_t adresse, const uint8_t donnee)
{
  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for ( ; ; )
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
       ;

    TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
       ;

    if (TWSR==0x18)
       break;               // 0x18 = cycle d'ecriture termine
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)    // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;        // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR = adresse >> 8;                 // 8 bits de poids fort de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                      // 8 bits de poids faible de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________________ Transmission de la donnee ______________________
  TWDR = donnee;
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //________________ Transmission de la condition d'arret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);  // Demarrage du cycle d'ecriture

  return 0;
}


uint8_t Memoire24CXXX::ecriture(const uint16_t adresse, uint8_t *donnee,
                                const uint8_t longueur)
{
  uint8_t rv;
  uint16_t copieAdresse = adresse;
  uint8_t copieLongueur = longueur;
  do
  {
      rv = ecrire_page(copieAdresse, donnee, copieLongueur);
      copieAdresse += rv;      // On pointe une nouvelle page
      copieLongueur -= rv;     // On soustrait la partie ecrite precedemment
      donnee += rv;            // On avance le pointeur de donnees
  }
  while (copieLongueur > 0);

  return 0;
}


uint8_t Memoire24CXXX::ecrire_page(const uint16_t adresse, uint8_t *donnee,
                                   const uint8_t longueur)
{
  uint16_t addr_fin;
  uint8_t rv = 0;
  uint8_t copieLongueur = longueur;

  // Les operations suivantes permettent de tenir compte des limites
  // de grandeur d'une page afin d'eviter le repliement dans l'ecriture
  // des donnees

  if (adresse + longueur < (adresse | (PAGE_SIZE - 1)))
    addr_fin = adresse + longueur;
  else
    addr_fin = (adresse | (PAGE_SIZE - 1)) + 1;
  copieLongueur = addr_fin - adresse;


  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for ( ; ; )
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0) ;   // Attente de fin de transmission
    TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
       ;

    if (TWSR==0x18)
       break;               // 0x18 = cycle d'ecriture termine
  }

  //_______________ Transmission de la condition de depart ________________uint8_t Memoire24CXXX::m_adresse_peripherique = 0xA0;

/******************************************************************************/
/* void Memoire24CXXX::Memoire24CXXX()                                        */
/*                                                                            */
/*      Constructeur: ajuste la taille de la page et procede a                */
/*                    l'initialisation                                        */
/*                                                                            */
/* Parametre d'entree  : aucun                                                */
/* Parametre de sortie : aucun                                                */
/******************************************************************************/
Memoire24CXXX::Memoire24CXXX()
  : PAGE_SIZE(128)
{
   init();
}


/******************************************************************************/
/* void Memoire24CXXX::~Memoire24CXXX()                                       */
/*                                                                            */
/*      Destructeur: ne fait rien                                             */
/*                                                                            */
/* Parametre d'entree  : aucun                                                */
/* Parametre de sortie : aucun                                                */
/******************************************************************************/
Memoire24CXXX::~Memoire24CXXX()
{
   // rien a faire... 
}


/******************************************************************************/
/* void Memoire24CXXX::init(void)                                             */
/*                                                                            */
/*      Initialisation du port serie et de l'horloge de l'interface I2C       */
/*                                                                            */
/* Parametre d'entree  : aucun                                                */
/* Parametre de sortie : aucun                                                */
/******************************************************************************/
void Memoire24CXXX::init()
{
   choisir_banc(0);
   // Initialisation de l'horloge de l'interface I2C
   TWSR = 0;
   // prediviseur
   TWBR =  (F_CPU / 100000UL - 16) / 2;

}

/******************************************************************************/
/* uint8_t Memoire24CXXX::choisir_banc(const uint8_t banc)                    */
/*                                                                            */
/*      Choisir un banc de memoire                                            */
/*                                                                            */
/* Parametre d'entree  : uint8_t banc - le banc de memoire a choisir          */
/* Parametre de sortie : uint8_t      - rv si c'est un succes, 255 si echec   */
/******************************************************************************/
uint8_t Memoire24CXXX::choisir_banc(const uint8_t banc)
{
   uint8_t temp = banc & 0x03;
   uint8_t rv = 255;
   if(banc == temp)
   {
      Memoire24CXXX::m_adresse_peripherique = (0xA0 | ( banc << 1 ));
      rv = Memoire24CXXX::m_adresse_peripherique;
   }
   return rv;
}


/******************************************************************************/
/*                Lecture sequentielle de l'eeprom I2C                        */
/*                                                                            */
/* Le microcontroleur est en mode maitre. Il realise un acquittement (ACK) de */
/* la memoire a la fin de chaque lecture a l'exception de la derniere ou il   */
/* n'acquitte pas la reception (NACK) pour que la memoire place la ligne SDA  */
/* a un niveau haut et libere le bus et il transmet ensuite la condition      */
/* d'arret.                                                                   */
/*                                                                            */
/* a la premiere etape on verifie si le cycle d'ecriture precedent est        */
/* termine. On transmet :                                                     */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande d'ecriture                         */
/*   Si le cycle d'ecriture precedent est en cours on recommence la sequence  */
/*                                                                            */
/* A la deuxieme etape on transmet :                                          */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresses physique        */
/*                              + commande d'ecriture                         */
/*   - L'adresse : poids fort suivi du poids faible                           */
/*                                                                            */
/* A la troisieme etape on transmet :                                         */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande de lecture                         */
/*                                                                            */
/* A la quatrieme etape on realise une lecture sequentielle :                 */
/*   - Lecture en boucle - Commande de depart de transmission avec ACK,       */
/*                         attente de reception et lecture de la donnee       */
/*   - Derniere lecture  - Commande de depart de transmission avec NACK,      */
/*                         attente de reception et lecture de la donnee       */
/*                         Le NACK indique a la memoire la fin du transfert   */
/*   - Transmission de la condition d'arret                                   */
/*                                                                            */
/* Parametres d'entree  : uint16_t adresse - adresse de debut de lecture      */
/*                        int longueur     - nombre de donnees a retourner    */
/*                                           (variante de la 2eme procedure)  */
/* Parametres de sortie : uint8_t *donnee  - donnees lues                     */
/*                                                                            */
/******************************************************************************/
uint8_t Memoire24CXXX::lecture(const uint16_t adresse, uint8_t *donnee)
{
  uint8_t rv = 0;

  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for (;;)
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
      ;

    TWDR = m_adresse_peripherique;    //controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);     // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
      ;
    if (TWSR==0x18)         // 0x18 = cycle d'ecriture termine
       break;
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
    ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR =  ( adresse >> 8 );            // 8 bits de poids fort de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                      // 8 bits de poids faible de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);       // R.�Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
    ;

  //_______________ Transmission de la condition de depart ________________
  //  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);    // Condition de fin
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;

  //__________________ Transmission du code de controle ___________________
  TWDR =  m_adresse_peripherique + 1;   // Controle - bit 0 a 1 lecture 
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
    ;

  //________________________ Lecture de l'eeprom __________________________
  TWCR = _BV(TWINT) | _BV(TWEN);     // R.�Z., interrupt. - Depart de transm.+NACK
  while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
    ;
  *donnee = TWDR;

  //________________ Transmission de la condition d'arret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);
  return rv;
}


uint8_t Memoire24CXXX::lecture(const uint16_t adresse, uint8_t *donnee,
                               uint8_t longueur)
{
  uint8_t twcr;

  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for (;;)
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0) ;   // Attente de fin de transmission

    TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
       ;
    if (TWSR==0x18)                      // 0x18 = cycle d'ecriture termine
       break;
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)    // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;        // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR = adresse >> 8;                  // 8 bits de poids fort de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                       // 8 bits de poids faible de l'addresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR =  m_adresse_peripherique + 1;  // Controle - bit 0 a 1, lecture
  TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
     ;

  //________________________ Lecture de l'eeprom __________________________
  // La memoire transmet 8 bits de donnee et le recepteur transmet un
  // acquittement (ACK). Si c'est la derniere donnee le recepteur n'acquitte
  // pas la reception (NACK) et il transmet ensuite la condition de stop.
  // Le ACK est realisee par le recepteur en placant TWEA a 1 au lieu de le
  // laisser a 0.
  for (twcr = _BV(TWINT) | _BV(TWEN) | _BV(TWEA) ; longueur > 0; longueur--)
  {
      if (longueur == 1)
         twcr = _BV(TWINT) | _BV(TWEN);  // Derniere donnee, NACK
      TWCR = twcr;                       // R. a Z., interrupt. - Depart de transm.
      while ((TWCR & _BV(TWINT)) == 0) ; // Attente de fin de transmission
         *donnee++ = TWDR;               // Lecture
  }

  //________________ Transmission de la condition d'arret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);

  return 0;
}


/******************************************************************************/
/*                                                                            */
/*      ecriture d'un bloc de donnees en mode page dans l'eeprom I2C          */
/*                                                                            */
/* On ne peut ecrire qu'une seule page a la fois dans une eeprom et il faut   */
/* s'assurer de ne pas depasser cette limite pour eviter le repliement. Cette */
/* fonction se termine apres l'ecriture d'un bloc de donnees dans une seule   */
/* page. On doit la rappeler plusieurs fois si la longueur d'un bloc de       */
/* donnees depasse les limites d'une page.                                    */
/*                                                                            */
/* Les memoires eeprom i2c ne generent pas de signal d'acquittement pendant   */
/* un cycle d'ecriture. Pour s'assurer que l'eeprom est libre pour l'ecriture */
/* d'une ou de plusieurs nouvelles donnees, on transmet en boucle une         */
/* condition de depart et un octet de controle d'ecriture et on attend un     */
/* signal d'acquittement. On peut ensuite entreprendre la procedure           */
/* d'ecriture. Cette verification est placee au debut de la fonction car le   */
/* temps d'acces permet a la condition de stop precedente de se completer.    */
/*                                                                            */
/* A la premiere, etape on calcule la longueur maximum que l'on peut placer   */
/* dans une page afin d'eviter le repliement dans l'ecriture des donnees      */
/*                                                                            */
/* A la deuxieme etape, on verifie si le cycle d'ecriture precedent est       */
/* termine. On transmet :                                                     */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande d'ecriture                         */
/*   Si le cycle d'ecriture precedent est en cours on recommence la sequence  */
/*                                                                            */
/* A la troisieme etape, on transmet :                                        */
/*   - La condition de depart                                                 */
/*   - Une donnee de controle : code de la memoire + adresse physique         */
/*                              + commande d'ecriture                         */
/*                                                                            */
/* A la quatrieme etape, on ecrit la donnee :                                 */
/*   - Transmission de la donnee + commande de depart de transmission avec    */
/*     ACK et attente de fin de transmission.                                 */
/*   - Transmission de la condition d'arret pour demarrer le cycle d'ecriture */
/*                                                                            */
/* Parametres d'entree  : uint16_t adresse - adresse de debut de lecture      */
/*                        uint8_t *donnee  - donnees a ecrire dans l'eeprom   */
/*                        int longueur     - longueur du bloc de donnees      */
/* Parametre de sortie  : uint8_t rv       - nombre de donnees ecrites        */
/*                                                                            */
/******************************************************************************/
uint8_t Memoire24CXXX::ecriture(const uint16_t adresse, const uint8_t donnee)
{
  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for ( ; ; )
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
       ;

    TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
       ;

    if (TWSR==0x18)
       break;               // 0x18 = cycle d'ecriture termine
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)    // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;        // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR = adresse >> 8;                 // 8 bits de poids fort de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                      // 8 bits de poids faible de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________________ Transmission de la donnee ______________________
  TWDR = donnee;
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //________________ Transmission de la condition d'arret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN);  // Demarrage du cycle d'ecriture

  return 0;
}


uint8_t Memoire24CXXX::ecriture(const uint16_t adresse, uint8_t *donnee,
                                const uint8_t longueur)
{
  uint8_t rv;
  uint16_t copieAdresse = adresse;
  uint8_t copieLongueur = longueur;
  do
  {
      rv = ecrire_page(copieAdresse, donnee, copieLongueur);
      copieAdresse += rv;      // On pointe une nouvelle page
      copieLongueur -= rv;     // On soustrait la partie ecrite precedemment
      donnee += rv;            // On avance le pointeur de donnees
  }
  while (copieLongueur > 0);

  return 0;
}


uint8_t Memoire24CXXX::ecrire_page(const uint16_t adresse, uint8_t *donnee,
                                   const uint8_t longueur)
{
  uint16_t addr_fin;
  uint8_t rv = 0;
  uint8_t copieLongueur = longueur;

  // Les operations suivantes permettent de tenir compte des limites
  // de grandeur d'une page afin d'eviter le repliement dans l'ecriture
  // des donnees

  if (adresse + longueur < (adresse | (PAGE_SIZE - 1)))
    addr_fin = adresse + longueur;
  else
    addr_fin = (adresse | (PAGE_SIZE - 1)) + 1;
  copieLongueur = addr_fin - adresse;


  //______________ Attente de la fin d'un cycle d'ecriture ______________
  for ( ; ; )
  {
    TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);    // Condition de depart
    while ((TWCR & _BV(TWINT)) == 0) ;   // Attente de fin de transmission
    TWDR = m_adresse_peripherique;       // Controle - bit 0 a 0, ecriture
    TWCR = _BV(TWINT) | _BV(TWEN);       // R. a Z., interrupt. - Depart de transm.
    while ((TWCR & _BV(TWINT)) == 0)     // Attente de fin de transmission
       ;

    if (TWSR==0x18)
       break;               // 0x18 = cycle d'ecriture termine
  }

  //_______________ Transmission de la condition de depart ________________
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)       // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;        // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR = adresse >> 8;                  // 8 bits de poids fort de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                       // 8 bits de poids faible de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________________ Transmission de la page ______________________
  for ( ; copieLongueur > 0; copieLongueur--)
  {
     TWDR = *donnee++;
     TWCR = _BV(TWINT) | _BV(TWEN);     // R. a Z., interrupt. - Depart de transm.
     while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
        ;
     rv++;                              // Compteur de donnees
  }

  //________________ Transmission de la condition d'arrret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN); // Demarrage du cycle d'ecriture

  return rv;
}
  TWCR = _BV(TWINT) | _BV(TWSTA) | _BV(TWEN);     // Condition de depart
  while ((TWCR & _BV(TWINT)) == 0)       // Attente de fin de transmission
     ;

  //__________________ Transmission du code de controle ___________________
  TWDR = m_adresse_peripherique;        // Controle - bit 0 a 0, ecriture
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________ Transmission du poids fort de l'adresse ________________
  TWDR = adresse >> 8;                  // 8 bits de poids fort de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //_____________ Transmission du poids faible de l'adresse _______________
  TWDR = adresse;                       // 8 bits de poids faible de l'adresse
  TWCR = _BV(TWINT) | _BV(TWEN);        // R. a Z., interrupt. - Depart de transm.
  while ((TWCR & _BV(TWINT)) == 0)      // Attente de fin de transmission
     ;

  //______________________ Transmission de la page ______________________
  for ( ; copieLongueur > 0; copieLongueur--)
  {
     TWDR = *donnee++;
     TWCR = _BV(TWINT) | _BV(TWEN);     // R. a Z., interrupt. - Depart de transm.
     while ((TWCR & _BV(TWINT)) == 0)   // Attente de fin de transmission
        ;
     rv++;                              // Compteur de donnees
  }

  //________________ Transmission de la condition d'arrret _________________
  TWCR = _BV(TWINT) | _BV(TWSTO) | _BV(TWEN); // Demarrage du cycle d'ecriture

  return rv;
}
