/****************************************************************************
* Fichier: tp3-2.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 2
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table2.png



#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>   // Nécessaire pour utiliser la commande "_delay_ms()"
#include <avr/interrupt.h>

volatile uint8_t minuterieExpiree;
volatile uint8_t boutonPoussoir; 

volatile uint8_t state = 0; // Variable globale


void initialisation ( void ) {

	
	cli ();


	// Variables

	
	DDRD = 0x00; // PORT D est en mode entrée
  	DDRB = 0xFF; // PORT B est en mode sortie

	// Permettre les interruptions externes

	EIMSK |= _BV(INT0);

	// Sensibiliser les interruptions externes aux

	// changements de niveau du bouton-poussoir

	EICRA |= (1 << ISC00) ;

	sei ();

}


ISR (TIMER1_COMPA_vect) {

	minuterieExpiree = 1;

}


ISR (INT0_vect) {

	boutonPoussoir = 1;

	// anti-rebond

	_delay_ms(10);

}

void partirMinuterie ( uint16_t duree ) {

	minuterieExpiree = 0;

	// mode CTC du timer 1 avec horloge divisee par 1024

	// interruption apres la duree specifiee


	// Timer

	TCNT1 = 0 ;

	OCR1A = duree;

	TCCR1A = 0 ;

	//prescaler à 1024 + mode CTC

	TCCR1B = ((1<<CS02) | (1<<CS00)) | (1<<WGM02) ;

	TCCR1C = 0;

	// Timer/Counter1, Output Compare A Match Interrupt Enable

	TIMSK1 |= (1 << OCIE1A);

}



int main(){
        
initialisation();
	// 1E84 = 1 sec
	// 8000000 / 1024 (Prescaler)

 
    
	for(;;)  // boucle sans fin
	  {
		sei ();
		PORTB =0x00;
		boutonPoussoir =0;
		_delay_ms(2000);
		PINB = 0x01;
		_delay_ms(100);
		partirMinuterie(0x1E84); 
		PORTB =0x00;


		do {

		// attendre qu'une des deux variables soit modifiee

		// par une ou l'autre des interruptions.

		} while ( minuterieExpiree == 0 && boutonPoussoir == 0 );


		// Une interruption s'est produite. Arreter toute

		// forme d'interruption. Une seule reponse suffit.

		cli ();

		// Verifier la reponse
		
		if (boutonPoussoir ==1)
		{
			PINB=0x02;
			_delay_ms(1000);
			
		}
		else
		{
		
			PINB=0x01;
			_delay_ms(1000);
		}
	}

}






