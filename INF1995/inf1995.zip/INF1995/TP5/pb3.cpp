/****************************************************************************
* Fichier: tp3-2.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 2
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table2.png



#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>   // Nécessaire pour utiliser la commande "_delay_ms()"
#include <avr/interrupt.h>









void ajustementPWM ( uint8_t ratio ) {

	// mise a un des sorties OC1A et OC1B sur comparaison

	// reussie en mode PWM 8 bits, phase correcte

	// et valeur de TOP fixe a 0xFF (mode #1 de la table 16-5

	// page 130 de la description technique du ATmega324PA)

	TCCR1A = 0xA1;

	OCR1A = 0xFF *(ratio/100) ;

	OCR1B = 0xFF *(ratio/100) ;


	// division d'horloge par 8 - implique une frequence de PWM fixe

	TCCR1B = 0x02;

	TCCR1C = 0;

}

int main()
{
DDRD = 0xFF; // PORT D est en mode sortie
ajustementPWM(0);
_delay_ms(2000);
ajustementPWM(25);
_delay_ms(2000);
ajustementPWM(50);
_delay_ms(2000);
ajustementPWM(75);
_delay_ms(2000);
ajustementPWM(100);
_delay_ms(2000);
ajustementPWM(0);

return 0;
}
