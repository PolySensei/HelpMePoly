/****************************************************************************
* Fichier: tp3-2.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 2
****************************************************************************/





#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>   // Nécessaire pour utiliser la commande "_delay_ms()"
#include <avr/interrupt.h>

volatile uint8_t state = 0; // Variable globale


void initialisation ( void ) {

	
	cli ();


	// Variables

	
	DDRD = 0x00; // PORT D est en mode entrée
  	DDRB = 0xFF; // PORT B est en mode sortie

	// Permettre les interruptions externes

	EIMSK |= _BV(INT0);

	// Sensibiliser les interruptions externes aux

	// changements de niveau du bouton-poussoir

	EICRA |= (1 << ISC00) ;

	sei ();

}


ISR (INT0_vect) {

	_delay_ms ( 30 );

	// Se souvenir ici si le bouton est presse ou relache

	// changements d'etats tels que ceux de la

	// semaine precedente

	//'modifier ici'
	state++;
	if (state==6)
		state =0;

	// Voir la note plus bas pour comprendre cette instruction et son role

	EIFR |= (1 << INTF0) ;

}





int main(){
        
  initialisation();	//   
    
  for(;;)  // boucle sans fin
  {
   
	

    switch(state)
    {
        case 0:
        {
            PORTB = 0x00;
            PINB = 0x01;        // DEL rouge

            break;
        }
        

        case 1:               // DEL ambre
        {
            PORTB = 0x00;
            PINB = 0x01;        // DEL rouge
            _delay_ms(3);
            PORTB = 0x00;
            
            PINB = 0x02;        // DEL verte
            _delay_ms(17);
            PORTB = 0x00;
            
            break;
        }

        case 2:
        {
            PORTB = 0x00;
            PINB = 0x02;        // DEL verte

            break;
        }

        case 3:
        {
            PORTB = 0x00;
            PINB = 0x01;        // DEL rouge

            break;
        }

        case 4:
        {
        PORTB = 0x00;        // DEL éteinte

        break;
        }

        case 5:
        {
        PORTB = 0x00;
        PINB = 0x02;        // DEL verte

        break;
        }
    }
    _delay_ms(10); // Délai à chaque exécution de la boucle for (Anti-rebonds)

 }
 return 0;
}






