#define F_CPU 8000000
#define FREQ_CPU 8000000
#include <avr/io.h>
#include "lib.h"
#include "../includes/memoire_24.h"


#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03

#define AVANCER 0x10
#define RECULER 0x11
#define GAUCHE 0x12
#define DROITE 0x13

bool initialisation = true;
uint16_t tailleByteCode;
Memoire24CXXX mem;


// *************** PIEZO *********************



void PWMPiezo (double frequence)
{
	// COM0B1 , COM0B0 , WGM01, WGM00 sont actifs
	// COM0B1/C0M0B0 : set OC0B on compare match, clear OC0B at BOTTOM
	// WGM02/WGM01/WGM01 : Fast PWM, top = OCR0A
	TCCR0A = 0x33;
	// CS01 , CS00 et WGM02 sont actifs 
	// CS01/CS00 : Prescaler à 64
	TCCR0B = 0x0D;
	// OCR0A en MAX	
	OCR0A = frequence-1;
	OCR0B = OCR0A / 2 ; // PWM de 50%

}
void choisirFrequence(uint8_t note)
{
	uint8_t frequence[37]={71 , 67 , 63 ,60, 56, 53 , 50 ,47,45,42,40, 38, 36, 34, 32, 30, 28, 27,25, 24, 23, 	21, 20,19, 18 , 17, 16,15, 14, 	14, 13, 12, 11, 10, 10, 9, 9};
	
	if (note == 0) {
		arreterPiezo();
	}
	else
	// Les notes commencent à 45 donc on fait -45
	// pour commencer à l'index 0
	PWMPiezo(frequence[note-45]);

}

void arreterPiezo()
{

   TCCR0B = 0x08; // Pour arreter.
   return;

}


void playSong1()
{
    DDRB = 0xff;
    int chanson[] = {72, 72, 79, 79, 69, 69, 72, 72, 65, 65, 69, 69, 67, 67, 71,71};
   
        for (int j=0; j<2; j++) {
        	for (int i=0; i<16; i++) 
       		{

        		int note = chanson[i];
			choisirFrequence(note-12);
           		_delay_ms(175);
			if (i%2 == 0)
			{
				arreterPiezo();
				_delay_ms(125);
			}		
			else
			{
				arreterPiezo();
				_delay_ms(25);
			}
    	
       		}
	}
        arreterPiezo();
        PORTB=0;
}

void playSong2()
{
	DDRB = 0xff;
	int melodie[]= { 60,60,60,60,59,58,59,60,61,62,62,62,62,61,60,61,62,63,65,64,60,64,63,62,61,60};
	int delay[]= { 10,10,10,1,1,1,1,1,10,10,10,10,1,1,1,1,1,5,8,8,1,1,1,1,1,1};
        
	for (int z=0; z<25; z++){
		int note2=melodie[z];
		choisirFrequence(note2);
		_delay_ms(150);
		for (int t=0;t<delay[t];t++)
		{
			arreterPiezo();
			_delay_ms(25);
		}
	}
}

void playSong3() // Grieg: In the Hall of the Mountain King
{
    DDRB = 0xff;
    int chanson[] = {52, 54, 55, 57, 59, 55, 59,59 , 58, 54, 58,58 , 57, 53, 57,57, 52, 54,55,57,59,55,59,64,62,59,55,59,62,62,0};
   
	// j = nombre de répétitions de la chanson
        for (int j=0; j<2; j++) 
	{
        	for (int i=0; i<31; i++) 
       		{
        		int note = chanson[i];
			choisirFrequence(note);
           		_delay_ms(200);	
		}
	}
        arreterPiezo();
        PORTB=0;
}

void sequenceDemarage()
{

	PORTC=0x04;
	_delay_ms(500);
	PORTC=0x08;
	_delay_ms(500);
	PORTC=0x04;
	_delay_ms(500);
	PORTC=0x08;
	_delay_ms(500);
	PORTC=0x00;
}

 void initialisationUSART ( void ) {

	// 2400 bauds. Nous vous donnons la valeur des deux

	// premier registres pour vous éviter des complications

	UBRR0H = 0;

	UBRR0L = 0xCF;

	// permettre la reception et la transmission par le UART0

	UCSR0A = 0x00;

	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	

	// Format des trames: 8 bits, 1 stop bits, none parity

	UCSR0C = (0<<UPM01)|(0<<UPM00)|(0<<USBS0)|(1<<UCSZ01)|(1<<UCSZ00) ;

}

uint8_t USART_Receive(void){
	/* Wait for data to be receives */
	while( !(UCSR0A & (1<<RXC0)) ) {}

	/*Get and return received data from buffer*/
	return UDR0;
}


int main()
{

	//Initialisation de l' USART
	//initialisationUSART();
	// Initialisation des ports

	// moteurs (sortie)
	DDRD = 0xFF;
	PORTD=0x00;
	// Piezo (sortie)
	DDRB = 0xFF;
	// Lumiere (sortie)
	DDRC = 0xFF;

	// Initialisation des variables
	uint8_t *instruction=0; 
	uint8_t *parametre=0;
	uint8_t compteur=0;
	uint8_t adresseMem=0; 
	uint8_t donne=0;
	
	bool enMarche = false;
	bool enBoucle = false;
	bool sonnerie = false;
	bool recule = false;

	// Lecture des 2 premiers octets du fichier pour obtenir la taille
	mem.lecture(0,&donne);
	tailleByteCode = donne << 8;
	mem.lecture(1,&donne);
	tailleByteCode = tailleByteCode + donne - 2;
	
	// À chaque itération
	// on saute de 2 byte pour obtenir la prochaine instruction
	for (uint16_t i=0; i < tailleByteCode ; i= i+2)
	{
		// Lecture de la mémoire du robot
		// l'instruction lue est stocké dans le ptr instruction
		mem.lecture(i,instruction);
		_delay_ms(5);

		if((*instruction) == 0x01 || enMarche)
		{
			switch (*instruction)
			{
				// DEBUT
				case 0x01:
				{
					PORTD=0x00;
					// Permet de rester dans le case
					enMarche = true;
					sequenceDemarage();
					//*************playSong3();
					break;
				}
				// ATTENDRE
				// On attend (X * 25) ms
				case 0x02:
				{
					// Lecture de la mémoire
					// la valeur lue est stocké dans le ptr parametre
					// i+1 permet d'accéder au paramètre
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					for (int i =0; i < *parametre; i++)
						_delay_ms(25);
					break;
				}
				//ALLUMER
				case 0x44:
				{
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					// On active les pins spécifiées par le parametre en entrée
					// sans modifié le reste du port
					PORTC = PORTC | *parametre; 
					break;
				}
				// ÉTEINDRE
				case 0x45:
				{
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					// On inverse le parametre d'entrée
					// et on effectue un OU binaire
					// pour fermer uniquement les bits de parametre
					uint8_t temp = ~(*parametre);
					PORTC = PORTC & temp;
					break;
				}
				// ACTIVER SONORITÉ
				case 0x48:
				{
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					sonnerie = true;
					choisirFrequence(*parametre);
					break;
				}
				// ARRETER SONORITÉ
				case 0x09:
				{
					sonnerie = false;
   					arreterPiezo();
					break;
				}
				// ARRETER MOTEURS
				case 0x60:
				{
					recule = false;
					ajustementPWM(0,0,0x10);
					break;
				}
				// ARRETER MOTEURS
				case 0x61:
				{
					recule = false;
					ajustementPWM(0,0,0x10);
					break;
				}
				// AVANCER
				case 0x62:
				{
					recule = false;
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					*parametre = (*parametre)*100/255;
					avancer(*parametre,*parametre);
					break;
				}
				// RECULER
				case 0x63:
				{
					recule = true;
					sonnerie = true;
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					*parametre = (*parametre)*100/255;
					reculer(*parametre,*parametre);
					_delay_ms(1000);
					choisirFrequence(75);
					break;
				}
				// TOURNER A DROITE
				case 0x64:
				{
					recule = false;
					tournerDroite(100,100);
					_delay_ms(500); // ***** À TESTER 
					ajustementPWM(0,0,0x12);
					break;
				}
				// TOURNER A GAUCHE
				case 0x65:
				{
					recule = false;
					tournerGauche(100,100);
					_delay_ms(500); // ***** À TESTER 
					ajustementPWM(0,0,0x13);
					break;
				}
				// DEBUT BOUCLE
				case 0xC0:
				{
					mem.lecture(i+1,parametre);
					_delay_ms(5);
					if (!enBoucle)
					{
						// compteur == nombre de répétitions de la boucle
						compteur = *parametre;
						// On sauvegarde l'addresse du début de la boucle
						adresseMem = i;
						// Éviter d'avoir 2 boucles imbriquées
						enBoucle = true;
					}
					break;
				}
				// FIN BOUCLE
				case 0xC1:
				{
					if (compteur != 0)
					{
						i = adresseMem;
						compteur--;
					}
					else 
						enBoucle = false;
					break;
				}
				// FIN
				case 0xFF:
				{
					enMarche = false;
					playSong3();
					break;
				}
			}
			// Joue une tonalité lorsqu'une instruction est prise
			if (enMarche && !sonnerie)
			{
				choisirFrequence(45);
				_delay_ms(100);
				arreterPiezo();
			}
			if (!recule && !sonnerie)
				arreterPiezo();
		}
	}

	return 0;
}
