#define F_CPU 8000000
#define FREQ_CPU 8000000
#include <avr/io.h>
#include "lib.h"
#include "../../includes/memoire_24.h"

 void initialisationUSART ( void ) {

	// 2400 bauds. Nous vous donnons la valeur des deux

	// premier registres pour vous éviter des complications

	UBRR0H = 0;

	UBRR0L = 0xCF;

	// permettre la reception et la transmission par le UART0

	UCSR0A = 0x00;

	UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	

	// Format des trames: 8 bits, 1 stop bits, none parity

	UCSR0C = (0<<UPM01)|(0<<UPM00)|(0<<USBS0)|(1<<UCSZ01)|(1<<UCSZ00) ;

}

uint8_t USART_Receive(void){
	/* Wait for data to be receives */
	while( !(UCSR0A & (1<<RXC0)) ) {}

	/*Get and return received data from buffer*/
	return UDR0;
}

int main(){
	uint16_t tailleByteCode;
	uint8_t donne;
	Memoire24CXXX mem;
	initialisationUSART();
	tailleByteCode = USART_Receive() << 8;
	tailleByteCode = tailleByteCode + USART_Receive() - 2;
	for (uint16_t i=0; i<tailleByteCode; i++){
		donne=USART_Receive();
		mem.ecriture(i,donne);
		_delay_ms(5);
	}
}
