#define F_CPU 8000000UL
#include <avr/io.h> 
#include <util/delay.h>

void allumerLumiere(uint8_t couleur);
void lumiereClignotante(uint8_t compteur, uint8_t couleur);
void setPrescaler1024();
uint8_t conversion16a8bits(uint16_t resultat);
void ajustementPWM ( uint8_t powerPercentRight, uint8_t powerPercentLeft, uint8_t mode, int delay );
void avancer(uint8_t puissanceGauche, uint8_t puissanceDroite);
void reculer(uint8_t puissanceGauche, uint8_t puissanceDroite);
void tournerGauche(uint8_t puissanceGauche, uint8_t puissanceDroite);
void tournerDroite(uint8_t puissanceGauche, uint8_t puissanceDroite);
