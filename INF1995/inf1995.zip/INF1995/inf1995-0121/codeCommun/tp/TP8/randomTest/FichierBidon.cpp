

#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03


#include "lib.h"




int main() {
// mode sortie
DDRB= 0xFF;

// mode entrée
DDRD= 0x00;

allumerLumiere(AMBRE);

tournerGauche(0,1);

setPrescaler1024();

return 0;
}
