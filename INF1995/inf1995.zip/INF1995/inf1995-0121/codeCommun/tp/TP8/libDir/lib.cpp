#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>		// Nécessaire pour utiliser la commande "_delay_ms()"
#include <avr/interrupt.h>	// Nécessaire pour les interruptions	



#define ROUGE 0x01
#define VERT 0x02
#define AMBRE 0x03

#define AVANCER 0x04
#define RECULER 0x05
#define GAUCHE 0x06
#define DROITE 0x07


// **********************************DEL**************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************

void allumerLumiere(uint8_t couleur)
{
	switch(couleur)
	{
		case VERT:
		{
			PINB = VERT;
		}

		case ROUGE:
		{
			PINB = ROUGE;
		}

		case AMBRE:
		{
			PINB = 0x01;        // DEL rouge
          		_delay_ms(3);

           		PINB = 0x02;        // DEL verte
           		_delay_ms(17);	
		}
	}
          
}

// Fait clignoter la lumière X fois dans une période Y avec la couleur choisie
// X : compteur , Y : intervalle
void lumiereClignotante(uint8_t compteur, uint8_t couleur)
{

	for(int i =0; i<compteur; i++)
	{
		
		allumerLumiere(couleur);
		_delay_ms(500);
		PORTB = 0x00;
		_delay_ms(500);
	}
}

// ******************************Conversion analogique numérique**************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************


uint8_t conversion16a8bits(uint16_t resultat)
{
// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);
	return resultat;
}


// **********************************************Moteurs**********************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************
// ***************************************************************************************

// Ajustement PWM

void ajustementPWM ( uint8_t puissanceGauche, uint8_t puissanceDroite, uint8_t mode) {
	// Port D en mode sortie
	DDRD=0xFF;
	// 
	TCCR1A = 0xA1;
	
	if(mode == AVANCER)
	{
		// Port D à 0
		PORTD = 0x00;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);
	}
	if(mode == RECULER)
	{
		// On active les pins "Direction" des deux moteurs à 1 (la direction est inversée)
		PORTD |= 0xC0;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);	
	}

	if(mode == GAUCHE)
	{
		// On active la pin "Direction" du moteur de gauche
		// donc moteur gauche va vers l'arrière 
		// et moteur droit va vers l'avant
		PORTD |= 0x40;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	}

	if(mode == DROITE)
	{
		// On active la pin "Direction" du moteur de droite
		// donc moteur droit va vers l'arrière 
		// et moteur gauche va vers l'avant
		PORTD |= 0x80;
		OCR1A = 0xFF * (puissanceDroite);
		OCR1B = 0xFF * (puissanceGauche);		
	}
}


// Avancer

void avancer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, AVANCER);	
}

// Reculer

void reculer(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, RECULER);	
}

// Tourner vers la gauche

void tournerGauche(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, GAUCHE);	
}

// Tourner vers la droite

void tournerDroite(uint8_t puissanceGauche, uint8_t puissanceDroite)
{
	ajustementPWM (puissanceGauche, puissanceDroite, DROITE);	
}

// Prescaler à 1024 + mode CTC (Clear counter on compare match)
void setPrescaler1024() 
{
	TCCR1B = ((1<<CS02) | (1<<CS00)) | (1<<WGM02) ;
}


