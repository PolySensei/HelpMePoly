/* Diagramme d etat
 Etats  PIND            PORTB
        0       1
  INIT  INIT    E1      0x00
  E1    E1      E2      0x00
  E2    E2      E3      0x00
  E3    E3      E4      0x00
  E4    E4      E5      0x00
  E5    INIT    INIT    0x02
*/


#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
using namespace std;

enum Etat {INIT, E1, E2, E3, E4, E5};
Etat etatSuivant(Etat etatSuivant, bool a){
    a=0;
    Etat etat;
    if(PIND & 0x04){
        a=1;
        _delay_ms(10);
        if((~PIND & 0x04) && a==1 )
            etat = etatSuivant;
    };
    return etat;
}
int main()
{
  DDRA = 0xff; // PORT A est en mode sortie
  DDRB = 0xff; // PORT B est en mode sortie
  DDRC = 0xff; // PORT C est en mode sortie
  DDRD = 0x00; // PORT D est en mode entree
  Etat etat = INIT;
  bool a=0;
for(;;){
  switch (etat){
    case INIT: PORTB=0x00;
                etat=etatSuivant(E1, a);
                break;
    case E1:PORTB=0x00;
              etat=etatSuivant(E2, a);
              break;
    case E2:PORTB=0x00;
            etat=etatSuivant(E3, a);
            break;
    case E3:PORTB=0x00;
            etat=etatSuivant(E4, a);
            break;
    case E4:PORTB=0x00;
            etat=etatSuivant(E5, a);
            break;
    case E5: PORTB=0x02;
            _delay_ms(1000);
            etat=INIT;
            break;
}
}

  return 0;
}
