/****************************************************************************
* Fichier: tp3-1.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 1
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table1.png



#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>    // Nécessaire pour utiliser la commande "_delay_ms()"




int main(){
 
  DDRD = 0x00; // PORT D est en mode entrée
  DDRB = 0xFF; // PORT B est en mode sortie
  bool alreadyPressed = false; 		
  int state = 0;
  
  for(;;)  // boucle sans fin
  {
 
	switch(state) 
	{
	case 0:
    		if (PIND & 0x04 && alreadyPressed==false)  // Vérifie que le bouton a été pressé et relâché
    		{
    			state = 1;
    			alreadyPressed = true;
   		}
    		break;

	case 1:
    		if (PIND & 0x04 && alreadyPressed==false)
    		{
    			state = 2;
   			alreadyPressed = true;
   		}
    		break;

	case 2:
    		if (PIND & 0x04 && alreadyPressed==false)
   		{
    			state = 3;
   			alreadyPressed = true;
   		}
   		break;

	case 3:
   		if (PIND & 0x04 && alreadyPressed==false)
   		{
   			state = 4;
   			alreadyPressed = true;
   		}
   		break;

	case 4:
   		if (PIND & 0x04 && alreadyPressed==false)
    		{
   			state = 0;
   		 	alreadyPressed = true;
   			PINB = 0x01;
    			_delay_ms(1000);   // Lumiere allumee pendant 1 sec
    			PORTB = 0x00;
    		}
   		break;


	}

	if (!(PIND & 0x04))      // Vérifie que le bouton est relâché
    		alreadyPressed = false;
	_delay_ms(100); // Anti-rebonds

 }
   return 0;
}
