/* Diagramme d etat
 Etats  PIND            PORTB
        0       1
  INIT  INIT    E1      0x02
  E1    E2      E1      Ambré
  E2    E2      E3      0x01
  E3    E4      E3      0x02
  E4    E4      E5      0x00
  E5    INIT    E5      0x01
*/


#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
using namespace std;

enum Etat {INIT, E1, E2, E3, E4, E5};
int main()
{
  DDRA = 0xff; // PORT A est en mode sortie
  DDRB = 0xff; // PORT B est en mode sortie
  DDRC = 0xff; // PORT C est en mode sortie
  DDRD = 0x00; // PORT D est en mode entree
  Etat etat = INIT;
  bool a=0;
for(;;){
  switch (etat){
    case INIT: PORTB=0x02;
                if (PIND & 0x04)
                    etat=E1;
                break;
    case E1:while(PIND!=0x00){
            PORTB = 0x01;
            _delay_ms(8);
            PORTB ^= 0x03;
            _delay_ms(2);
            }
            etat=E2;
            break;


    case E2:PORTB=0x01;
            if(PIND & 0x04){
                etat=E3;
            };
            break;
    case E3:while(PIND!=0x00){
                PORTB=0x02;
            }
            etat=E4;
            break;
    case E4:PORTB=0x00;
            if(PIND & 0x04){
                etat=E5;
            };
            break;
    case E5: while(PIND!=0x00){
                PORTB=0x01;
             }
            etat=INIT;
            break;
}
}

  return 0;
}
