/****************************************************************************
* Fichier: tp3-2.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 2
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table2.png



#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>   // Nécessaire pour utiliser la commande "_delay_ms()"



int main(){
 
  DDRD = 0x00; // PORT D est en mode entrée
  DDRB = 0xFF; // PORT B est en mode sortie
 
  int state = 0;                         
  
  for(;;)  // boucle sans fin
  {
 
    switch(state)
    {
        case 0:
        {
            PORTB = 0x00;
            PINB = 0x01;        // DEL rouge

            if (PIND & 0x04)
                state = 1;
            
            break;
        }
        

        case 1:               // DEL ambre
        {
            PORTB = 0x00;
            PINB = 0x01;        // DEL rouge
            _delay_ms(3);
            PORTB = 0x00;
            
            PINB = 0x02;        // DEL verte
            _delay_ms(17);
            PORTB = 0x00;

            if(!(PIND & 0x04))
                state = 2;
            
            break;
        }

        case 2:
        {
            PORTB = 0x00;
            PINB = 0x02;        // DEL verte

            if (PIND & 0x04)
                state = 3;
            
            break;
        }

        case 3:
        {
            PORTB = 0x00;
            PINB = 0x01;        // DEL rouge

            if (!(PIND & 0x04))
                state = 4;
            
            break;
        }

        case 4:
        {
        PORTB = 0x00;        // DEL éteinte

        if (PIND & 0x04)
            state = 5;
        
        break;
        }

        case 5:
        {
        PORTB = 0x00;
        PINB = 0x02;        // DEL verte

        if (!(PIND & 0x04))
            state = 0;
        break;
        }
    }
    _delay_ms(10); // Délai à chaque exécution de la boucle for (Anti-rebonds)

 }
 return 0;
}
