/********************************************************************************************
* Fichier: tp3-1.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1] et Saif Belhattab
* Date: 23 octobre 2016
* Mise a jour :  25 octobre 2016
* Description: Travail pratique No. 7 - Problème 1
********************************************************************************************/

#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>    // Nécessaire pour utiliser la commande "_delay_ms()"




int main(){
 
	DDRD = 0x00; // PORT D est en mode entrée
	DDRB = 0xFF; // PORT D est en mode sortie
	  	
	uint8_t compteur = 0;


	bool appuye = false;
	bool relache = false;

	for(;;)  // boucle sans fin
	{
		// Si le bouton est appuyé et que le compteur est inférieur à 120
		if ((PIND & 0x04) && compteur < 120)
		{
			compteur++;
			// incrémente 10 fois par seconde + ANTIREBONDS
			_delay_ms(100);	
			appuye = true;	
		}

		// Si le bouton a été appuyé et qu'il est maintenant relâché
		if (appuye && !(PIND & 0x04))
			relache = true;

		// Si le bouton est relache est vrai ou que le compteur atteint 120
		if (relache || compteur == 120)
		{
			// La lumière verte clignote pendant une demie seconde
			for(int i =0; i<10; i++)
			{
				PINB = 0x02;
				_delay_ms(25);
				PORTB = 0x00;
				_delay_ms(25);
			}
		
			// La carte mère ne fait rien pendant 2 secondes
			_delay_ms(2000);

			// La lumière rouge clignote 2 fois par seconde (compteur/2) fois
			for(int i =0; i<(compteur/2); i++)
			{
				PINB = 0x01;
				_delay_ms(250);
				PORTB = 0x00;
				_delay_ms(250);
			}

			// La lumière devient verte et s'éteint après une seconde
			PINB = 0x02;
			_delay_ms(1000);
			PORTB = 0x00;
		
			// On réinitialise les variables à leurs valeurs de base
			compteur =0;
			appuye = false;
	  		relache = false;
		
		}
	
	}
   	return 0;
}
