/************************************************************************************************
* Fichier: pb2.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) et Saif Belhattab 1687465 [ÉQUIPE 1]
* Date: 23 octobre 2016
* Mise a jour :  25 octobre 2016
* Description: Travail pratique No. 7 - Problème 2
************************************************************************************************/

#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>    // Nécessaire pour utiliser la commande "_delay_ms()"

#include "can.h"	// Nécessaire pour effectuer une conversion analogique numérique

uint8_t state =0;

// fonction
uint8_t updateState(uint16_t resultat)
{
	uint8_t stateTEMP=0;
	// On décale les 16 bits vers la droite puique les 2 derniers ne signifie rien
	resultat = resultat >> 2;
	// On met tous les 8 premiers bits à 0
	resultat &= 0x00FF;
	// On force notre valeur sur 8 bits
	resultat = uint8_t (resultat);

	// Maximum int sur 8 bits : 2⁸ -1 = 255 
	// On a 3 états (lumière basse/normale/forte)
	// donc 255 / 3 = 85
	
	// Lumière faible
	if(resultat <= 85)
		stateTEMP= 1;

	// Lumière moyenne
	else if(resultat > 85 && resultat <= 170)
		stateTEMP= 2;

	// Lumière forte
	else if(resultat > 170 && resultat <= 255)
		stateTEMP= 3;

	return stateTEMP;
}

int main(){
 
	DDRA = 0x00; // PORT A est en mode entrée
	DDRB = 0xFF; // PORT B est en mode sortie
	can conversion;	

	for(;;)  // boucle sans fin
	{
		state = updateState(conversion.lecture(PINA & 0x04));
		switch (state) 
		{
			case 1 :
			{
				// DEL vert
				PORTB = 0x01; 
				break;
			}

			case 2 :
			{
				// DEL ambre
			    	PORTB = 0x02;        
			   	_delay_ms(27);
			   	
			    
			   	PORTB = 0x01;       
			   	_delay_ms(3);
				break;
			}

			case 3 :
			{
				// DEL rouge
				PORTB = 0x02; 
				break;		
			}
		}	
		
	
	}
   	return 0;
}
