#define F_CPU 8000000UL
#include "Can.cpp"
#include "Can.h"
#include <util/delay.h>
#include <avr/io.h>
void read(uint16_t& valeur,can& adc){
	uint8_t pos=0x01;//PIN de lecture pour le capteur
	valeur=adc.lecture(pos)>>2;//>>2 Pour enelevr les deux bits de poids faible de la lecture
	valeur &= 0x00ff; // Applicatiopn d'un masque pour avoir seulement 8bits
}
void ambre(){
	PORTB=0x01;
	_delay_ms(5);
	PORTB=0x02;
	_delay_ms(3);

	}
int main(){
	DDRB = 0xff; // PORT B est en mode sortie
	DDRA = 0x00; // PORT A est en mode entree
	uint16_t valeurNum;
	can adc;

	for(;;){

		read(valeurNum,adc);
		while(valeurNum<=90){ //Tant que la luminosite est faible on prend vert
			PORTB=0x01; //Vert
			read(valeurNum,adc);
			}
		while(valeurNum>=91&&valeurNum<=185){ //Tant que la luminosité est ambiante on prend ambre
			ambre();
			read(valeurNum,adc);
			}
		while(valeurNum>=186){ //Tant que la luminosité est élevéee on prend rouge
			PORTB=0x02; //Rouge
			read(valeurNum,adc);
			}
		
	}
}
