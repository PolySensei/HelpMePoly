#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
using namespace std;



int main() {
	DDRA = 0xff; // PORT A est en mode sortie
	DDRB = 0xff; // PORT B est en mode sortie
	DDRC = 0xff; // PORT C est en mode sortie
	DDRD = 0x00; // PORT D est en mode entree
	for(;;){
		int compteur=0;
		bool a=0;

		if (PIND & 0x04){
        _delay_ms(10);
			if(PIND & 0x04){
				a=1;
			}
		}
		while ((PIND !=0x00) && (a==1)){
			compteur+=10;
			_delay_ms(1000);
			if (compteur == 120){
					PORTA=0x01;
					_delay_ms(500);
					PORTA=0x00;
					a=0;
				}
			}
		if(a==1){
			PORTA=0x01;
			_delay_ms(500);
			PORTA=0x00;
			a=0;
		}
		_delay_ms(2000);
		for (int i=0; i<(compteur/4);i++){
			PORTA=0x02;
			_delay_ms(250);
			PORTA=0x00;
			_delay_ms(250);
			PORTA=0x02;
			_delay_ms(250);
			PORTA=0x00;
			_delay_ms(250);
			}
		if (compteur>0){
			PORTA=0x01;
			_delay_ms(1000);
			PORTA=0x00;
		}

		
	}

	}

