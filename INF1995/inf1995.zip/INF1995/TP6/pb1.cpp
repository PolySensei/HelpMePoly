/****************************************************************************
* Fichier: tp3-2.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 2
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table2.png







#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>   // Nécessaire pour utiliser la commande "_delay_ms()"
#include "memoire_24.h"   // Nécessaire pour effectuer des opérations sur la mémoire


int main(){
        bool pareil=true;
	uint8_t chaine[] = {"E","C","O","L","E"," ","P","O","L","Y","T","E","C","H","N","I","Q","U","E",0x00};

	Memoire24CXXX memory;
	

	for(int i =0; i< 21; i++)
	{
		memory.ecriture(0x00, chaine[i]);
		_delay_ms(5);
	}

	//memory.ecriture(0x00, &chaine[0], 20);

	uint8_t resultat[20];

	memory.lecture(0x00, &resultat[0], 20);

	for (int i=0; ((i<20)&& pareil); i++)
	{
		if(chaine[i]!=resultat[i])
			pareil =false;

	}

	if (pareil)
		PINB=0x02;
	else
		PINB=0x01;

return 0;
}






