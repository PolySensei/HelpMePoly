/****************************************************************************
* Fichier: tp3-1.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 1
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table1.png



#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>    // Nécessaire pour utiliser la commande "_delay_ms()"




int main(){
 
  DDRD = 0x00; // PORT D est en mode entrée
  DDRB = 0xFF; // PORT B est en mode sortie
		
  int a=100;
  int c=0;
  
  for(;;)  // boucle sans fin
  {
 	for(int j=0; j<30;j++)
	{
		for(int i =0; i<a; i++)
		{
		PINB= 0x02;
		_delay_us(10);
		}

		for(int i =0;i<c;i++)
		{
		PORTB = 0x00;
		_delay_us(10);
		}
	}

	a --;
	c ++;

 }
   return 0;
}
