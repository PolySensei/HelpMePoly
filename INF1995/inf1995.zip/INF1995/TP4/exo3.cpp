/****************************************************************************
* Fichier: tp3-1.cpp
* Auteur: David Tremblay (1748125) et Alexandre Clark (1803508) [ÉQUIPE 1]
* Date: 14 septembre 2016
* Mise a jour :  19 septembre 2016
* Description: Travail pratique No. 3 - Problème 1
****************************************************************************/

// TABLE D'ÉTAT dans le fichier table1.png



#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>    // Nécessaire pour utiliser la commande "_delay_ms()"




int main(){
 
  DDRD = 0x00; // PORT D est en mode entrée
  DDRC = 0xFF; // PORT B est en mode sortie
		
  int a=0;
  int c=17;
  int d = 2500;
  int e=0;
  int state= 0;
  
  for(;;)  // boucle sans fin
  {
	if (PIND & 0x04)
		state=1;

	switch(state)
	{
		case 1 :
		{
		for(int j=0; j<118;j++)
		{
			for(int i =0; i<a; i++)
			{
				PINC= 0x02;
				_delay_ms(1);
			}

			for(int i =0;i<c;i++)
			{
				PORTC = 0x00;
				_delay_ms(1);
			}
		}

		a += 4;
		c -= 4;
		break;
		}

		
	case 0 :
	{
		for(int j=0; j<800;j++)
		{
			for(int i =0; i<e; i++)
			{
				PINC= 0x02;
				_delay_us(1);
			}

			for(int i =0;i<d;i++)
			{
				PORTC = 0x00;
				_delay_us(1);
			}
		}

		e += 600;
		d -= 600;
		break;
	}
}
 	

 }
   return 0;
}
