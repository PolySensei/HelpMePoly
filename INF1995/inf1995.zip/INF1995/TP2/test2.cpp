/*
 * Nom: compteur 32 bits
 * Copyright (C) 2005 Matthew Khouzam
 * License http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * Description: Ceci est un exemple simple de programme 
 * Version: 1.1
 */

#define F_CPU 8000000
#include <avr/io.h>
#include <util/delay.h>



int main(){
 
  DDRD = 0x00; // PORT D est en mode entrée
  DDRB = 0xFF; // PORT B est en mode sortie
  unsigned long compteur=0;
  
  for(;;)  // boucle sans fin
  {
	_delay_ms(100);

        if (PIND & 0x04)
	{
            compteur++;
	_delay_ms(100);
	}
           
        // ANti-rebonds

        if (compteur==5)
	{
	     for (;;){
	     
             PINB = 0x01;
	     _delay_ms(10);
	     PORTB = 0x00;
	     
	     PINB = 0x02;
             compteur =0;
	     _delay_ms(20);
	     PORTB = 0x00;
	    }
	}
	 PORTB = 0x00;
            
  }
   return 0;
}


