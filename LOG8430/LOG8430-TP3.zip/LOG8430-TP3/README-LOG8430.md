�quipe Papa:
F�lix Agagnier 1797592
Alexandre Clark 1803508
David Tremblay 1748125

------------------------------------------------------------

Les fichiers JAR sont dans "lib" ainsi que dans "src/demo/libs" (seul ceux dans ce dernier sont utilis�s lors de la compilation).

"src/demo" contient les memes classes de tests que avant le refactoring. En addition, les librairies sous forme de JARs ont �t� rajout� et sont incluses dans les tasks Gradle sous forme de dependance.
"src/minidraw-bckp" contient un backup du code source des JARs suite au refactoring.

Les m�thodes de tests sont comme avant le refactoring, c'est-�-dire les tasks Gradle dans "testing" (add, background, composite, etc...)

Le dossier Docs contient le fichier ODEM, MDG ainsi que plusieurs BUNCH (chaque niveau de clustering). Il est � noter que le fichier "MiniDraw.mdg.bunch" a �t� utilis� pour le refactoring.

Ce que nous avons trouv� bizarre:
Les outils �taient g�n�ralement bien et facile d'utilisation, pour ce laboratoire except� BUNCH.
Le probl�me de cet outil est au niveau des r�sultats. Il �tait fr�quent de voir la m�me classe appara�tre plusieurs foid dans le m�me packet, ou encore dans plusieurs packets diff�rents.
Nous avons donc, d� utiliser un syst�me de "priorit�" pour d�terminer dans quel packet les doublons vont.
De plus, il �tait difficile de comprendre o� trouver les niveaux de clustering, (il fallait avoir �x�cut� l'outil un fois et choisir apr�s l'�x�cution).