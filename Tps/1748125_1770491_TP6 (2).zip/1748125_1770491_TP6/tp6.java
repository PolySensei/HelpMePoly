package tp6;
import static org.junit.Assert.*;

import java.util.List;
import java.util.NoSuchElementException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;

import edu.princeton.cs.algs4.Bag;
import edu.princeton.cs.algs4.BipartiteX;
import edu.princeton.cs.algs4.BipartiteXExtended;
import edu.princeton.cs.algs4.Graph;
import edu.princeton.cs.algs4.GraphGenerator;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import org.junit.Test;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;

/** A class that contains an Implementation of integration tests OO according to ORD */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class tp6 {

	@BeforeClass public static void testSetup()  {}
	@AfterClass public static void testCleanup() {}

	// ------------------------------------------------------------------------------------ //
	// ----------------------------------- Tests FOR LEVEL 1 ------------------------------ //
	// ------------------------------------------------------------------------------------ //

	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------- Tests for StdOut -------------------------------- */
	/** ------------------------------------------------------------------------------------ */
	
	// Test StdOut println method with string.
	@Test public void LEVEL_1_StdOut_println_string() {
		StdOut.println("Test");
		assertEquals("println must not handle an exception", true, true);
	}
	
	// Test StdOut println method with number.
	@Test public void LEVEL_1_StdOut_println_number() {
		StdOut.println(19);
		assertEquals("println must not handle an exception", true, true);
	}
	
	// Test StdOut println method with boolean.
	@Test public void LEVEL_1_StdOut_println_boolean() {
		StdOut.println(true);
		assertEquals("println must not handle an exception", true, true);
	}
	
	// Test StdOut printf method.
	@Test public void LEVEL_1_StdOut_printf() {
		StdOut.printf("%.6f\n", 1.0/7.0);
		assertEquals("println must not handle an exception", true, true);
	}
	
	// ------------------------------------------------------------------------------------ //
	// ----------------------------------- Tests FOR LEVEL 2 ------------------------------ //
	// ------------------------------------------------------------------------------------ //
	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------- Tests for StdRandom ----------------------------- */
	/** ------------------------------------------------------------------------------------ */
	
	// Test StdRandom setseed and getseed methods.
	@Test public void LEVEL_2_StdRandom_getSeed() {
		StdRandom.setSeed(Long.parseLong("11"));
		assertEquals("getSeed must be 11", 11, StdRandom.getSeed());
	}
	
	// Test StdRandom uniform method.
	@Test public void LEVEL_2_StdRandom_uniform() {
		StdRandom.setSeed(Long.parseLong("11"));
		assertEquals("uniform must be 1", 1, StdRandom.uniform(13));
	}
	
	// Test StdRandom uniform method.
	@Test public void LEVEL_2_StdRandom_uniform_double() {
		assertNotNull("uniform must be not null", StdRandom.uniform(13));
	}
	
	// Test StdRandom uniform method.
	@Test public void LEVEL_2_StdRandom_uniform_long() {
		assertNotNull("uniform must be not null", StdRandom.uniform(100000000000L));
	}
	
	// Test StdRandom bernoulli method.
	@Test public void LEVEL_2_StdRandom_bernoulli() {
		assertEquals("bernoulli must be true", true , StdRandom.bernoulli(1.0));
	}
	
	// Test StdRandom gaussian method.
	@Test public void LEVEL_2_StdRandom_gaussian() {
		StdRandom.setSeed(Long.parseLong("11"));
		assertNotNull("gaussian must be not null",StdRandom.gaussian(1.0, 0.2));
	}

	// Test StdRandom discrete probabilities method.
	@Test public void LEVEL_2_StdRandom_discrete_probabilities() {
		double[] probabilities = { 0.5, 0.3, 0.1, 0.1 };
		assertNotNull("discrete must be not null", StdRandom.discrete(probabilities));
	}
	
	// Test StdRandom discrete frequencies method.
	@Test public void LEVEL_2_StdRandom_discrete_frequencies() {
		int[] frequencies = { 5, 3, 1, 1 };
		assertNotNull("discrete must be not null", StdRandom.discrete(frequencies));
	}
	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------- Tests for QUEUE --------------------------------- */
	/** ------------------------------------------------------------------------------------ */
	
	
	// Test Queue()	enqueue()	dequeue()	peek() Sequence for the attribute first .
	@Test(expected = NoSuchElementException.class)
	public void LEVEL_2_firstTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(11);
		queue.dequeue();
		queue.peek();
	}
	
	// Test Queue()	enqueue() peek() Sequence for the attribute first .
	@Test public void LEVEL_2_secondTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(11);
		queue.peek();
		assertEquals("peek must be 11", 11, queue.peek());
		assertEquals("first.item  must be 11", 11, queue.getFirst()); 
		assertEquals("last.item must be 11", 11, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
	}
	
	// Test Queue()	enqueue() isEmpty() Sequence for the attribute first .
	@Test public void LEVEL_2_thirdTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(13);
		queue.isEmpty();
		assertEquals("peek must be 13", 13, queue.peek());
		assertEquals("first.item  must be 13", 13, queue.getFirst()); 
		assertEquals("last.item must be 13", 13, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
		assertEquals("isEmpty must be false", false, queue.isEmpty()); 
	}
	
	// Test Queue()	enqueue() dequeue() isEmpty() Sequence for the attribute first .
	@Test public void LEVEL_2_fourthTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(13);
		queue.dequeue();
		queue.isEmpty();
		assertEquals("first.item  must be null", null, queue.getFirst()); 
		assertEquals("last.item must be null", null, queue.getLast()); 
		assertEquals("n must be 0", 0, queue.size()); 
		assertEquals("isEmpty must be true", true, queue.isEmpty()); 
	}
	
	// Test Queue()	enqueue() enqueue() toString() Sequence for the attribute first .
	@Test public void LEVEL_2_fifthTestSequence_first() {
		Queue queue = new Queue();
		queue.enqueue(13);
		queue.enqueue(15);
		assertEquals("peek must be 13", 13, queue.peek());
		assertEquals("first.item  must be 13", 13, queue.getFirst()); 
		assertEquals("last.item must be 15", 15, queue.getLast()); 
		assertEquals("n must be 2", 2, queue.size()); 
		assertEquals("toString must be '13 15'", "13 15 ", queue.toString()); 
	}
	

	// Test Queue()	enqueue()	dequeue()	toString () Sequence for the attribute last .
	@Test public void LEVEL_2_firstTestSequence_last() {
		Queue queue = new Queue();
		queue.enqueue(17);
		queue.dequeue();
		assertEquals("first.item  must be null", null, queue.getFirst()); 
		assertEquals("last.item must be null", null, queue.getLast()); 
		assertEquals("n must be 0", 0, queue.size()); 
		assertEquals("toString must be ''", "", queue.toString()); 
	}
	
	
	// Test Queue()	enqueue() toString() Sequence for the attribute last .
	@Test public void LEVEL_2_secondTestSequence_last() {
		Queue queue = new Queue();
		queue.enqueue(19);
		assertEquals("peek must be 19", 19, queue.peek());
		assertEquals("first.item  must be 19", 19, queue.getFirst()); 
		assertEquals("last.item must be 19", 19, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
		assertEquals("toString must be '19 '", "19 ", queue.toString()); 
	}
	
	
	// Test Queue()	dequeue() toString() Sequence for the attribute last .
	@Test(expected = NoSuchElementException.class)
	public void LEVEL_2_thirdTestSequence_last() {
		Queue queue = new Queue();
		queue.dequeue();
		queue.toString();
	}

	// Test Queue()	size()	enqueue ()	size()	dequeue()	toString ()	Size() Sequence for the attribute n .
	@Test public void LEVEL_2_firstTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.enqueue(21);
		queue.size();
		queue.dequeue();
		queue.toString();
		queue.size();
		assertEquals("first.item  must be null", null, queue.getFirst()); 
		assertEquals("last.item must be null", null, queue.getLast()); 
		assertEquals("n must be 0", 0, queue.size()); 
		assertEquals("toString must be ''", "", queue.toString()); 
	}
	
	// Test Queue()	size()	dequeue ()	size()	enqueue()	toString ()	Size() Sequence for the attribute n .
	@Test(expected = NoSuchElementException.class)
	public void LEVEL_2_secondTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.dequeue();
		queue.size();
		queue.enqueue(21);
		queue.toString();
		queue.size();
	}
	
	// Test Queue()	size()	enqueue ()	size ()	enqueue()	Size() Sequence for the attribute n .
	@Test public void LEVEL_2_thirdTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.enqueue(23);
		queue.size();
		queue.enqueue(39);
		queue.size();
		assertEquals("peek must be 23", 23, queue.peek());
		assertEquals("first.item  must be 23", 23, queue.getFirst()); 
		assertEquals("last.item must be 39", 39, queue.getLast()); 
		assertEquals("n must be 2", 2, queue.size()); 
		assertEquals("toString must be '23 39 '", "23 39 ", queue.toString()); 
	}
	
	// Test Queue()	size()	enqueue ()	size()	enqueue()	size ()	toString()	Dequeue()	Size() Sequence for the attribute n .
	@Test public void LEVEL_2_fourTestSequence_n() {
		Queue queue = new Queue();
		queue.size();
		queue.enqueue(23);
		queue.size();
		queue.enqueue(39);
		queue.size();
		queue.toString();
		queue.dequeue();
		queue.size();
		assertEquals("peek must be 39", 39, queue.peek());
		assertEquals("first.item  must be 39", 39, queue.getFirst()); 
		assertEquals("last.item must be 39", 39, queue.getLast()); 
		assertEquals("n must be 1", 1, queue.size()); 
		assertEquals("toString must be '39 '", "39 ", queue.toString()); 
	}
	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------- Tests for Bag ----------------------------------- */
	/** ------------------------------------------------------------------------------------ */
	
	// Test Bag Constructor method.
	@Test public void LEVEL_2_Bag_Constructor() {
		Bag<String> bag = new Bag<String>();
		assertNotNull("Bag Constructor must construct a valid bag", bag);
	}
	
	// Test Bag add method.
	@Test public void LEVEL_2_Bag_add() {
		Bag<String> bag = new Bag<String>();
        String item = "Test bag";
        bag.add(item);
        assertEquals("size of bag must be 1", 1, bag.size());
	}
	
	// ------------------------------------------------------------------------------------ //
	// ----------------------------------- Tests FOR LEVEL 3 ------------------------------ //
	// ------------------------------------------------------------------------------------ //
	
	/** ------------------------------------------------------------------------------------ */
	/** ---------------------------------- Tests for BipartiteX ---------------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test BipartiteX constructor method.
	@Test public void LEVEL_3_BipartiteX_Constructor() {
		Graph G = GraphGenerator.bipartite(1, 2, 2);
		BipartiteX b = new BipartiteX(G);
		assertNotNull("BipartiteX Constructor must construct a valid BipartiteX graph", b);
	}
	
	// Test BipartiteX constructor method with too many edges.
	@Test (expected = IllegalArgumentException.class)
	public void LEVEL_3_BipartiteX_Constructor_ManyEdges() {
		Graph G = GraphGenerator.bipartite(1, 2, 20);
		BipartiteX b = new BipartiteX(G);
		assertNotNull("BipartiteX Constructor must construct a valid BipartiteX graph", b);
	}
	
	
	// Test BipartiteX isBipartite method.
	@Test public void LEVEL_3_BipartiteX_isBipartite() {
		Graph G = GraphGenerator.bipartite(1, 7, 1);
		BipartiteX b = new BipartiteX(G);
		assertEquals("isBipartite must return true", true, b.isBipartite()); 
	}
	
	// Test BipartiteX check method.
	@Test public void LEVEL_3_BipartiteX_check() {
		Graph G = GraphGenerator.bipartite(1, 7, 0);
		BipartiteX b = new BipartiteX(G);
		assertEquals("color must return false", false, b.color(1)); 
	}
	
	
	/** ------------------------------------------------------------------------------------ */
	/** -------------------------------------- Tests for Graph ----------------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test Graph V method.
	@Test public void LEVEL_3_Graph_V() {
		Graph G = new Graph(3);
		assertEquals("Number of vertices must be 3", 3, G.V());
	}
	
	// Test Graph adj method.
	@Test public void LEVEL_3_Graph_adj() {
		Graph G = new Graph(3);
		assertNotNull("adj must have a not null iterator", G.adj(0).iterator());
	}
		
	// Test Graph addEdge method.
	@Test public void LEVEL_3_Graph_addEdge() {
		Graph G = new Graph(4);
		G.addEdge(3,2);
		assertEquals("V must return 4", 4, G.V()); 
		assertEquals("E must return 1", 1, G.E()); 
	}
	
	// ------------------------------------------------------------------------------------ //
	// ----------------------------------- Tests FOR LEVEL 4 ------------------------------ //
	// ------------------------------------------------------------------------------------ //
	
	/** --------------------------------------------------------------------------------------- */
	/** ------ Tests for the GraphGenerator to construct bipartite Graph ---------------------- */
	/** --------------------------------------------------------------------------------------- */

	// Test the case where the number of edges is too many for bipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void LEVEL_4_testBipartiteTooManyEdges() {
		int verticesOne = 6;
		int verticesTwo = 10;
		int edges = 80;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
	}

	// Test the case where the number of edges is too few for bipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void LEVEL_4_testBipartiteTooFewEdges() {
		int verticesOne = 18;
		int verticesTwo = 6;
		int edges = -11;
		Graph graphToTest = GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
	}

	// Test the type, the vertices number and the edges number for bipartite Graph
	@Test public void LEVEL_4_testBipartiteCreated() {
		int verticesOne = 12;
		int verticesTwo = 10;
		int edges = 10;
		int vertices = 22;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V());
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices number and the edges number are on their limits for bipartite Graph
	@Test public void LEVEL_4_testBipartiteLimits() {
		int verticesOne = 0;
		int verticesTwo = 0;
		int vertices = 0;
		int edges = 0;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
		assertEquals("Vertices must be "+vertices, vertices, graphToTest.V());
		assertEquals("Edges must be "+edges, edges, graphToTest.E()); 
		assertEquals("Type name must be bipartite", "bipartite", graphToTest.getTypeName()); 
	}

	// Test the case where the vertices numbers  are negative for bipartite Graph
	@Test(expected = IllegalArgumentException.class)
	public void LEVEL_4_testBipartiteNegativeVertices() {
		int verticesOne = -10;
		int verticesTwo = -100;
		int edges = 0;
		Graph graphToTest= GraphGenerator.bipartite(verticesOne, verticesTwo, edges);
	}
	
	// ------------------------------------------------------------------------------------ //
	// ----------------------------------- Tests FOR LEVEL 5 ------------------------------ //
	// ------------------------------------------------------------------------------------ //
	
	/** ------------------------------------------------------------------------------------ */
	/** ------------------------------- Tests for BipartiteXExtended ----------------------- */
	/** ------------------------------------------------------------------------------------ */

	// Test BipartiteXExtended constructor method.
	@Test public void LEVEL_5_BipartiteXExtended_Constructor() {
		Graph G = new Graph(3);
		BipartiteXExtended b = new BipartiteXExtended(G);
		assertNotNull("BipartiteXExtended constructor must construct a valid BipartiteXExtended graph", b);
	}	
	
	// Test BipartiteXExtended getVerticesWithAnEdgeToB method.
	@Test public void LEVEL_5_BipartiteXExtended_getVerticesWithAnEdgeToB() {
		Graph G = new Graph(3);
		BipartiteXExtended b = new BipartiteXExtended(G);
        List<Integer> VerticesWithAnEdgeToFirstVertex = b.getVerticesWithAnEdgeToB(4);
        assertNotNull("getVerticesWithAnEdgeToB must return a valid list ", VerticesWithAnEdgeToFirstVertex);
	}	
}