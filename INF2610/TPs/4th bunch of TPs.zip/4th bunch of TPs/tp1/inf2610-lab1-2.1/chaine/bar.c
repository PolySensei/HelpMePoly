/*
 * bar.c
 *
 *  Created on: 2013-08-15
 *      Author: Francis Giraldeau <francis.giraldeau@gmail.com>
 */

#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include "whoami.h"

int main(int argc, char **argv) {
	increment_rank();
	whoami("bar");
	
	int n = atoi(argv[1]);
	n--; // une boucle est complete
	if (n > 0) { // une autre recommence
		char* arg;
		asprintf(&arg, "%d", n);
		// remplace le processus enfant par baz
		execlp("baz", "baz", arg, NULL);	
	}
	return 0;
}
