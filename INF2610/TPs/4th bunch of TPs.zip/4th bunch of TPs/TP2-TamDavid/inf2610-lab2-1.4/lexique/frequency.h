/*
 * frequency.h
 *
 *  Created on: Aug 27, 2013
 *      Author: francis
 */

#ifndef FREQUENCY_H_
#define FREQUENCY_H_

void task_frequency(int in_length, int in_string, int out);

#endif /* FREQUENCY_H_ */
