#!/bin/sh

${abs_top_srcdir}/interblocage/interblocage
