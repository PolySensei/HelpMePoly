#!/bin/sh

REPEAT=10000000
AMOUNT=1000000000
LIBS="serial fork pthread pth"
for lib in $LIBS; do
	CMD="./banque --lib $lib --repeat $REPEAT --amount $AMOUNT"
	echo $CMD
	$CMD
done
