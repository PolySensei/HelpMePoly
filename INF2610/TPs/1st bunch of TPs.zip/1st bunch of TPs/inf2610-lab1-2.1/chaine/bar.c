/*
 * bar.c
 *
 *  Created on: 2013-08-15
 *      Author: Francis Giraldeau <francis.giraldeau@gmail.com>
 */

#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include "whoami.h"

int main(int argc, char **argv) {
	increment_rank();
	whoami("bar");
        
        //on recupere la valeur de n que l'on decremente
        
        int n = atoi(argv[1])-1;
        
        if(n>0) //on appelle foo a nouveau (equivalent a la boucle dans la situation de depart)
        {
            char* boucle;
            asprintf(&boucle, "%d", n);
            execlp("foo", "foo",boucle, NULL);
        }
	return 0;
}
