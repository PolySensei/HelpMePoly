/*
 * Nom:Debounce.h
 * Auteurs: Dylan Batista-Moniz - 1954776
 *          Jeremy Charland - 1955452
 */

 #define F_CPU 8000000

 bool CheckIfPressed();