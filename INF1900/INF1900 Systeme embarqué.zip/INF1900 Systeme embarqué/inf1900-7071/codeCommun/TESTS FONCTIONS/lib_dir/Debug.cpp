/*
 * Nom:Debug.cpp
 * Auteurs: Dylan Batista-Moniz - 1954776
*/

#include "Debug.h"