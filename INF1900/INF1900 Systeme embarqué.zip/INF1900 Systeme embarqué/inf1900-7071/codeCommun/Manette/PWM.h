
#ifndef PWM_H
#define PWM_H

void PWM(int valeur);

#endif
