public class Main{

//Part11

  public static void ajoutAbonne(Connection myConnection) throws SQLException{
    int numMember = 3;
    int numAbonne = 4;
    PreparedStatement request = myConnection.prepareStatement("INSERT INTO ABONNE VALUES(?, ?, TO_DATE('28-05-1995', 'DD:MM:YYYY'), NULL)");
    request.setInt(1, numMember);
    request.setInt(2, numAbonne);
    int result = request.executeUpdate();
    if (result != 0)
      System.out.println("Succes");
  }

//Part12

  public static void typeProfilMembre(Connection myConnection) throws SQLException{
    int numMembre = 1;
    PreparedStatement select = myConnection.prepareStatement("SELECT typeProfil FROM MEMBRE WHERE numM = ?");
    select.setInt(1, numMembre);
    ResultSet resSelect = select.executeQuery();
    while (resSelect.next()){
      if (resSelect.getString("typeProfil").equals("P")){
        PreparedStatement request = myConnection.prepareStatement("UPDATE MEMBRE SET typeProfil = 'v' WHERE numM = ?");
        request.setInt(1, numMembre);
        int resultat = request.executeUpdate();
        if (resultat != 0)
          System.out.println("succes");
      }else
        System.out.println("echec");
    } 
  }

//Part13

public static void membreSuperLike(Connection myConnection) throws SQLException{
  PreparedStatement select = myConnection.prepareStatement("SELECT numm FROM MEMBRE WHERE numm IN " + "(SELECT numm FROM COMMENTAIRE WHERE numPhoto IN " + "(SELECT numPhoto FROM PHOTO WHERE numm IN " + "(SELECT numAmi FROM AMI WHERE numm IN " + "(SELECT numm FROM MEMBRE))))");
  ResultSet res = select.executeQuery();
  int[] membersWhoCommented;
  int nMembersWhoCommented = 0;
  while (res.next())
    nMembersWhoCommented++;
  membersWhoCommented = new int[nMembersWhoCommented];
  res = select.executeQuery();
  for (int i = 0; res.next(); i++)
    membersWhoCommented[i] = res.getInt("numm");
  int[] membreHyperactif = new int[nMembersWhoCommented];
  int hyperCounter = 0;
  for (int i = 0; i < nMembersWhoCommented; i++){
    select = myConnection.prepareStatement("SELECT COUNT(numPhoto) AS nPhoto FROM COMMENTAIRE WHERE numPhoto IN" + "(SELECT numPhoto FROM PHOTO WHERE numm IN" + "(SELECT numAmi FROM AMI WHERE numm = ?)) AND numm = ?");
    select.setInt(1, membersWhoCommented[i]);
    select.setInt(2, membersWhoCommented[i]);
    res = select.executeQuery();
    int nComments = 0;
    while (res.next())
      nComments = res.getInt("nPhoto");
    select = myConnection.prepareStatement("SELECT COUNT(numPhoto) AS nPhoto FROM PHOTO WHERE numm IN" + "(SELECT numAmi FROM AMI WHERE numm = ?)");
    select.setInt(1, membersWhoCommented[i]);
    res = select.executeQuery();
    int nPossibleComments = 1;
    while (res.next())
      nPossibleComments = res.getInt(1);
    if (nComments >= nPossibleComments){
      membreHyperactif[hyperCounter] = membersWhoCommented[i];
      hyperCounter++;
    }
  }
  if (hyperCounter > 0){
    System.out.println("membres super like: ");
    for (int i = 0; i < hyperCounter; i++){
      select = myConnection.prepareStatement("SELECT prenom, nom FROM MEMBRE WHERE numm = ?");
      select.setInt(1, membreHyperactif[i]);
      res = select.executeQuery();
      while (res.next()){
        System.out.print(res.getString("prenom"));
        System.out.print(' ');
        System.out.println(res.getString("nom"));
      }
    }
  }
}
	
//Part14

public static void membreLePlusPopulaire(Connection myConnection) throws SQLException{
  System.out.println("membres populaires: ");
  PreparedStatement select = myConnection.prepareStatement("SELECT prenom, nom FROM MEMBRE WHERE nAmis = (SELECT MAX(nAmis) FROM MEMBRE)");
  ResultSet result = select.executeQuery();
  while (result.next()){
    System.out.print(result.getString("prenom") + " ");
    System.out.println(result.getString("nom"));
  }
}
	
public static void main(String[] args) throws SQLException{		
  String server = "jdbc:oracle:thin:@ora-labos.labos.polymtl.ca:2001:LABOS";
  String usr = "inf3710-171-62";
  String pwd = "9AAJ0G";
  Connection myConnection = null;
  try{
    Class.forName("oracle.jdbc.OracleDriver");
    myConnection = DriverManager.getConnection(server, usr, pwd);
    myConnection.setAutoCommit(false);
    System.out.println("next");
    ajoutAbonne(myConnection);
    System.out.println("next");
    typeProfilMembre(myConnection);
    System.out.println("next");
    membreSuperLike(myConnection);
    System.out.println("next");
    membreLePlusPopulaire(myConnection);
   }catch(ClassNotFoundException ex){
    System.out.println("pas trouve " + ex.getMessage());
   }catch(SQLException ex){
    System.out.println("echec" + ex.getMessage());
    ex.printStackTrace();
    }
  }
}